interface BusinessInsight {
  id: string;
  question: string;
  answer: string;
  trend: 'up' | 'down' | 'neutral';
  confidence: 'high' | 'medium' | 'low';
  action: string;
  actionUrl: string;
  priority: 'critical' | 'important' | 'normal';
  detailData?: {
    metrics?: Record<string, any>;
    explanation?: string;
    recommendations?: string[];
  };
}

interface AdMetrics {
  cost: number;
  conversions: number;
  impressions: number;
  clicks: number;
  roas: number;
  ctr: number;
  cpc: number;
}

interface CustomerMetrics {
  new_customers_this_week: number;
  new_customers_last_week: number;
  total_customers: number;
  average_customer_value: number;
  churn_rate: number;
}

interface ReviewMetrics {
  new_reviews_count: number;
  pending_responses: number;
  average_rating: number;
  response_rate: number;
  total_reviews: number;
}

interface RevenueMetrics {
  revenue_this_month: number;
  revenue_last_month: number;
  revenue_growth_rate: number;
  profit_margin: number;
  top_revenue_source: string;
}

export class BusinessInsightService {
  
  static generateInsights(data: {
    ads?: AdMetrics;
    customers?: CustomerMetrics;
    reviews?: ReviewMetrics;
    revenue?: RevenueMetrics;
  }): BusinessInsight[] {
    const insights: BusinessInsight[] = [];
    
    if (data.ads) {
      insights.push(this.transformAdData(data.ads));
    }
    
    if (data.customers) {
      insights.push(this.transformCustomerData(data.customers));
    }
    
    if (data.reviews) {
      insights.push(this.transformReviewData(data.reviews));
    }
    
    if (data.revenue) {
      insights.push(this.transformRevenueData(data.revenue));
    }
    
    // Add contextual insights based on combinations
    if (data.ads && data.customers) {
      insights.push(this.generateAcquisitionEfficiencyInsight(data.ads, data.customers));
    }
    
    return this.prioritizeInsights(insights);
  }
  
  private static transformAdData(data: AdMetrics): BusinessInsight {
    const { cost, conversions, roas, ctr, cpc } = data;
    const customerAcquisitionCost = conversions > 0 ? cost / conversions : 0;
    
    if (roas >= 4) {
      return {
        id: 'ad_performance_excellent',
        question: "Are my ads working?",
        answer: `Excellent! You spent $${cost} and got ${conversions} customers`,
        trend: "up",
        confidence: "high",
        action: "Scale this campaign",
        actionUrl: "/campaigns/scale",
        priority: "important",
        detailData: {
          explanation: `Your return on ad spend is ${roas.toFixed(1)}x, which is excellent. This means every $1 spent returns $${roas.toFixed(2)}.`,
          metrics: {
            "Ad spend": `$${cost}`,
            "New customers": conversions.toString(),
            "Cost per customer": `$${customerAcquisitionCost.toFixed(2)}`,
            "ROAS": `${roas.toFixed(1)}x`,
            "Click rate": `${(ctr * 100).toFixed(1)}%`
          },
          recommendations: [
            "Increase daily budget by 25-50%",
            "Duplicate this campaign to new audiences",
            "Create similar campaigns for other products"
          ]
        }
      };
    } else if (roas >= 2) {
      return {
        id: 'ad_performance_good',
        question: "Are my ads working?",
        answer: `Yes! You spent $${cost} yesterday and got ${conversions} new customers`,
        trend: "up",
        confidence: "high",
        action: "Optimize for better results",
        actionUrl: "/campaigns/optimize",
        priority: "normal",
        detailData: {
          explanation: `Your ads are profitable with a ${roas.toFixed(1)}x return, but there's room for improvement.`,
          metrics: {
            "Ad spend": `$${cost}`,
            "New customers": conversions.toString(),
            "Cost per customer": `$${customerAcquisitionCost.toFixed(2)}`,
            "ROAS": `${roas.toFixed(1)}x`
          },
          recommendations: [
            "Test new ad creative variations",
            "Refine your target audience",
            "Optimize landing page conversion rate"
          ]
        }
      };
    } else if (roas >= 1) {
      return {
        id: 'ad_performance_breaking_even',
        question: "Are my ads profitable?",
        answer: `Barely. You're breaking even with $${roas.toFixed(2)} return per $1 spent`,
        trend: "neutral",
        confidence: "medium",
        action: "Fix campaign targeting",
        actionUrl: "/campaigns/troubleshoot",
        priority: "important",
        detailData: {
          explanation: "Your ads are close to breaking even, which means there's potential but optimization is needed.",
          metrics: {
            "Ad spend": `$${cost}`,
            "Revenue generated": `$${(cost * roas).toFixed(2)}`,
            "ROAS": `${roas.toFixed(2)}x`,
            "Break-even point": "1.0x"
          },
          recommendations: [
            "Pause underperforming ads",
            "Test completely new audiences",
            "Review landing page experience",
            "Consider lowering bids"
          ]
        }
      };
    } else {
      return {
        id: 'ad_performance_losing_money',
        question: "Are my ads losing money?",
        answer: `Yes. You're losing $${(cost - (cost * roas)).toFixed(2)} per day`,
        trend: "down",
        confidence: "high",
        action: "Pause and fix immediately",
        actionUrl: "/campaigns/pause",
        priority: "critical",
        detailData: {
          explanation: `Your ads have a ${roas.toFixed(2)}x return, meaning you're losing money on every dollar spent.`,
          metrics: {
            "Daily loss": `$${(cost - (cost * roas)).toFixed(2)}`,
            "Ad spend": `$${cost}`,
            "Revenue generated": `$${(cost * roas).toFixed(2)}`,
            "ROAS": `${roas.toFixed(2)}x`
          },
          recommendations: [
            "Pause all campaigns immediately",
            "Review targeting settings",
            "Audit landing page conversion rate",
            "Consider professional help"
          ]
        }
      };
    }
  }
  
  private static transformCustomerData(data: CustomerMetrics): BusinessInsight {
    const { new_customers_this_week, new_customers_last_week, total_customers, average_customer_value } = data;
    const growthRate = new_customers_last_week > 0 
      ? ((new_customers_this_week - new_customers_last_week) / new_customers_last_week) * 100 
      : 0;
    
    if (growthRate > 20) {
      return {
        id: 'customer_growth_accelerating',
        question: "How is my business growing?",
        answer: `Amazing! You gained ${new_customers_this_week} customers this week (+${growthRate.toFixed(0)}%)`,
        trend: "up",
        confidence: "high",
        action: "See growth breakdown",
        actionUrl: "/customers/growth",
        priority: "important",
        detailData: {
          explanation: "Your customer acquisition is accelerating significantly, which indicates strong market demand.",
          metrics: {
            "This week": `${new_customers_this_week} customers`,
            "Last week": `${new_customers_last_week} customers`,
            "Growth rate": `+${growthRate.toFixed(1)}%`,
            "Total customers": total_customers.toString(),
            "Avg. customer value": `$${average_customer_value.toFixed(2)}`
          },
          recommendations: [
            "Identify what's driving this growth",
            "Scale successful acquisition channels",
            "Prepare infrastructure for continued growth"
          ]
        }
      };
    } else if (growthRate > 0) {
      return {
        id: 'customer_growth_positive',
        question: "How is my customer base growing?",
        answer: `Steadily. You gained ${new_customers_this_week} customers this week`,
        trend: "up",
        confidence: "high",
        action: "Accelerate growth",
        actionUrl: "/growth/strategies",
        priority: "normal",
        detailData: {
          explanation: "You're seeing positive growth, which is great. There's opportunity to accelerate this trend.",
          metrics: {
            "This week": `${new_customers_this_week} customers`,
            "Last week": `${new_customers_last_week} customers`,
            "Growth rate": `+${growthRate.toFixed(1)}%`,
            "Total customers": total_customers.toString()
          },
          recommendations: [
            "Double down on what's working",
            "Experiment with new marketing channels",
            "Improve customer referral program"
          ]
        }
      };
    } else if (growthRate === 0) {
      return {
        id: 'customer_growth_flat',
        question: "Why isn't my customer base growing?",
        answer: `Flat. You gained ${new_customers_this_week} customers (same as last week)`,
        trend: "neutral",
        confidence: "medium",
        action: "Find growth opportunities",
        actionUrl: "/growth/audit",
        priority: "important",
        detailData: {
          explanation: "Your customer acquisition has plateaued. This is common but indicates you need new strategies.",
          metrics: {
            "This week": `${new_customers_this_week} customers`,
            "Last week": `${new_customers_last_week} customers`,
            "Growth rate": "0%",
            "Total customers": total_customers.toString()
          },
          recommendations: [
            "Audit current marketing channels",
            "Try new acquisition channels",
            "Improve conversion rates",
            "Launch referral program"
          ]
        }
      };
    } else {
      return {
        id: 'customer_growth_declining',
        question: "Why am I losing customers?",
        answer: `Concerning. You only gained ${new_customers_this_week} customers (down ${Math.abs(growthRate).toFixed(0)}%)`,
        trend: "down",
        confidence: "high",
        action: "Diagnose the problem",
        actionUrl: "/customers/analyze-decline",
        priority: "critical",
        detailData: {
          explanation: "Your customer acquisition is declining, which needs immediate attention to prevent further loss.",
          metrics: {
            "This week": `${new_customers_this_week} customers`,
            "Last week": `${new_customers_last_week} customers`,
            "Decline rate": `${growthRate.toFixed(1)}%`,
            "Total customers": total_customers.toString()
          },
          recommendations: [
            "Review recent changes to marketing",
            "Check if competitors launched campaigns",
            "Survey recent customers for feedback",
            "Consider promotional offers"
          ]
        }
      };
    }
  }
  
  private static transformReviewData(data: ReviewMetrics): BusinessInsight {
    const { new_reviews_count, pending_responses, average_rating, response_rate } = data;
    
    if (pending_responses > 0) {
      return {
        id: 'reviews_need_response',
        question: "What needs my attention today?",
        answer: `${new_reviews_count} customers left reviews - ${pending_responses} need responses`,
        trend: "neutral",
        confidence: "high",
        action: "Respond to reviews",
        actionUrl: "/reviews/pending",
        priority: pending_responses > 3 ? "critical" : "important",
        detailData: {
          explanation: "Responding to reviews quickly improves your reputation and shows customers you care.",
          metrics: {
            "New reviews": new_reviews_count.toString(),
            "Pending responses": pending_responses.toString(),
            "Average rating": `${average_rating.toFixed(1)} ⭐`,
            "Response rate": `${(response_rate * 100).toFixed(0)}%`
          },
          recommendations: [
            "Respond within 24 hours",
            "Thank customers for positive reviews",
            "Address concerns in negative reviews professionally",
            "Set up review response templates"
          ]
        }
      };
    } else if (average_rating >= 4.5) {
      return {
        id: 'reviews_excellent_rating',
        question: "How do customers rate my business?",
        answer: `Excellent! ${average_rating.toFixed(1)} stars from ${new_reviews_count} recent reviews`,
        trend: "up",
        confidence: "high",
        action: "Leverage positive reviews",
        actionUrl: "/reviews/marketing",
        priority: "normal",
        detailData: {
          explanation: "Your high rating is a valuable marketing asset that can drive more customers.",
          metrics: {
            "Average rating": `${average_rating.toFixed(1)} ⭐`,
            "New reviews": new_reviews_count.toString(),
            "Response rate": `${(response_rate * 100).toFixed(0)}%`
          },
          recommendations: [
            "Feature reviews on your website",
            "Share positive reviews on social media",
            "Ask happy customers for more reviews",
            "Include ratings in ad campaigns"
          ]
        }
      };
    } else {
      return {
        id: 'reviews_needs_improvement',
        question: "How can I improve my customer satisfaction?",
        answer: `${average_rating.toFixed(1)} star average needs improvement`,
        trend: "neutral",
        confidence: "medium",
        action: "Improve customer experience",
        actionUrl: "/reviews/improvement-plan",
        priority: "important",
        detailData: {
          explanation: "Your rating indicates there are opportunities to improve the customer experience.",
          metrics: {
            "Average rating": `${average_rating.toFixed(1)} ⭐`,
            "New reviews": new_reviews_count.toString(),
            "Target rating": "4.5+ ⭐"
          },
          recommendations: [
            "Analyze negative review patterns",
            "Implement customer feedback system",
            "Train staff on customer service",
            "Follow up with unsatisfied customers"
          ]
        }
      };
    }
  }
  
  private static transformRevenueData(data: RevenueMetrics): BusinessInsight {
    const { revenue_this_month, revenue_last_month, revenue_growth_rate, profit_margin } = data;
    
    if (revenue_growth_rate > 15) {
      return {
        id: 'revenue_strong_growth',
        question: "How is my revenue performing?",
        answer: `Strong! $${revenue_this_month.toLocaleString()} this month (+${revenue_growth_rate.toFixed(0)}%)`,
        trend: "up",
        confidence: "high",
        action: "Scale successful strategies",
        actionUrl: "/revenue/scale",
        priority: "important",
        detailData: {
          explanation: "Your revenue growth is strong, indicating successful business strategies.",
          metrics: {
            "This month": `$${revenue_this_month.toLocaleString()}`,
            "Last month": `$${revenue_last_month.toLocaleString()}`,
            "Growth rate": `+${revenue_growth_rate.toFixed(1)}%`,
            "Profit margin": `${profit_margin.toFixed(1)}%`
          },
          recommendations: [
            "Identify top-performing revenue streams",
            "Invest more in successful channels",
            "Consider expanding product/service line"
          ]
        }
      };
    } else if (revenue_growth_rate < -5) {
      return {
        id: 'revenue_declining',
        question: "Why is my revenue declining?",
        answer: `Concerning. Revenue dropped to $${revenue_this_month.toLocaleString()} (${revenue_growth_rate.toFixed(0)}%)`,
        trend: "down",
        confidence: "high",
        action: "Diagnose revenue issues",
        actionUrl: "/revenue/recovery-plan",
        priority: "critical",
        detailData: {
          explanation: "Revenue decline needs immediate attention to identify and address root causes.",
          metrics: {
            "This month": `$${revenue_this_month.toLocaleString()}`,
            "Last month": `$${revenue_last_month.toLocaleString()}`,
            "Decline": `${revenue_growth_rate.toFixed(1)}%`,
            "Profit margin": `${profit_margin.toFixed(1)}%`
          },
          recommendations: [
            "Analyze customer behavior changes",
            "Review pricing strategy",
            "Check for increased competition",
            "Survey customers for feedback"
          ]
        }
      };
    } else {
      return {
        id: 'revenue_stable',
        question: "How is my revenue trending?",
        answer: `Stable. $${revenue_this_month.toLocaleString()} this month`,
        trend: "neutral",
        confidence: "medium",
        action: "Find growth opportunities",
        actionUrl: "/revenue/growth-plan",
        priority: "normal",
        detailData: {
          explanation: "Stable revenue is good, but there's always opportunity for growth.",
          metrics: {
            "This month": `$${revenue_this_month.toLocaleString()}`,
            "Last month": `$${revenue_last_month.toLocaleString()}`,
            "Change": `${revenue_growth_rate.toFixed(1)}%`,
            "Profit margin": `${profit_margin.toFixed(1)}%`
          },
          recommendations: [
            "Explore new revenue streams",
            "Optimize pricing strategy", 
            "Improve customer lifetime value",
            "Consider upselling/cross-selling"
          ]
        }
      };
    }
  }
  
  private static generateAcquisitionEfficiencyInsight(ads: AdMetrics, customers: CustomerMetrics): BusinessInsight {
    const costPerCustomer = ads.conversions > 0 ? ads.cost / ads.conversions : 0;
    const customerLifetimeValue = customers.average_customer_value;
    const efficiency = customerLifetimeValue / costPerCustomer;
    
    if (efficiency > 3) {
      return {
        id: 'acquisition_very_efficient',
        question: "How efficient is my customer acquisition?",
        answer: `Very efficient! Each customer costs $${costPerCustomer.toFixed(2)} but is worth $${customerLifetimeValue.toFixed(2)}`,
        trend: "up",
        confidence: "high",
        action: "Scale acquisition",
        actionUrl: "/acquisition/scale",
        priority: "important",
        detailData: {
          explanation: "Your customer acquisition is highly efficient with strong lifetime value ratios.",
          metrics: {
            "Cost per customer": `$${costPerCustomer.toFixed(2)}`,
            "Customer lifetime value": `$${customerLifetimeValue.toFixed(2)}`,
            "Efficiency ratio": `${efficiency.toFixed(1)}:1`,
            "Profit per customer": `$${(customerLifetimeValue - costPerCustomer).toFixed(2)}`
          },
          recommendations: [
            "Increase marketing budget",
            "Expand to new platforms",
            "Test higher value audiences"
          ]
        }
      };
    } else {
      return {
        id: 'acquisition_needs_optimization',
        question: "Is my customer acquisition cost effective?",
        answer: `Marginal. Customers cost $${costPerCustomer.toFixed(2)} vs $${customerLifetimeValue.toFixed(2)} value`,
        trend: "neutral",
        confidence: "medium",
        action: "Improve efficiency",
        actionUrl: "/acquisition/optimize",
        priority: "important",
        detailData: {
          explanation: "Your acquisition costs are close to customer value, limiting profitability.",
          metrics: {
            "Cost per customer": `$${costPerCustomer.toFixed(2)}`,
            "Customer lifetime value": `$${customerLifetimeValue.toFixed(2)}`,
            "Efficiency ratio": `${efficiency.toFixed(1)}:1`
          },
          recommendations: [
            "Reduce acquisition costs",
            "Increase customer lifetime value",
            "Improve ad targeting",
            "Optimize conversion rates"
          ]
        }
      };
    }
  }
  
  private static prioritizeInsights(insights: BusinessInsight[]): BusinessInsight[] {
    // Sort by priority: critical first, then important, then normal
    // Within each priority, sort by confidence: high first
    return insights.sort((a, b) => {
      const priorityOrder = { critical: 3, important: 2, normal: 1 };
      const confidenceOrder = { high: 3, medium: 2, low: 1 };
      
      if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      }
      
      return confidenceOrder[b.confidence] - confidenceOrder[a.confidence];
    });
  }
  
  // Helper method to generate sample data for testing
  static generateSampleInsights(): BusinessInsight[] {
    const sampleData = {
      ads: {
        cost: 127,
        conversions: 5,
        impressions: 8500,
        clicks: 340,
        roas: 4.2,
        ctr: 0.04,
        cpc: 0.37
      },
      customers: {
        new_customers_this_week: 12,
        new_customers_last_week: 8,
        total_customers: 234,
        average_customer_value: 89,
        churn_rate: 0.05
      },
      reviews: {
        new_reviews_count: 7,
        pending_responses: 2,
        average_rating: 4.8,
        response_rate: 0.85,
        total_reviews: 156
      },
      revenue: {
        revenue_this_month: 18500,
        revenue_last_month: 16200,
        revenue_growth_rate: 14.2,
        profit_margin: 23.5,
        top_revenue_source: "E-commerce"
      }
    };
    
    return this.generateInsights(sampleData);
  }
} 