/**
 * Data safety utilities to prevent runtime errors with null/undefined values
 */

/**
 * Safely handles Object.entries calls to prevent null/undefined errors
 */
export const safeObjectEntries = (obj: any): [string, any][] => {
  if (!obj || typeof obj !== 'object') {
    return [];
  }
  try {
    return Object.entries(obj);
  } catch (error) {
    console.warn('Error in safeObjectEntries:', error);
    return [];
  }
};

/**
 * Safely handles Object.keys calls to prevent null/undefined errors
 */
export const safeObjectKeys = (obj: any): string[] => {
  if (!obj || typeof obj !== 'object') {
    return [];
  }
  try {
    return Object.keys(obj);
  } catch (error) {
    console.warn('Error in safeObjectKeys:', error);
    return [];
  }
};

/**
 * Safely handles Object.values calls to prevent null/undefined errors
 */
export const safeObjectValues = (obj: any): any[] => {
  if (!obj || typeof obj !== 'object') {
    return [];
  }
  try {
    return Object.values(obj);
  } catch (error) {
    console.warn('Error in safeObjectValues:', error);
    return [];
  }
};

/**
 * Safely access nested object properties
 */
export const safeGet = (obj: any, path: string, defaultValue: any = null): any => {
  if (!obj || typeof obj !== 'object') {
    return defaultValue;
  }
  
  try {
    return path.split('.').reduce((current, key) => {
      return current && current[key] !== undefined ? current[key] : defaultValue;
    }, obj);
  } catch (error) {
    console.warn('Error in safeGet:', error);
    return defaultValue;
  }
};

/**
 * Safely check if an object has a property
 */
export const safeHasProperty = (obj: any, property: string): boolean => {
  if (!obj || typeof obj !== 'object') {
    return false;
  }
  try {
    return Object.prototype.hasOwnProperty.call(obj, property);
  } catch (error) {
    console.warn('Error in safeHasProperty:', error);
    return false;
  }
};

/**
 * Safely map over object entries
 */
export const safeMapEntries = <T>(
  obj: any, 
  mapFn: (key: string, value: any, index: number) => T,
  defaultValue: T[] = []
): T[] => {
  if (!obj || typeof obj !== 'object') {
    return defaultValue;
  }
  
  try {
    return Object.entries(obj).map(([key, value], index) => mapFn(key, value, index));
  } catch (error) {
    console.warn('Error in safeMapEntries:', error);
    return defaultValue;
  }
};

/**
 * Safely merge objects
 */
export const safeMerge = (...objects: any[]): any => {
  try {
    return objects.reduce((merged, obj) => {
      if (obj && typeof obj === 'object') {
        return { ...merged, ...obj };
      }
      return merged;
    }, {});
  } catch (error) {
    console.warn('Error in safeMerge:', error);
    return {};
  }
}; 