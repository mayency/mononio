'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuthStore } from '@/store/auth';
import {
  HomeIcon,
  ChartBarIcon,
  MegaphoneIcon as CampaignIcon,
  DocumentTextIcon,
  UsersIcon,
  CogIcon,
  ArrowLeftOnRectangleIcon as LogoutIcon,
  SparklesIcon,
  BuildingStorefrontIcon,
  BellIcon,
  QuestionMarkCircleIcon,
  ChevronDownIcon,
  ChevronRightIcon
} from '@heroicons/react/24/outline';

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: HomeIcon },
  { name: 'Analytics', href: '/analytics', icon: ChartBarIcon },
  { name: 'Campaigns', href: '/campaigns', icon: CampaignIcon },
  { name: 'Content', href: '/content', icon: DocumentTextIcon },
  { name: 'Leads', href: '/leads', icon: UsersIcon },
  { name: 'Businesses', href: '/businesses', icon: BuildingStorefrontIcon },
  { name: 'Marketplace', href: '/marketplace', icon: SparklesIcon, badge: 'New' },
  { name: 'Settings', href: '/settings', icon: CogIcon },
];

const aiToolsSubmenu = [
  { name: 'AI Tools', href: '/ai-tools', icon: SparklesIcon },
  { name: 'Video Generator', href: '/video', icon: DocumentTextIcon },
  { name: 'Landing Pages', href: '/landing-pages', icon: DocumentTextIcon },
  { name: 'Research', href: '/research', icon: ChartBarIcon },
  { name: 'Campaign Orchestrator', href: '/campaign-orchestrator', icon: CampaignIcon },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuthStore();
  const [isAiToolsOpen, setIsAiToolsOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="flex flex-col w-64 bg-white shadow-lg">
        {/* Logo */}
        <div className="flex items-center justify-center h-16 px-4 border-b">
          <Link href="/dashboard" className="flex items-center space-x-2">
            <SparklesIcon className="h-8 w-8 text-blue-600" />
            <span className="text-xl font-bold text-gray-900">LaunchMate</span>
          </Link>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
          {navigation.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                  isActive
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-50'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <item.icon className="h-5 w-5" />
                  <span>{item.name}</span>
                </div>
                {item.badge && (
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    {item.badge}
                  </span>
                )}
              </Link>
            );
          })}

          {/* AI Tools Submenu */}
          <div className="space-y-1">
            <button
              onClick={() => setIsAiToolsOpen(!isAiToolsOpen)}
              className="flex items-center justify-between w-full px-3 py-2 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center space-x-3">
                <SparklesIcon className="h-5 w-5" />
                <span>AI Tools</span>
              </div>
              {isAiToolsOpen ? (
                <ChevronDownIcon className="h-4 w-4" />
              ) : (
                <ChevronRightIcon className="h-4 w-4" />
              )}
            </button>
            
            {isAiToolsOpen && (
              <div className="ml-6 space-y-1">
                {aiToolsSubmenu.map((item) => {
                  const isActive = pathname === item.href;
                  return (
                    <Link
                      key={item.name}
                      href={item.href}
                      className={`flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                        isActive
                          ? 'bg-blue-50 text-blue-700'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      <item.icon className="h-4 w-4" />
                      <span>{item.name}</span>
                    </Link>
                  );
                })}
              </div>
            )}
          </div>
        </nav>

        {/* User Profile */}
        <div className="border-t px-4 py-4">
          <div className="flex items-center space-x-3 mb-4">
            <div className="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center">
              <span className="text-white text-sm font-medium">
                {user?.name?.[0] || 'U'}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">
                {user?.name || 'User'}
              </p>
              <p className="text-xs text-gray-500 truncate">
                {user?.email || 'user@example.com'}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <Link
              href="/notifications"
              className="flex items-center space-x-3 px-3 py-2 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <BellIcon className="h-4 w-4" />
              <span>Notifications</span>
            </Link>
            
            <Link
              href="/help"
              className="flex items-center space-x-3 px-3 py-2 text-sm font-medium text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <QuestionMarkCircleIcon className="h-4 w-4" />
              <span>Help & Support</span>
            </Link>
            
            <button
              onClick={handleLogout}
              className="flex items-center space-x-3 px-3 py-2 text-sm font-medium text-red-600 rounded-lg hover:bg-red-50 transition-colors w-full"
            >
              <LogoutIcon className="h-4 w-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
} 