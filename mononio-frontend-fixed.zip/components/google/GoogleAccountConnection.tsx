'use client';

import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  BarChart3, 
  Target, 
  Building, 
  PlayCircle,
  Shield,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Trash2
} from 'lucide-react';

interface GoogleAccount {
  id: string;
  email: string;
  name: string;
  connected_at: string;
  scopes: string[];
  status: 'active' | 'expired' | 'error';
}

interface GoogleService {
  key: string;
  name: string;
  icon: React.ElementType;
  description: string;
  features: string[];
  required_scopes: string[];
  status: 'connected' | 'not_connected' | 'error';
}

export default function GoogleAccountConnection() {
  const [connectedAccounts, setConnectedAccounts] = useState<GoogleAccount[]>([]);
  const [isConnecting, setIsConnecting] = useState(false);
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'connecting' | 'success' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const googleServices: GoogleService[] = [
    {
      key: 'analytics',
      name: 'Google Analytics',
      icon: BarChart3,
      description: 'Website and app analytics, user behavior insights',
      features: ['Traffic analysis', 'Conversion tracking', 'Audience insights', 'Custom reports'],
      required_scopes: ['https://www.googleapis.com/auth/analytics.readonly'],
      status: 'not_connected'
    },
    {
      key: 'ads',
      name: 'Google Ads',
      icon: Target,
      description: 'Advertising campaign management and optimization',
      features: ['Campaign management', 'Performance tracking', 'Keyword research', 'Audience targeting'],
      required_scopes: ['https://www.googleapis.com/auth/adwords'],
      status: 'not_connected'
    },
    {
      key: 'business_profile',
      name: 'Google Business Profile',
      icon: Building,
      description: 'Local business listing and customer engagement',
      features: ['Business information', 'Customer reviews', 'Local SEO', 'Insights'],
      required_scopes: ['https://www.googleapis.com/auth/business.manage'],
      status: 'not_connected'
    },
    {
      key: 'youtube',
      name: 'YouTube',
      icon: PlayCircle,
      description: 'Video content management and analytics',
      features: ['Channel analytics', 'Video performance', 'Audience insights', 'Content management'],
      required_scopes: ['https://www.googleapis.com/auth/youtube.readonly'],
      status: 'not_connected'
    }
  ];

  useEffect(() => {
    loadConnectedAccounts();
  }, []);

  const loadConnectedAccounts = async () => {
    try {
      const response = await fetch('/api/google/accounts', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });

      if (response.ok) {
        const result = await response.json();
        setConnectedAccounts(result.connected_accounts || []);
      }
    } catch (error) {
      console.error('Error loading connected accounts:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const generateOAuthUrl = async (services: string[]) => {
    try {
      setIsConnecting(true);
      setError(null);

      // Map services to features
      const features = services.flatMap(service => {
        switch (service) {
          case 'analytics':
            return ['view_analytics_reports'];
          case 'ads':
            return ['manage_ads_campaigns'];
          case 'business_profile':
            return ['view_business_profile'];
          case 'youtube':
            return ['view_youtube_analytics'];
          default:
            return [];
        }
      });

      const response = await fetch('/api/google/oauth/url', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({
          user_id: 'current_user',
          features: features
        })
      });

      if (response.ok) {
        const result = await response.json();
        
        // Store connection state
        sessionStorage.setItem('google_oauth_state', result.state);
        sessionStorage.setItem('google_connecting_services', JSON.stringify(services));
        
        // Open OAuth flow in popup
        const popup = window.open(
          result.oauth_url,
          'google_oauth',
          'width=600,height=700,scrollbars=yes,resizable=yes'
        );

        // Listen for popup completion
        const checkClosed = setInterval(() => {
          if (popup?.closed) {
            clearInterval(checkClosed);
            setIsConnecting(false);
            checkConnectionResult();
          }
        }, 1000);

      } else {
        throw new Error('Failed to generate OAuth URL');
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to connect');
      setIsConnecting(false);
    }
  };

  const checkConnectionResult = async () => {
    // Check if connection was successful
    await new Promise(resolve => setTimeout(resolve, 2000)); // Wait for callback processing
    await loadConnectedAccounts();
    
    const connectingServices = sessionStorage.getItem('google_connecting_services');
    if (connectingServices) {
      sessionStorage.removeItem('google_connecting_services');
      sessionStorage.removeItem('google_oauth_state');
      setConnectionStatus('success');
      setTimeout(() => setConnectionStatus('idle'), 3000);
    }
  };

  const disconnectAccount = async (accountId: string) => {
    try {
      const response = await fetch(`/api/google/accounts/${accountId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });

      if (response.ok) {
        await loadConnectedAccounts();
      } else {
        throw new Error('Failed to disconnect account');
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to disconnect');
    }
  };

  const toggleService = (serviceKey: string) => {
    setSelectedServices(prev => 
      prev.includes(serviceKey)
        ? prev.filter(s => s !== serviceKey)
        : [...prev, serviceKey]
    );
  };

  const getServiceStatus = (service: GoogleService): 'connected' | 'not_connected' | 'error' => {
    // Check if any connected account has the required scopes
    const hasRequiredScopes = connectedAccounts.some(account => 
      service.required_scopes.every(scope => 
        account.scopes.some(accountScope => accountScope.includes(scope.split('/').pop() || ''))
      )
    );
    
    return hasRequiredScopes ? 'connected' : 'not_connected';
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="space-y-3">
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded w-5/6"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow">
      {/* Header */}
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Globe className="w-6 h-6 text-blue-600" />
            <div>
              <h2 className="text-lg font-semibold text-gray-900">Google Services</h2>
              <p className="text-sm text-gray-600">Connect your Google accounts to unlock powerful integrations</p>
            </div>
          </div>
          {connectionStatus === 'success' && (
            <div className="flex items-center space-x-2 text-green-600">
              <CheckCircle className="w-5 h-5" />
              <span className="text-sm font-medium">Connected successfully!</span>
            </div>
          )}
        </div>
      </div>

      {/* Connected Accounts */}
      {connectedAccounts.length > 0 && (
        <div className="px-6 py-4 border-b border-gray-200 bg-green-50">
          <h3 className="text-sm font-medium text-gray-900 mb-3">Connected Accounts</h3>
          <div className="space-y-2">
            {connectedAccounts.map((account) => (
              <div key={account.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                    <Globe className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <div className="font-medium text-gray-900">{account.name}</div>
                    <div className="text-sm text-gray-600">{account.email}</div>
                    <div className="text-xs text-gray-500">
                      Connected {new Date(account.connected_at).toLocaleDateString()}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    account.status === 'active' 
                      ? 'bg-green-100 text-green-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {account.status}
                  </span>
                  <button
                    onClick={() => disconnectAccount(account.id)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Available Services */}
      <div className="p-6">
        <h3 className="text-sm font-medium text-gray-900 mb-4">Available Services</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {googleServices.map((service) => {
            const status = getServiceStatus(service);
            const isSelected = selectedServices.includes(service.key);
            const IconComponent = service.icon;
            
            return (
              <div
                key={service.key}
                className={`border rounded-lg p-4 cursor-pointer transition-all ${
                  status === 'connected' 
                    ? 'border-green-200 bg-green-50'
                    : isSelected
                    ? 'border-blue-200 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => status !== 'connected' && toggleService(service.key)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${
                      status === 'connected' ? 'bg-green-100' : 'bg-gray-100'
                    }`}>
                      <IconComponent className={`w-6 h-6 ${
                        status === 'connected' ? 'text-green-600' : 'text-gray-600'
                      }`} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{service.name}</h4>
                      <p className="text-sm text-gray-600 mt-1">{service.description}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {status === 'connected' ? (
                      <div className="flex items-center space-x-1 text-green-600">
                        <CheckCircle className="w-4 h-4" />
                        <span className="text-xs font-medium">Connected</span>
                      </div>
                    ) : (
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleService(service.key)}
                        className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                      />
                    )}
                  </div>
                </div>
                
                {/* Features */}
                <div className="mt-3">
                  <div className="flex flex-wrap gap-1">
                    {service.features.slice(0, 3).map((feature) => (
                      <span
                        key={feature}
                        className="px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded"
                      >
                        {feature}
                      </span>
                    ))}
                    {service.features.length > 3 && (
                      <span className="px-2 py-1 text-xs bg-gray-100 text-gray-500 rounded">
                        +{service.features.length - 3} more
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <span className="text-sm text-red-800">{error}</span>
            </div>
          </div>
        )}

        {/* Connect Button */}
        {selectedServices.length > 0 && (
          <div className="flex items-center justify-between p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div>
              <div className="font-medium text-blue-900">
                Connect {selectedServices.length} service{selectedServices.length > 1 ? 's' : ''}
              </div>
              <div className="text-sm text-blue-700">
                {selectedServices.map(key => 
                  googleServices.find(s => s.key === key)?.name
                ).join(', ')}
              </div>
            </div>
            <button
              onClick={() => generateOAuthUrl(selectedServices)}
              disabled={isConnecting}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center space-x-2"
            >
              {isConnecting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>Connecting...</span>
                </>
              ) : (
                <>
                  <ExternalLink className="w-4 h-4" />
                  <span>Connect with Google</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Security Notice */}
        <div className="mt-6 p-4 bg-gray-50 border border-gray-200 rounded-lg">
          <div className="flex items-start space-x-3">
            <Shield className="w-5 h-5 text-gray-600 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-gray-900">Security & Privacy</h4>
              <p className="text-sm text-gray-600 mt-1">
                We use OAuth 2.0 for secure authentication. Your passwords are never stored. 
                You can revoke access at any time through your Google Account settings.
              </p>
              <a
                href="https://myaccount.google.com/permissions"
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-blue-600 hover:underline mt-2 inline-flex items-center space-x-1"
              >
                <span>Manage Google permissions</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
} 