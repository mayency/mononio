'use client';

import React, { useState, useEffect } from 'react';
import { X, Shield, BarChart3, Target, Mail } from 'lucide-react';

interface ConsentChoices {
  necessary: boolean;
  analytics: boolean;
  advertising: boolean;
  marketing: boolean;
}

interface ConsentBannerProps {
  onConsentGiven: (choices: ConsentChoices) => void;
  onConsentDeclined: () => void;
}

export default function ConsentBanner({ onConsentGiven, onConsentDeclined }: ConsentBannerProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [consentChoices, setConsentChoices] = useState<ConsentChoices>({
    necessary: true,    // Always required
    analytics: false,
    advertising: false,
    marketing: false
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Check if consent has already been given
    const storedConsent = localStorage.getItem('google_api_consent');
    if (!storedConsent) {
      // Show banner after a short delay
      const timer = setTimeout(() => setIsVisible(true), 1000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAcceptAll = async () => {
    const allAccepted = {
      necessary: true,
      analytics: true,
      advertising: true,
      marketing: true
    };
    await submitConsent(allAccepted);
  };

  const handleAcceptSelected = async () => {
    await submitConsent(consentChoices);
  };

  const handleDeclineAll = async () => {
    const onlyNecessary = {
      necessary: true,
      analytics: false,
      advertising: false,
      marketing: false
    };
    await submitConsent(onlyNecessary);
    onConsentDeclined();
  };

  const submitConsent = async (choices: ConsentChoices) => {
    setIsLoading(true);
    
    try {
      // Submit consent to backend
      const response = await fetch('/api/google/consent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        },
        body: JSON.stringify({
          consent_choices: choices
        })
      });

      if (response.ok) {
        const result = await response.json();
        
        // Store consent locally
        localStorage.setItem('google_api_consent', JSON.stringify({
          choices,
          timestamp: new Date().toISOString(),
          allowed_services: result.allowed_services
        }));

        // Hide banner
        setIsVisible(false);
        
        // Notify parent component
        onConsentGiven(choices);
        
        // Configure Google Analytics based on consent
        if (choices.analytics && window.gtag) {
          window.gtag('consent', 'update', {
            'analytics_storage': 'granted'
          });
        }
        
        if (choices.advertising && window.gtag) {
          window.gtag('consent', 'update', {
            'ad_storage': 'granted'
          });
        }
        
      } else {
        console.error('Failed to submit consent');
      }
    } catch (error) {
      console.error('Error submitting consent:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateConsentChoice = (category: keyof ConsentChoices, value: boolean) => {
    setConsentChoices(prev => ({
      ...prev,
      [category]: value
    }));
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div className="flex items-center space-x-3">
            <Shield className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-900">Privacy & Cookie Consent</h2>
          </div>
          <button
            onClick={handleDeclineAll}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="mb-6">
            <p className="text-gray-700 mb-4">
              We use cookies and similar technologies to improve your experience, analyze usage, 
              and provide personalized content. You can customize your preferences below.
            </p>
            <p className="text-sm text-gray-600">
              This consent applies to Google services integration including Analytics, Ads, 
              Tag Manager, and Business Profile APIs.
            </p>
          </div>

          {/* Consent Categories */}
          <div className="space-y-4">
            {/* Necessary Cookies */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Shield className="w-5 h-5 text-green-600" />
                  <div>
                    <h3 className="font-medium text-gray-900">Necessary</h3>
                    <p className="text-sm text-gray-600">
                      Required for basic site functionality and security
                    </p>
                  </div>
                </div>
                <div className="flex items-center">
                  <span className="text-sm text-gray-500 mr-2">Always Active</span>
                  <div className="w-12 h-6 bg-green-100 rounded-full flex items-center justify-end px-1">
                    <div className="w-4 h-4 bg-green-600 rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Analytics */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <BarChart3 className="w-5 h-5 text-blue-600" />
                  <div>
                    <h3 className="font-medium text-gray-900">Analytics</h3>
                    <p className="text-sm text-gray-600">
                      Help us understand site usage and improve your experience
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Google Analytics, performance tracking
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={consentChoices.analytics}
                    onChange={(e) => updateConsentChoice('analytics', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-12 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>

            {/* Advertising */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Target className="w-5 h-5 text-orange-600" />
                  <div>
                    <h3 className="font-medium text-gray-900">Advertising</h3>
                    <p className="text-sm text-gray-600">
                      Personalized ads and content based on your interests
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Google Ads, Tag Manager, audience targeting
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={consentChoices.advertising}
                    onChange={(e) => updateConsentChoice('advertising', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-12 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-orange-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-600"></div>
                </label>
              </div>
            </div>

            {/* Marketing */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Mail className="w-5 h-5 text-purple-600" />
                  <div>
                    <h3 className="font-medium text-gray-900">Marketing</h3>
                    <p className="text-sm text-gray-600">
                      Business communications and campaign management
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Google Business Profile, customer communications
                    </p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={consentChoices.marketing}
                    onChange={(e) => updateConsentChoice('marketing', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-12 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                </label>
              </div>
            </div>
          </div>

          {/* Additional Information */}
          {showDetails && (
            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-3">Data Processing Details</h4>
              <div className="space-y-3 text-sm text-gray-700">
                <div>
                  <strong>Data Controller:</strong> LaunchMate Platform
                </div>
                <div>
                  <strong>Legal Basis:</strong> Consent (GDPR Article 6(1)(a))
                </div>
                <div>
                  <strong>Data Retention:</strong> Analytics data retained for 26 months, 
                  advertising data for 18 months
                </div>
                <div>
                  <strong>Your Rights:</strong> You can withdraw consent, access, rectify, 
                  or delete your data at any time
                </div>
                <div>
                  <strong>Third Parties:</strong> Google LLC (Privacy Policy: 
                  <a href="https://policies.google.com/privacy" target="_blank" rel="noopener" 
                     className="text-blue-600 hover:underline ml-1">
                    https://policies.google.com/privacy
                  </a>)
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-6 border-t bg-gray-50">
          <button
            onClick={() => setShowDetails(!showDetails)}
            className="text-sm text-gray-600 hover:text-gray-800 underline"
          >
            {showDetails ? 'Hide Details' : 'More Information'}
          </button>
          
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleDeclineAll}
              disabled={isLoading}
              className="px-6 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50"
            >
              Essential Only
            </button>
            <button
              onClick={handleAcceptSelected}
              disabled={isLoading}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {isLoading ? 'Saving...' : 'Accept Selected'}
            </button>
            <button
              onClick={handleAcceptAll}
              disabled={isLoading}
              className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
            >
              Accept All
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Type declarations for global gtag
declare global {
  interface Window {
    gtag: any;
  }
} 