'use client';

import { useState, useEffect } from 'react';
import { Business } from '@/types';
import { Button } from '@/components/ui/Button';
import {
  SparklesIcon,
  LightBulbIcon,
  DocumentTextIcon,
  PhotoIcon,
  VideoCameraIcon,
  ArrowPathIcon,
  EyeIcon,
  ClipboardDocumentIcon,
} from '@heroicons/react/24/outline';

interface ContentRecommendation {
  id: string;
  type: 'text' | 'image' | 'video';
  platform: string;
  title: string;
  description: string;
  reasoning: string;
  estimatedEngagement: number;
  difficulty: 'easy' | 'medium' | 'hard';
  timeToCreate: string;
}

interface AIRecommendationsProps {
  business: Business | null;
  onSelectRecommendation: (recommendation: ContentRecommendation) => void;
  onGenerateRecommendations: () => void;
}

export default function AIRecommendations({ 
  business, 
  onSelectRecommendation, 
  onGenerateRecommendations 
}: AIRecommendationsProps) {
  const [recommendations, setRecommendations] = useState<ContentRecommendation[]>([]);
  const [loading, setLoading] = useState(false);
  const [expandedRecommendation, setExpandedRecommendation] = useState<string | null>(null);

  useEffect(() => {
    if (business) {
      generateRecommendations();
    }
  }, [business]);

  const generateRecommendations = () => {
    if (!business) return;
    
    setLoading(true);
    
    // Simulate async operation with setTimeout
    setTimeout(() => {
      try {
        // Mock recommendations for now - will be replaced with API call
        const mockRecommendations: ContentRecommendation[] = [
          {
            id: '1',
            type: 'text',
            platform: 'linkedin',
            title: 'Professional Industry Insights Post',
            description: 'Share valuable insights about your industry with a professional tone',
            reasoning: `Based on your ${business.industry} industry and professional brand voice, LinkedIn posts perform well with your target audience of ${business.target_audience}`,
            estimatedEngagement: 85,
            difficulty: 'easy',
            timeToCreate: '15 min'
          },
          {
            id: '2',
            type: 'image',
            platform: 'instagram',
            title: 'Behind-the-Scenes Brand Story',
            description: 'Visual content showing your team and company culture',
            reasoning: 'Instagram visual content drives 2.3x more engagement for businesses in your industry',
            estimatedEngagement: 92,
            difficulty: 'medium',
            timeToCreate: '30 min'
          },
          {
            id: '3',
            type: 'video',
            platform: 'tiktok',
            title: 'Quick Tips & Tricks Video',
            description: 'Short, engaging video with actionable advice for your audience',
            reasoning: 'TikTok videos under 60 seconds have 40% higher completion rates for your target demographic',
            estimatedEngagement: 78,
            difficulty: 'hard',
            timeToCreate: '45 min'
          },
          {
            id: '4',
            type: 'text',
            platform: 'facebook',
            title: 'Customer Success Story',
            description: 'Share a testimonial or case study with engaging copy',
            reasoning: 'Facebook posts with customer stories generate 3x more engagement than promotional content',
            estimatedEngagement: 88,
            difficulty: 'easy',
            timeToCreate: '20 min'
          },
          {
            id: '5',
            type: 'image',
            platform: 'twitter',
            title: 'Infographic with Key Statistics',
            description: 'Visual data presentation with compelling statistics',
            reasoning: 'Twitter users engage 2.5x more with visual content, especially data-driven posts',
            estimatedEngagement: 75,
            difficulty: 'medium',
            timeToCreate: '25 min'
          }
        ];
        
        setRecommendations(mockRecommendations);
      } catch (error) {
        console.error('Failed to generate recommendations:', error);
      } finally {
        setLoading(false);
      }
    }, 1000); // Simulate 1 second delay
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'text': return DocumentTextIcon;
      case 'image': return PhotoIcon;
      case 'video': return VideoCameraIcon;
      default: return DocumentTextIcon;
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'hard': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getPlatformIcon = (platform: string) => {
    const platformIcons: { [key: string]: string } = {
      facebook: '📘',
      instagram: '📷',
      twitter: '🐦',
      linkedin: '💼',
      youtube: '📺',
      tiktok: '🎵',
      google_ads: '🔍',
      tabula: '📊',
      outbrain: '🧠',
      email: '📧',
      blog: '📝'
    };
    return platformIcons[platform] || '📱';
  };

  if (!business) {
    return (
      <div className="bg-white rounded-lg border border-secondary-200 p-6">
        <div className="text-center text-secondary-500">
          <SparklesIcon className="h-12 w-12 mx-auto mb-3 text-secondary-400" />
          <p>Select a business to get AI-powered content recommendations</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-secondary-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-primary-100 rounded-lg">
            <SparklesIcon className="h-6 w-6 text-primary-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-secondary-900">
              AI Content Recommendations
            </h3>
            <p className="text-sm text-secondary-600">
              Personalized suggestions for {business.name}
            </p>
          </div>
        </div>
        <Button
          variant="secondary"
          size="sm"
          onClick={generateRecommendations}
          disabled={loading}
          leftIcon={loading ? undefined : <ArrowPathIcon className="h-4 w-4" />}
        >
          {loading ? 'Generating...' : 'Refresh'}
        </Button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
          <span className="ml-3 text-secondary-600">Generating recommendations...</span>
        </div>
      ) : (
        <div className="space-y-4">
          {recommendations.map((recommendation) => {
            const TypeIcon = getTypeIcon(recommendation.type);
            const isExpanded = expandedRecommendation === recommendation.id;
            
            return (
              <div
                key={recommendation.id}
                className="border border-secondary-200 rounded-lg p-4 hover:border-primary-300 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3 flex-1">
                    <div className="flex items-center space-x-2">
                      <div className="p-2 bg-secondary-100 rounded-lg">
                        <TypeIcon className="h-4 w-4 text-secondary-600" />
                      </div>
                      <span className="text-2xl">{getPlatformIcon(recommendation.platform)}</span>
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h4 className="font-medium text-secondary-900">
                          {recommendation.title}
                        </h4>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(recommendation.difficulty)}`}>
                          {recommendation.difficulty}
                        </span>
                      </div>
                      
                      <p className="text-sm text-secondary-600 mb-2">
                        {recommendation.description}
                      </p>
                      
                      <div className="flex items-center space-x-4 text-xs text-secondary-500">
                        <span>📊 {recommendation.estimatedEngagement}% engagement</span>
                        <span>⏱️ {recommendation.timeToCreate}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setExpandedRecommendation(isExpanded ? null : recommendation.id)}
                    >
                      <EyeIcon className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => onSelectRecommendation(recommendation)}
                      leftIcon={<ClipboardDocumentIcon className="h-4 w-4" />}
                    >
                      Use This
                    </Button>
                  </div>
                </div>
                
                {isExpanded && (
                  <div className="mt-4 pt-4 border-t border-secondary-200">
                    <div className="flex items-start space-x-2">
                      <LightBulbIcon className="h-4 w-4 text-yellow-500 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-secondary-900 mb-1">
                          Why this works for your business:
                        </p>
                        <p className="text-sm text-secondary-600">
                          {recommendation.reasoning}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
      
      {recommendations.length === 0 && !loading && (
        <div className="text-center py-8 text-secondary-500">
          <SparklesIcon className="h-12 w-12 mx-auto mb-3 text-secondary-400" />
          <p>No recommendations available. Try refreshing or check your business settings.</p>
        </div>
      )}
    </div>
  );
} 