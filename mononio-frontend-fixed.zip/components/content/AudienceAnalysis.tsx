'use client';

import { useState, useEffect } from 'react';
import { Business } from '@/types';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import {
  UsersIcon,
  ChartBarIcon,
  MagnifyingGlassIcon,
  PencilIcon,
  CheckIcon,
  XMarkIcon,
  PlusIcon,
  TrashIcon,
  EyeIcon,
  GlobeAltIcon,
  CalendarIcon,
  CurrencyDollarIcon,
  AcademicCapIcon,
  HomeIcon,
} from '@heroicons/react/24/outline';

interface AudienceSegment {
  id: string;
  name: string;
  description: string;
  demographics: {
    ageRange: string;
    gender: string;
    location: string;
    income: string;
    education: string;
  };
  interests: string[];
  behaviors: string[];
  size: number; // Estimated audience size
  engagement: number; // Estimated engagement rate
}

interface AudienceInsights {
  primaryAudience: AudienceSegment;
  secondaryAudiences: AudienceSegment[];
  keyInsights: string[];
  recommendedPlatforms: string[];
  engagementPredictions: {
    platform: string;
    engagement: number;
    reasoning: string;
  }[];
}

interface AudienceAnalysisProps {
  business: Business | null;
  onSelectAudience: (audience: AudienceSegment) => void;
  onGenerateAnalysis: () => void;
}

export default function AudienceAnalysis({ 
  business, 
  onSelectAudience, 
  onGenerateAnalysis 
}: AudienceAnalysisProps) {
  const [insights, setInsights] = useState<AudienceInsights | null>(null);
  const [loading, setLoading] = useState(false);
  const [showManualSegment, setShowManualSegment] = useState(false);
  const [manualSegment, setManualSegment] = useState<Partial<AudienceSegment>>({
    name: '',
    description: '',
    demographics: {
      ageRange: '',
      gender: '',
      location: '',
      income: '',
      education: ''
    },
    interests: [],
    behaviors: []
  });
  const [newInterest, setNewInterest] = useState('');
  const [newBehavior, setNewBehavior] = useState('');

  useEffect(() => {
    if (business) {
      generateAudienceAnalysis();
    }
  }, [business]);

  const generateAudienceAnalysis = () => {
    if (!business) return;
    
    setLoading(true);
    
    // Simulate async operation with setTimeout
    setTimeout(() => {
      try {
        // Mock audience analysis for now - will be replaced with API call
        const mockInsights: AudienceInsights = {
          primaryAudience: {
            id: 'primary',
            name: 'Primary Target Audience',
            description: `Professionals in the ${business.industry} industry`,
            demographics: {
              ageRange: '25-45',
              gender: 'All',
              location: business.location,
              income: '$50K-$150K',
              education: 'Bachelor\'s degree or higher'
            },
            interests: [
              'Professional development',
              'Industry trends',
              'Technology',
              'Business growth',
              'Networking'
            ],
            behaviors: [
              'Active on LinkedIn',
              'Reads industry publications',
              'Attends professional events',
              'Makes business decisions',
              'Values quality and expertise'
            ],
            size: 250000,
            engagement: 78
          },
          secondaryAudiences: [
            {
              id: 'secondary-1',
              name: 'Young Professionals',
              description: 'Early-career professionals looking to grow',
              demographics: {
                ageRange: '22-30',
                gender: 'All',
                location: business.location,
                income: '$30K-$70K',
                education: 'Bachelor\'s degree'
              },
              interests: [
                'Career advancement',
                'Skill development',
                'Social media',
                'Innovation',
                'Work-life balance'
              ],
              behaviors: [
                'Active on social media',
                'Seeks mentorship',
                'Values authenticity',
                'Prefers mobile-first content',
                'Engages with educational content'
              ],
              size: 180000,
              engagement: 82
            },
            {
              id: 'secondary-2',
              name: 'Decision Makers',
              description: 'Senior professionals and executives',
              demographics: {
                ageRange: '35-55',
                gender: 'All',
                location: business.location,
                income: '$100K+',
                education: 'Advanced degree'
              },
              interests: [
                'Strategic planning',
                'Leadership',
                'Industry insights',
                'ROI and efficiency',
                'Professional networking'
              ],
              behaviors: [
                'Makes purchasing decisions',
                'Values data-driven insights',
                'Prefers professional content',
                'Engages with thought leadership',
                'Attends high-level events'
              ],
              size: 75000,
              engagement: 71
            }
          ],
          keyInsights: [
            `Your ${business.industry} industry audience is highly engaged on LinkedIn and professional platforms`,
            'Visual content performs 40% better than text-only posts for your target demographic',
            'Educational content drives 3x more engagement than promotional content',
            'Your audience values authenticity and industry expertise over sales pitches',
            'Mobile-first content strategy is crucial for reaching your target audience'
          ],
          recommendedPlatforms: ['LinkedIn', 'Instagram', 'YouTube', 'Facebook', 'Twitter'],
          engagementPredictions: [
            {
              platform: 'LinkedIn',
              engagement: 85,
              reasoning: 'Professional audience highly active on LinkedIn'
            },
            {
              platform: 'Instagram',
              engagement: 78,
              reasoning: 'Visual content performs well with your demographic'
            },
          {
            platform: 'YouTube',
            engagement: 72,
            reasoning: 'Educational video content drives high engagement'
          },
          {
            platform: 'Facebook',
            engagement: 65,
            reasoning: 'Good for community building and brand awareness'
          },
          {
            platform: 'Twitter',
            engagement: 58,
            reasoning: 'Useful for industry conversations and thought leadership'
          }
        ]
      };
      
        setInsights(mockInsights);
      } catch (error) {
        console.error('Failed to generate audience analysis:', error);
      } finally {
        setLoading(false);
      }
    }, 1500); // Simulate 1.5 second delay
  };

  const handleCreateManualSegment = () => {
    if (!manualSegment.name || !manualSegment.description) {
      return;
    }

    const newSegment: AudienceSegment = {
      id: `manual-${Date.now()}`,
      name: manualSegment.name,
      description: manualSegment.description,
      demographics: manualSegment.demographics as any,
      interests: manualSegment.interests || [],
      behaviors: manualSegment.behaviors || [],
      size: 50000, // Default size
      engagement: 70 // Default engagement
    };

    // Add to insights
    if (insights) {
      setInsights({
        ...insights,
        secondaryAudiences: [...insights.secondaryAudiences, newSegment]
      });
    }

    // Reset form
    setManualSegment({
      name: '',
      description: '',
      demographics: {
        ageRange: '',
        gender: '',
        location: '',
        income: '',
        education: ''
      },
      interests: [],
      behaviors: []
    });
    setShowManualSegment(false);
  };

  const addInterest = () => {
    if (newInterest.trim()) {
      setManualSegment(prev => ({
        ...prev,
        interests: [...(prev.interests || []), newInterest.trim()]
      }));
      setNewInterest('');
    }
  };

  const addBehavior = () => {
    if (newBehavior.trim()) {
      setManualSegment(prev => ({
        ...prev,
        behaviors: [...(prev.behaviors || []), newBehavior.trim()]
      }));
      setNewBehavior('');
    }
  };

  const removeInterest = (index: number) => {
    setManualSegment(prev => ({
      ...prev,
      interests: prev.interests?.filter((_, i) => i !== index) || []
    }));
  };

  const removeBehavior = (index: number) => {
    setManualSegment(prev => ({
      ...prev,
      behaviors: prev.behaviors?.filter((_, i) => i !== index) || []
    }));
  };

  if (!business) {
    return (
      <div className="bg-white rounded-lg border border-secondary-200 p-6">
        <div className="text-center text-secondary-500">
          <UsersIcon className="h-12 w-12 mx-auto mb-3 text-secondary-400" />
          <p>Select a business to analyze audience insights</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-secondary-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-100 rounded-lg">
            <UsersIcon className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-secondary-900">
              Audience Analysis
            </h3>
            <p className="text-sm text-secondary-600">
              AI-powered insights for {business.name}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => setShowManualSegment(!showManualSegment)}
            leftIcon={<PlusIcon className="h-4 w-4" />}
          >
            Add Segment
          </Button>
          <Button
            variant="secondary"
            size="sm"
            onClick={generateAudienceAnalysis}
            disabled={loading}
            leftIcon={<ChartBarIcon className="h-4 w-4" />}
          >
            {loading ? 'Analyzing...' : 'Refresh'}
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-3 text-secondary-600">Analyzing audience...</span>
        </div>
      ) : insights ? (
        <div className="space-y-6">
          {/* Primary Audience */}
          <div className="border border-blue-200 rounded-lg p-4 bg-blue-50">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-semibold text-blue-900">{insights.primaryAudience.name}</h4>
              <Button
                size="sm"
                onClick={() => onSelectAudience(insights.primaryAudience)}
                leftIcon={<EyeIcon className="h-4 w-4" />}
              >
                Use This Audience
              </Button>
            </div>
            <p className="text-sm text-blue-700 mb-3">{insights.primaryAudience.description}</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="font-medium text-blue-800">Age:</span>
                <p className="text-blue-700">{insights.primaryAudience.demographics.ageRange}</p>
              </div>
              <div>
                <span className="font-medium text-blue-800">Location:</span>
                <p className="text-blue-700">{insights.primaryAudience.demographics.location}</p>
              </div>
              <div>
                <span className="font-medium text-blue-800">Size:</span>
                <p className="text-blue-700">{insights.primaryAudience.size.toLocaleString()}</p>
              </div>
              <div>
                <span className="font-medium text-blue-800">Engagement:</span>
                <p className="text-blue-700">{insights.primaryAudience.engagement}%</p>
              </div>
            </div>
          </div>

          {/* Key Insights */}
          <div>
            <h4 className="font-semibold text-secondary-900 mb-3">Key Insights</h4>
            <div className="space-y-2">
              {insights.keyInsights.map((insight, index) => (
                <div key={index} className="flex items-start space-x-2 p-3 bg-secondary-50 rounded-lg">
                  <MagnifyingGlassIcon className="h-4 w-4 text-secondary-500 mt-0.5" />
                  <p className="text-sm text-secondary-700">{insight}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Platform Predictions */}
          <div>
            <h4 className="font-semibold text-secondary-900 mb-3">Platform Performance Predictions</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {insights.engagementPredictions.map((prediction, index) => (
                <div key={index} className="p-3 border border-secondary-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-secondary-900">{prediction.platform}</span>
                    <span className="text-sm font-semibold text-primary-600">{prediction.engagement}%</span>
                  </div>
                  <p className="text-xs text-secondary-600">{prediction.reasoning}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Secondary Audiences */}
          <div>
            <h4 className="font-semibold text-secondary-900 mb-3">Additional Audience Segments</h4>
            <div className="space-y-3">
              {insights.secondaryAudiences.map((audience) => (
                <div key={audience.id} className="border border-secondary-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="font-medium text-secondary-900">{audience.name}</h5>
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => onSelectAudience(audience)}
                      leftIcon={<EyeIcon className="h-4 w-4" />}
                    >
                      Use This
                    </Button>
                  </div>
                  <p className="text-sm text-secondary-600 mb-2">{audience.description}</p>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div>
                      <span className="font-medium text-secondary-700">Age:</span>
                      <p className="text-secondary-600">{audience.demographics.ageRange}</p>
                    </div>
                    <div>
                      <span className="font-medium text-secondary-700">Size:</span>
                      <p className="text-secondary-600">{audience.size.toLocaleString()}</p>
                    </div>
                    <div>
                      <span className="font-medium text-secondary-700">Engagement:</span>
                      <p className="text-secondary-600">{audience.engagement}%</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Manual Segment Creation */}
          {showManualSegment && (
            <div className="border border-primary-200 rounded-lg p-4 bg-primary-50">
              <h4 className="font-semibold text-primary-900 mb-4">Create Custom Audience Segment</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <Input
                  label="Segment Name"
                  value={manualSegment.name}
                  onChange={(e) => setManualSegment(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g., High-Value Customers"
                />
                <Input
                  label="Description"
                  value={manualSegment.description}
                  onChange={(e) => setManualSegment(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe this audience segment"
                />
              </div>

              <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-4">
                <Input
                  label="Age Range"
                  value={manualSegment.demographics?.ageRange}
                  onChange={(e) => setManualSegment(prev => ({ 
                    ...prev, 
                    demographics: { ...prev.demographics!, ageRange: e.target.value }
                  }))}
                  placeholder="e.g., 25-45"
                />
                <Input
                  label="Gender"
                  value={manualSegment.demographics?.gender}
                  onChange={(e) => setManualSegment(prev => ({ 
                    ...prev, 
                    demographics: { ...prev.demographics!, gender: e.target.value }
                  }))}
                  placeholder="e.g., All, Male, Female"
                />
                <Input
                  label="Location"
                  value={manualSegment.demographics?.location}
                  onChange={(e) => setManualSegment(prev => ({ 
                    ...prev, 
                    demographics: { ...prev.demographics!, location: e.target.value }
                  }))}
                  placeholder="e.g., San Francisco, CA"
                />
                <Input
                  label="Income"
                  value={manualSegment.demographics?.income}
                  onChange={(e) => setManualSegment(prev => ({ 
                    ...prev, 
                    demographics: { ...prev.demographics!, income: e.target.value }
                  }))}
                  placeholder="e.g., $50K-$100K"
                />
                <Input
                  label="Education"
                  value={manualSegment.demographics?.education}
                  onChange={(e) => setManualSegment(prev => ({ 
                    ...prev, 
                    demographics: { ...prev.demographics!, education: e.target.value }
                  }))}
                  placeholder="e.g., Bachelor's degree"
                />
              </div>

              {/* Interests */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-secondary-700 mb-2">Interests</label>
                <div className="flex space-x-2 mb-2">
                  <Input
                    value={newInterest}
                    onChange={(e) => setNewInterest(e.target.value)}
                    placeholder="Add interest"
                    className="flex-1"
                  />
                  <Button size="sm" onClick={addInterest} leftIcon={<PlusIcon className="h-4 w-4" />}>
                    Add
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {manualSegment.interests?.map((interest, index) => (
                    <span key={index} className="flex items-center space-x-1 px-2 py-1 bg-secondary-100 rounded-full text-sm">
                      <span>{interest}</span>
                      <button onClick={() => removeInterest(index)}>
                        <XMarkIcon className="h-3 w-3 text-secondary-500" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              {/* Behaviors */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-secondary-700 mb-2">Behaviors</label>
                <div className="flex space-x-2 mb-2">
                  <Input
                    value={newBehavior}
                    onChange={(e) => setNewBehavior(e.target.value)}
                    placeholder="Add behavior"
                    className="flex-1"
                  />
                  <Button size="sm" onClick={addBehavior} leftIcon={<PlusIcon className="h-4 w-4" />}>
                    Add
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {manualSegment.behaviors?.map((behavior, index) => (
                    <span key={index} className="flex items-center space-x-1 px-2 py-1 bg-secondary-100 rounded-full text-sm">
                      <span>{behavior}</span>
                      <button onClick={() => removeBehavior(index)}>
                        <XMarkIcon className="h-3 w-3 text-secondary-500" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex space-x-2">
                <Button onClick={handleCreateManualSegment} leftIcon={<CheckIcon className="h-4 w-4" />}>
                  Create Segment
                </Button>
                <Button 
                  variant="secondary" 
                  onClick={() => setShowManualSegment(false)}
                  leftIcon={<XMarkIcon className="h-4 w-4" />}
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="text-center py-8 text-secondary-500">
          <UsersIcon className="h-12 w-12 mx-auto mb-3 text-secondary-400" />
          <p>No audience analysis available. Try refreshing or check your business settings.</p>
        </div>
      )}
    </div>
  );
} 