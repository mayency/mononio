'use client';

import { useEffect, useState } from 'react';
import { useAuthStore } from '@/store/auth';

interface AuthProviderProps {
  children: React.ReactNode;
}

/**
 * AuthProvider blocks rendering only until Zustand store hydration is complete.
 * After hydration, it always renders children, regardless of auth state.
 * Use ProtectedRoute for actual route protection.
 */
export default function AuthProvider({ children }: AuthProviderProps) {
  const { initialize, _hasHydrated } = useAuthStore();
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    initialize();
  }, [initialize]);

  // Only block rendering until hydration is done
  if (!isClient || !_hasHydrated) {
    return (
      <div className="flex h-screen bg-gray-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
} 