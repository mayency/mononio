'use client';

import { useState, useEffect } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  ClockIcon,
  EyeIcon,
  CursorArrowRaysIcon,
  CurrencyDollarIcon,
} from '@heroicons/react/24/outline';

interface PerformanceMetric {
  timestamp: string;
  impressions: number;
  clicks: number;
  conversions: number;
  cost: number;
  revenue: number;
  ctr: number;
  conversion_rate: number;
  cpc: number;
  roi: number;
}

interface Alert {
  id: string;
  type: 'warning' | 'error' | 'success' | 'info';
  message: string;
  timestamp: string;
  campaign_id?: number;
  campaign_name?: string;
}

interface PerformanceMonitorProps {
  campaignId?: number;
  refreshInterval?: number;
  showAlerts?: boolean;
}

export default function PerformanceMonitor({
  campaignId,
  refreshInterval = 30000,
  showAlerts = true,
}: PerformanceMonitorProps) {
  const [metrics, setMetrics] = useState<PerformanceMetric[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const [isLive, setIsLive] = useState(true);

  // Mock real-time data generation
  const generateMockMetrics = (): PerformanceMetric => {
    const now = new Date();
    const baseImpressions = 1000 + Math.random() * 500;
    const baseClicks = baseImpressions * (0.05 + Math.random() * 0.1);
    const baseConversions = baseClicks * (0.02 + Math.random() * 0.05);
    const baseCost = baseClicks * (0.5 + Math.random() * 1);
    const baseRevenue = baseConversions * (20 + Math.random() * 30);

    return {
      timestamp: now.toISOString(),
      impressions: Math.round(baseImpressions),
      clicks: Math.round(baseClicks),
      conversions: Math.round(baseConversions),
      cost: Math.round(baseCost * 100) / 100,
      revenue: Math.round(baseRevenue * 100) / 100,
      ctr: Math.round((baseClicks / baseImpressions) * 10000) / 100,
      conversion_rate: Math.round((baseConversions / baseClicks) * 10000) / 100,
      cpc: Math.round((baseCost / baseClicks) * 100) / 100,
      roi: Math.round(((baseRevenue - baseCost) / baseCost) * 10000) / 100,
    };
  };

  const generateAlerts = (metrics: PerformanceMetric[]): Alert[] => {
    const newAlerts: Alert[] = [];
    const latestMetric = metrics[metrics.length - 1];
    
    if (!latestMetric) return newAlerts;

    // Check for performance issues
    if (latestMetric.ctr < 1) {
      newAlerts.push({
        id: `ctr-${Date.now()}`,
        type: 'warning',
        message: `Low CTR detected: ${latestMetric.ctr}%`,
        timestamp: new Date().toISOString(),
        campaign_id: campaignId,
        campaign_name: 'Campaign Name',
      });
    }

    if (latestMetric.conversion_rate < 1) {
      newAlerts.push({
        id: `conv-${Date.now()}`,
        type: 'warning',
        message: `Low conversion rate: ${latestMetric.conversion_rate}%`,
        timestamp: new Date().toISOString(),
        campaign_id: campaignId,
        campaign_name: 'Campaign Name',
      });
    }

    if (latestMetric.cpc > 5) {
      newAlerts.push({
        id: `cpc-${Date.now()}`,
        type: 'error',
        message: `High CPC detected: $${latestMetric.cpc}`,
        timestamp: new Date().toISOString(),
        campaign_id: campaignId,
        campaign_name: 'Campaign Name',
      });
    }

    if (latestMetric.roi > 200) {
      newAlerts.push({
        id: `roi-${Date.now()}`,
        type: 'success',
        message: `Excellent ROI: ${latestMetric.roi}%`,
        timestamp: new Date().toISOString(),
        campaign_id: campaignId,
        campaign_name: 'Campaign Name',
      });
    }

    return newAlerts;
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Generate initial data
        const initialMetrics = Array.from({ length: 20 }, () => generateMockMetrics());
        setMetrics(initialMetrics);
        setLoading(false);

        // Set up real-time updates
        if (isLive) {
          const interval = setInterval(() => {
            const newMetric = generateMockMetrics();
            setMetrics(prev => {
              const updated = [...prev, newMetric];
              // Keep only last 50 data points
              return updated.slice(-50);
            });

            // Generate alerts
            const newAlerts = generateAlerts([newMetric]);
            if (newAlerts.length > 0) {
              setAlerts(prev => [...newAlerts, ...prev.slice(0, 9)]); // Keep last 10 alerts
            }
          }, refreshInterval);

          return () => clearInterval(interval);
        }
      } catch (error) {
        console.error('Failed to fetch performance data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, [campaignId, refreshInterval, isLive]);

  const getAlertIcon = (type: Alert['type']) => {
    switch (type) {
      case 'warning':
        return <ExclamationTriangleIcon className="w-4 h-4 text-warning-500" />;
      case 'error':
        return <ExclamationTriangleIcon className="w-4 h-4 text-danger-500" />;
      case 'success':
        return <CheckCircleIcon className="w-4 h-4 text-success-500" />;
      case 'info':
        return <ClockIcon className="w-4 h-4 text-info-500" />;
    }
  };

  const getAlertColor = (type: Alert['type']) => {
    switch (type) {
      case 'warning':
        return 'border-warning-200 bg-warning-50';
      case 'error':
        return 'border-danger-200 bg-danger-50';
      case 'success':
        return 'border-success-200 bg-success-50';
      case 'info':
        return 'border-info-200 bg-info-50';
    }
  };

  const currentMetrics = metrics[metrics.length - 1];
  const previousMetrics = metrics[metrics.length - 2];

  const calculateChange = (current: number, previous: number) => {
    if (previous === 0) return 0;
    return ((current - previous) / previous) * 100;
  };

  const metricCards = [
    {
      name: 'Impressions',
      value: currentMetrics?.impressions || 0,
      change: previousMetrics ? calculateChange(currentMetrics?.impressions || 0, previousMetrics.impressions) : 0,
      icon: EyeIcon,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
    },
    {
      name: 'Clicks',
      value: currentMetrics?.clicks || 0,
      change: previousMetrics ? calculateChange(currentMetrics?.clicks || 0, previousMetrics.clicks) : 0,
      icon: CursorArrowRaysIcon,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
    },
    {
      name: 'Conversions',
      value: currentMetrics?.conversions || 0,
      change: previousMetrics ? calculateChange(currentMetrics?.conversions || 0, previousMetrics.conversions) : 0,
      icon: ArrowTrendingUpIcon,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100',
    },
    {
      name: 'Revenue',
      value: `$${(currentMetrics?.revenue || 0).toLocaleString()}`,
      change: previousMetrics ? calculateChange(currentMetrics?.revenue || 0, previousMetrics.revenue) : 0,
      icon: CurrencyDollarIcon,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-100',
    },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Live Status */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className={`w-3 h-3 rounded-full ${isLive ? 'bg-success-500 animate-pulse' : 'bg-secondary-400'}`} />
          <span className="text-sm font-medium text-secondary-900">
            {isLive ? 'Live Monitoring' : 'Paused'}
          </span>
        </div>
        <button
          onClick={() => setIsLive(!isLive)}
          className={`px-3 py-1 text-sm rounded-full ${
            isLive
              ? 'bg-success-100 text-success-700 hover:bg-success-200'
              : 'bg-secondary-100 text-secondary-700 hover:bg-secondary-200'
          }`}
        >
          {isLive ? 'Pause' : 'Resume'}
        </button>
      </div>

      {/* Real-time Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {metricCards.map((metric) => (
          <div key={metric.name} className="bg-white rounded-lg border border-secondary-200 p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-secondary-600">{metric.name}</p>
                <p className="text-2xl font-bold text-secondary-900">{metric.value}</p>
                <div className="flex items-center mt-1">
                  {metric.change > 0 ? (
                    <ArrowTrendingUpIcon className="w-4 h-4 text-success-500 mr-1" />
                  ) : (
                    <ArrowTrendingDownIcon className="w-4 h-4 text-danger-500 mr-1" />
                  )}
                  <span
                    className={`text-sm ${
                      metric.change > 0 ? 'text-success-600' : 'text-danger-600'
                    }`}
                  >
                    {Math.abs(metric.change).toFixed(1)}%
                  </span>
                </div>
              </div>
              <div className={`h-12 w-12 ${metric.bgColor} rounded-lg flex items-center justify-center`}>
                <metric.icon className={`h-6 w-6 ${metric.color}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Performance Chart */}
      <div className="bg-white rounded-lg border border-secondary-200 p-6">
        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Real-time Performance</h3>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart data={metrics}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis
              dataKey="timestamp"
              tickFormatter={(value) => new Date(value).toLocaleTimeString()}
            />
            <YAxis />
            <Tooltip
              labelFormatter={(value) => new Date(value).toLocaleString()}
              formatter={(value: any, name: string) => [
                typeof value === 'number' ? value.toLocaleString() : value,
                name.charAt(0).toUpperCase() + name.slice(1),
              ]}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="impressions"
              stroke="#3B82F6"
              strokeWidth={2}
              dot={false}
            />
            <Line
              type="monotone"
              dataKey="clicks"
              stroke="#10B981"
              strokeWidth={2}
              dot={false}
            />
            <Line
              type="monotone"
              dataKey="conversions"
              stroke="#8B5CF6"
              strokeWidth={2}
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Alerts */}
      {showAlerts && (
        <div className="bg-white rounded-lg border border-secondary-200 p-6">
          <h3 className="text-lg font-semibold text-secondary-900 mb-4">Live Alerts</h3>
          <div className="space-y-3">
            {alerts.length === 0 ? (
              <p className="text-secondary-500 text-center py-4">No alerts at the moment</p>
            ) : (
              alerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`flex items-start space-x-3 p-3 border rounded-lg ${getAlertColor(alert.type)}`}
                >
                  {getAlertIcon(alert.type)}
                  <div className="flex-1">
                    <p className="text-sm font-medium text-secondary-900">{alert.message}</p>
                    <p className="text-xs text-secondary-600">
                      {new Date(alert.timestamp).toLocaleString()}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Key Performance Indicators */}
      {currentMetrics && (
        <div className="bg-white rounded-lg border border-secondary-200 p-6">
          <h3 className="text-lg font-semibold text-secondary-900 mb-4">Key Performance Indicators</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <p className="text-sm text-secondary-600">CTR</p>
              <p className="text-2xl font-bold text-secondary-900">{currentMetrics.ctr}%</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-secondary-600">Conversion Rate</p>
              <p className="text-2xl font-bold text-secondary-900">{currentMetrics.conversion_rate}%</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-secondary-600">CPC</p>
              <p className="text-2xl font-bold text-secondary-900">${currentMetrics.cpc}</p>
            </div>
            <div className="text-center">
              <p className="text-sm text-secondary-600">ROI</p>
              <p className="text-2xl font-bold text-secondary-900">{currentMetrics.roi}%</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
} 