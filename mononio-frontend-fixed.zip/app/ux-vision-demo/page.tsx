'use client';

import { useState } from 'react';
import { InsightCard } from '@/components/insights/InsightCard';
import { Button } from '@/components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import Sidebar from '@/components/layout/Sidebar';
import {
  SparklesIcon,
  ArrowPathIcon,
  ChartBarIcon,
  CheckCircleIcon,
} from '@heroicons/react/24/outline';

export default function UXVisionDemo() {
  const [currentView, setCurrentView] = useState<'new' | 'old'>('new');
  
  // Sample data representing the new vision
  const newVisionInsights = [
    {
      question: "Are my ads working?",
      answer: "Yes! You spent $127 yesterday and got 5 new customers",
      trend: "up" as const,
      confidence: "high" as const,
      action: "Scale this campaign",
      actionUrl: "/campaigns/123/scale",
      priority: "important" as const,
      detailData: {
        explanation: "Your Facebook campaign has a 4.2x return on ad spend, which is excellent.",
        metrics: {
          "Ad spend": "$127",
          "New customers": "5",
          "Cost per customer": "$25.40",
          "ROAS": "4.2x"
        },
        recommendations: [
          "Increase daily budget by 20%",
          "Duplicate top-performing ad creative",
          "Expand to similar audiences"
        ]
      }
    },
    {
      question: "How's my customer growth?",
      answer: "Amazing! You gained 12 customers this week (+50% growth)",
      trend: "up" as const,
      confidence: "high" as const,
      action: "See what's driving growth",
      actionUrl: "/growth/analysis",
      detailData: {
        explanation: "Your customer acquisition is accelerating significantly, indicating strong market demand.",
        metrics: {
          "This week": "12 customers",
          "Last week": "8 customers", 
          "Growth rate": "+50%",
          "Total customers": "234"
        },
        recommendations: [
          "Identify what's driving this growth",
          "Scale successful acquisition channels",
          "Prepare infrastructure for growth"
        ]
      }
    },
    {
      question: "What needs my attention today?",
      answer: "7 customers left reviews - 2 need responses",
      trend: "neutral" as const,
      confidence: "high" as const,
      action: "Respond to reviews",
      actionUrl: "/reviews/pending",
      priority: "critical" as const,
      detailData: {
        explanation: "Responding to reviews quickly improves your reputation and shows customer care.",
        metrics: {
          "New reviews": "7",
          "Pending responses": "2",
          "Average rating": "4.8 ⭐",
          "Response rate": "85%"
        },
        recommendations: [
          "Respond within 24 hours",
          "Thank customers for positive reviews",
          "Address concerns professionally"
        ]
      }
    }
  ];

  // Sample data representing current complex view
  const currentComplexStats = [
    { name: 'Total Businesses', value: '15', change: '+12%' },
    { name: 'Active Campaigns', value: '8', change: '+8%' },
    { name: 'Total Leads', value: '247', change: '+23%' },
    { name: 'Total Revenue', value: '$12,450', change: '+15%' },
    { name: 'CTR', value: '4.2%', change: '+2.1%' },
    { name: 'CPC', value: '$0.37', change: '-5%' },
    { name: 'ROAS', value: '3.8x', change: '+12%' },
    { name: 'Conversion Rate', value: '2.8%', change: '+0.3%' }
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header with Vision Toggle */}
        <header className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                UX Vision Demo
              </h1>
              <p className="text-gray-600">
                Compare current analytics vs. "Brutal Simplicity, Instant Value" approach
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setCurrentView('new')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    currentView === 'new'
                      ? 'bg-white text-blue-700 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <SparklesIcon className="h-4 w-4 inline mr-2" />
                  New Vision
                </button>
                <button
                  onClick={() => setCurrentView('old')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    currentView === 'old'
                      ? 'bg-white text-gray-700 shadow-sm'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <ChartBarIcon className="h-4 w-4 inline mr-2" />
                  Current
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-6">
          {currentView === 'new' ? (
            <div>
              {/* New Vision: Story-Driven Dashboard */}
              <div className="mb-8">
                <div className="flex items-center space-x-3 mb-4">
                  <CheckCircleIcon className="h-6 w-6 text-green-600" />
                  <h2 className="text-xl font-semibold text-gray-900">
                    Your Business Dashboard
                  </h2>
                </div>
                <p className="text-gray-600 mb-6">
                  Here's what's happening with your business right now.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {newVisionInsights.map((insight, index) => (
                    <InsightCard key={index} {...insight} />
                  ))}
                </div>
              </div>

              {/* Progressive Disclosure Example */}
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <SparklesIcon className="h-5 w-5 text-blue-600" />
                    <span>AI-Powered Recommendations</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-blue-800 mb-3">
                      <strong>Smart Insight:</strong> Your Facebook ads are performing 3x better than industry average. 
                      Consider increasing budget from $100 to $150/day for maximum growth.
                    </p>
                    <Button variant="default" size="sm">
                      Implement Recommendation
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Design Principles */}
              <Card>
                <CardHeader>
                  <CardTitle>🎯 New Vision Principles in Action</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Question-Driven</h3>
                      <p className="text-sm text-gray-600">
                        Each card answers a specific business question instead of showing raw metrics.
                      </p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Natural Language</h3>
                      <p className="text-sm text-gray-600">
                        "You spent $127 and got 5 customers" vs "CTR: 4.2%, CPC: $0.37"
                      </p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Action-Oriented</h3>
                      <p className="text-sm text-gray-600">
                        Every insight includes a clear next step to improve business outcomes.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div>
              {/* Current Complex Dashboard */}
              <div className="mb-8">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">
                  Traditional Analytics Dashboard
                </h2>
                
                {/* Complex Stats Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                  {currentComplexStats.map((stat) => (
                    <div key={stat.name} className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                      <p className="text-sm text-gray-600">{stat.name}</p>
                      <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                      <p className="text-sm text-green-600">{stat.change}</p>
                    </div>
                  ))}
                </div>

                {/* Complex Charts Section */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                  <Card>
                    <CardHeader>
                      <CardTitle>Campaign Performance Over Time</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                        <div className="text-center text-gray-500">
                          <ChartBarIcon className="h-12 w-12 mx-auto mb-2" />
                          <p>Complex Line Chart</p>
                          <p className="text-sm">Multiple metrics, hard to interpret</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Conversion Funnel Analysis</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64 bg-gray-100 rounded-lg flex items-center justify-center">
                        <div className="text-center text-gray-500">
                          <ChartBarIcon className="h-12 w-12 mx-auto mb-2" />
                          <p>Funnel Chart</p>
                          <p className="text-sm">Technical metrics, no context</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Current Problems */}
              <Card>
                <CardHeader>
                  <CardTitle>❌ Current Approach Problems</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Overwhelming</h3>
                      <p className="text-sm text-gray-600">
                        8+ metrics, 4+ charts, multiple tabs. Users don't know where to focus.
                      </p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Technical Language</h3>
                      <p className="text-sm text-gray-600">
                        CTR, CPC, ROAS - SMB owners need translation into business impact.
                      </p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">No Clear Actions</h3>
                      <p className="text-sm text-gray-600">
                        Data without guidance. Users see numbers but don't know what to do next.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </main>
      </div>
    </div>
  );
} 