'use client';

import { useEffect, useState } from 'react';
import { useAuthStore } from '@/store/auth';
import { Business, Expense, ExpenseCreate } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import {
  CurrencyDollarIcon,
  PlusIcon,
  ChartBarIcon,
  DocumentTextIcon,
  CalendarIcon,
  BuildingOfficeIcon,
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  ReceiptRefundIcon,
  BanknotesIcon,
} from '@heroicons/react/24/outline';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import toast from 'react-hot-toast';

interface FinancialStats {
  totalRevenue: number;
  totalExpenses: number;
  netProfit: number;
  profitMargin: number;
  monthlyGrowth: number;
}

export default function FinancialsPage() {
  const { isAuthenticated } = useAuthStore();
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddExpense, setShowAddExpense] = useState(false);
  const [formData, setFormData] = useState<ExpenseCreate>({
    business_id: 0,
    amount: 0,
    category: '',
    description: '',
    date: new Date().toISOString().split('T')[0],
  });

  useEffect(() => {
    if (isAuthenticated) {
      fetchData();
    }
  }, [isAuthenticated]);

  const fetchData = async () => {
    try {
      const businessesData = await apiClient.getBusinesses();
      setBusinesses(businessesData);
      
      if (businessesData.length > 0) {
        setSelectedBusiness(businessesData[0]);
        await fetchExpenses(businessesData[0].id);
      }
    } catch (error) {
      console.error('Failed to fetch data:', error);
      toast.error('Failed to load financial data');
    } finally {
      setLoading(false);
    }
  };

  const fetchExpenses = async (businessId: number) => {
    try {
      const expensesData = await apiClient.getBusinessExpenses(businessId);
      setExpenses(expensesData);
    } catch (error) {
      console.error('Failed to fetch expenses:', error);
      toast.error('Failed to load expenses');
    }
  };

  const handleBusinessChange = async (businessId: number) => {
    const business = businesses.find(b => b.id === businessId);
    setSelectedBusiness(business || null);
    await fetchExpenses(businessId);
  };

  const handleAddExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBusiness) {
      toast.error('Please select a business');
      return;
    }
    
    if (!formData.amount || !formData.category || !formData.description) {
      toast.error('Please fill in all required fields');
      return;
    }
    
    setLoading(true);
    
    try {
      const newExpense = await apiClient.createExpense({
        ...formData,
        business_id: selectedBusiness.id,
      });
      
      setExpenses([...expenses, newExpense]);
      setShowAddExpense(false);
      setFormData({
        business_id: 0,
        amount: 0,
        category: '',
        description: '',
        date: new Date().toISOString().split('T')[0],
      });
      toast.success('Expense added successfully!');
    } catch (error: any) {
      toast.error(error.message || 'Failed to add expense');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (file: File) => {
    if (!selectedBusiness) {
      toast.error('Please select a business');
      return;
    }
    
    setLoading(true);
    
    try {
      const expense = await apiClient.uploadReceipt(selectedBusiness.id, file);
      setExpenses([...expenses, expense]);
      toast.success('Receipt uploaded successfully!');
    } catch (error: any) {
      toast.error('Failed to upload receipt');
    } finally {
      setLoading(false);
    }
  };

  // Calculate financial stats
  const calculateStats = (): FinancialStats => {
    const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    const totalRevenue = 50000; // Mock revenue data
    const netProfit = totalRevenue - totalExpenses;
    const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;
    const monthlyGrowth = 15.5; // Mock growth data
    
    return {
      totalRevenue,
      totalExpenses,
      netProfit,
      profitMargin,
      monthlyGrowth,
    };
  };

  const stats = calculateStats();

  // Sample data for charts
  const revenueData = [
    { month: 'Jan', revenue: 4000, expenses: 2500 },
    { month: 'Feb', revenue: 3500, expenses: 2200 },
    { month: 'Mar', revenue: 4500, expenses: 2800 },
    { month: 'Apr', revenue: 5000, expenses: 3000 },
    { month: 'May', revenue: 4800, expenses: 2900 },
    { month: 'Jun', revenue: 5200, expenses: 3200 },
  ];

  const expenseCategories = [
    { name: 'Marketing', value: 35, color: '#3B82F6' },
    { name: 'Office', value: 25, color: '#10B981' },
    { name: 'Software', value: 20, color: '#F59E0B' },
    { name: 'Travel', value: 15, color: '#EF4444' },
    { name: 'Other', value: 5, color: '#8B5CF6' },
  ];

  const expenseCategoriesList = [
    'Marketing',
    'Office Supplies',
    'Software Subscriptions',
    'Travel',
    'Utilities',
    'Insurance',
    'Professional Services',
    'Other',
  ];

  if (!isAuthenticated) {
    return <div>Please log in to access financial data.</div>;
  }

  return (
    <div className="flex h-screen bg-secondary-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-secondary-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-secondary-900">
                Financial Management
              </h1>
              <p className="text-secondary-600">
                Track expenses, revenue, and financial performance
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <select
                value={selectedBusiness?.id || ''}
                onChange={(e) => handleBusinessChange(Number(e.target.value))}
                className="block rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
              >
                {businesses.map((business) => (
                  <option key={business.id} value={business.id}>
                    {business.name}
                  </option>
                ))}
              </select>
              <Button
                onClick={() => setShowAddExpense(true)}
                leftIcon={<PlusIcon className="h-4 w-4" />}
              >
                Add Expense
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-6">
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Financial Overview */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                <div className="stat-card">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="stat-label">Total Revenue</p>
                      <p className="stat-value">${stats.totalRevenue.toLocaleString()}</p>
                      <p className="stat-change positive">
                        <ArrowTrendingUpIcon className="inline h-3 w-3 mr-1" />
                        +{stats.monthlyGrowth}%
                      </p>
                    </div>
                    <div className="h-12 w-12 bg-success-100 rounded-lg flex items-center justify-center">
                      <BanknotesIcon className="h-6 w-6 text-success-600" />
                    </div>
                  </div>
                </div>
                
                <div className="stat-card">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="stat-label">Total Expenses</p>
                      <p className="stat-value">${stats.totalExpenses.toLocaleString()}</p>
                      <p className="stat-change negative">
                        <ArrowTrendingDownIcon className="inline h-3 w-3 mr-1" />
                        +8.2%
                      </p>
                    </div>
                    <div className="h-12 w-12 bg-danger-100 rounded-lg flex items-center justify-center">
                      <ReceiptRefundIcon className="h-6 w-6 text-danger-600" />
                    </div>
                  </div>
                </div>
                
                <div className="stat-card">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="stat-label">Net Profit</p>
                      <p className="stat-value">${stats.netProfit.toLocaleString()}</p>
                      <p className="stat-change positive">
                        <ArrowTrendingUpIcon className="inline h-3 w-3 mr-1" />
                        +12.5%
                      </p>
                    </div>
                    <div className="h-12 w-12 bg-primary-100 rounded-lg flex items-center justify-center">
                      <CurrencyDollarIcon className="h-6 w-6 text-primary-600" />
                    </div>
                  </div>
                </div>
                
                <div className="stat-card">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="stat-label">Profit Margin</p>
                      <p className="stat-value">{stats.profitMargin.toFixed(1)}%</p>
                      <p className="stat-change positive">
                        <ArrowTrendingUpIcon className="inline h-3 w-3 mr-1" />
                        +2.1%
                      </p>
                    </div>
                    <div className="h-12 w-12 bg-warning-100 rounded-lg flex items-center justify-center">
                      <ChartBarIcon className="h-6 w-6 text-warning-600" />
                    </div>
                  </div>
                </div>
                
                <div className="stat-card">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="stat-label">Total Expenses</p>
                      <p className="stat-value">{expenses.length}</p>
                      <p className="stat-change positive">
                        <ArrowTrendingUpIcon className="inline h-3 w-3 mr-1" />
                        +5 this month
                      </p>
                    </div>
                    <div className="h-12 w-12 bg-secondary-100 rounded-lg flex items-center justify-center">
                      <DocumentTextIcon className="h-6 w-6 text-secondary-600" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Revenue vs Expenses</h3>
                    <p className="card-subtitle">Monthly financial performance</p>
                  </div>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={revenueData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="revenue" stroke="#22c55e" strokeWidth={2} />
                        <Line type="monotone" dataKey="expenses" stroke="#ef4444" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Expense Categories</h3>
                    <p className="card-subtitle">Breakdown by category</p>
                  </div>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={expenseCategories}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {expenseCategories.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Recent Expenses */}
              <div className="card">
                <div className="card-header">
                  <h3 className="card-title">Recent Expenses</h3>
                  <p className="card-subtitle">Latest expense transactions</p>
                </div>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-secondary-200">
                    <thead className="bg-secondary-50">
                      <tr>
                        <th className="table-header">Date</th>
                        <th className="table-header">Description</th>
                        <th className="table-header">Category</th>
                        <th className="table-header">Amount</th>
                        <th className="table-header">Business</th>
                        <th className="table-header">Receipt</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-secondary-200">
                      {expenses.slice(0, 10).map((expense) => (
                        <tr key={expense.id} className="hover:bg-secondary-50">
                          <td className="table-cell">
                            {new Date(expense.date).toLocaleDateString()}
                          </td>
                          <td className="table-cell">{expense.description}</td>
                          <td className="table-cell">
                            <span className="badge badge-secondary">{expense.category}</span>
                          </td>
                          <td className="table-cell font-medium">
                            ${expense.amount.toLocaleString()}
                          </td>
                          <td className="table-cell">
                            {businesses.find(b => b.id === expense.business_id)?.name}
                          </td>
                          <td className="table-cell">
                            {expense.receipt_url ? (
                              <a
                                href={expense.receipt_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-primary-600 hover:text-primary-500"
                              >
                                View
                              </a>
                            ) : (
                              <span className="text-secondary-400">-</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Add Expense Modal */}
      {showAddExpense && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-secondary-900 mb-4">
                Add New Expense
              </h2>
              <form onSubmit={handleAddExpense} className="space-y-4">
                <Input
                  label="Amount"
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) || 0 })}
                  required
                />
                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-1">
                    Category
                  </label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
                    required
                  >
                    <option value="">Select category</option>
                    {expenseCategoriesList.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>
                <Input
                  label="Description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                />
                <Input
                  label="Date"
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  required
                />
                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-1">
                    Receipt (Optional)
                  </label>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        handleFileUpload(file);
                      }
                    }}
                    className="block w-full text-sm text-secondary-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-primary-50 file:text-primary-700 hover:file:bg-primary-100"
                  />
                </div>
                <div className="flex space-x-3 pt-4">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => setShowAddExpense(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button type="submit" loading={loading} className="flex-1">
                    Add Expense
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
} 