'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import apiClient from '@/lib/api';

interface LandingPageData {
  page_id: string;
  title: string;
  html_content: string;
  css_styles: string;
  preview_url: string;
  created_at: string;
  metadata: any;
}

export default function LandingPagePreview() {
  const params = useParams();
  const pageId = params.pageId as string;
  const [pageData, setPageData] = useState<LandingPageData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchLandingPage = async () => {
      try {
        setIsLoading(true);
        const response = await apiClient.getLandingPage(pageId);
        
        if (response.success && response.landing_page) {
          // Transform the response to match our expected structure
          const transformedData: LandingPageData = {
            page_id: response.landing_page.id,
            title: `${response.landing_page.business_name} - Landing Page`,
            html_content: response.landing_page.html_content || '<h1>Landing Page Content</h1><p>Content not available</p>',
            // Use the actual CSS styles from the backend instead of hardcoded styles
            css_styles: response.landing_page.css_styles || `
              body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
              h1 { color: #333; }
              p { color: #666; line-height: 1.6; }
            `,
            preview_url: response.landing_page.live_url,
            created_at: response.landing_page.created_at,
            metadata: {
              business_name: response.landing_page.business_name,
              business_type: response.landing_page.business_type,
              status: response.landing_page.status
            }
          };
          setPageData(transformedData);
        } else {
          setError(response.error || 'Landing page not found');
        }
      } catch (err) {
        console.error('Error fetching landing page:', err);
        setError('Failed to load landing page');
      } finally {
        setIsLoading(false);
      }
    };

    if (pageId) {
      fetchLandingPage();
    }
  }, [pageId]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading landing page...</p>
        </div>
      </div>
    );
  }

  if (error || !pageData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Landing Page Not Found</h1>
          <p className="text-gray-600 mb-6">{error || 'The requested landing page could not be loaded.'}</p>
          <a
            href="/landing-pages"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
          >
            Back to Landing Pages
          </a>
        </div>
      </div>
    );
  }

  // Extract only the <body> content from the HTML (if needed)
  let bodyContent = pageData.html_content;
  if (bodyContent?.includes('<body')) {
    const match = bodyContent.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    if (match) {
      bodyContent = match[1];
    }
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Preview Header */}
      <div className="bg-gray-100 border-b border-gray-200 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-lg font-semibold text-gray-900">Landing Page Preview</h1>
            <span className="text-sm text-gray-600">ID: {pageData.page_id}</span>
          </div>
          <div className="flex items-center space-x-3">
            <a
              href="/landing-pages"
              className="text-sm text-blue-600 hover:text-blue-700"
            >
              Back to Dashboard
            </a>
            <button
              onClick={() => window.print()}
              className="text-sm text-gray-600 hover:text-gray-700"
            >
              Print
            </button>
          </div>
        </div>
      </div>

      {/* Inject backend CSS styles */}
      <style dangerouslySetInnerHTML={{ __html: pageData.css_styles || '' }} />

      {/* Render landing page content */}
      <div 
        className="w-full"
        dangerouslySetInnerHTML={{ __html: bodyContent }}
      />
    </div>
  );
} 