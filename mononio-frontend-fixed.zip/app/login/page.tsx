'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import { EnvelopeIcon, LockClosedIcon, EyeIcon, EyeSlashIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { getErrorMessage } from '@/lib/getErrorMessage';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const router = useRouter();
  const { login, isLoading, error, clearError } = useAuthStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('📝 Login Page: Form submitted with email:', email);
    clearError();

    if (!email || !password) {
      console.log('📝 Login Page: Missing email or password');
      toast.error('Please fill in all fields');
      return;
    }

    console.log('📝 Login Page: Calling auth store login method...');
    const success = await login(email, password);
    console.log('📝 Login Page: Login result:', success);
    
    if (success) {
      console.log('📝 Login Page: Login successful, redirecting to dashboard...');
      toast.success('Welcome to LaunchMate DIAMOND!');
      router.push('/dashboard');
    } else {
      console.log('📝 Login Page: Login failed, showing error...');
      toast.error(getErrorMessage(error) || 'Login failed. Please check your credentials.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-secondary-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <div className="mx-auto h-16 w-16 bg-gradient-to-r from-primary-600 to-primary-700 rounded-2xl flex items-center justify-center mb-6">
            <svg
              className="h-8 w-8 text-white"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M13 10V3L4 14h7v7l9-11h-7z"
              />
            </svg>
          </div>
          <h2 className="text-3xl font-bold text-secondary-900">
            Welcome back
          </h2>
          <p className="mt-2 text-sm text-secondary-600">
            Sign in to your LaunchMate DIAMOND account
          </p>
        </div>

        {/* Login Form */}
        <div className="bg-white rounded-2xl shadow-xl border border-secondary-200 p-8">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <Input
              label="Email address"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              leftIcon={<EnvelopeIcon />}
              required
            />

            <div className="relative">
              <Input
                label="Password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                leftIcon={<LockClosedIcon />}
                rightIcon={
                  <span className="text-secondary-400">
                    {showPassword ? <EyeSlashIcon /> : <EyeIcon />}
                  </span>
                }
                required
              />
            </div>

            {error && (
              <div className="bg-danger-50 border border-danger-200 rounded-lg p-3">
                <p className="text-sm text-danger-600">{error}</p>
              </div>
            )}

            <Button
              type="submit"
              className="w-full"
              loading={isLoading}
              disabled={isLoading}
            >
              Sign in
            </Button>
          </form>

          {/* Demo Credentials */}
          <div className="mt-6 p-4 bg-secondary-50 rounded-lg">
            <h4 className="text-sm font-medium text-secondary-900 mb-2">
              Demo Account
            </h4>
            <p className="text-xs text-secondary-600">
              Email: demo@launchmate.com
              <br />
              Password: demo123
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center">
          <p className="text-sm text-secondary-500">
            Don't have an account?{' '}
            <span className="font-medium text-primary-600">
              Sign up for free
            </span>
          </p>
        </div>
      </div>
    </div>
  );
} 