'use client';

import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Send, 
  Edit, 
  Eye, 
  BarChart3, 
  Clock, 
  Mail, 
  Users, 
  TrendingUp,
  AlertCircle,
  CheckCircle,
  PlayCircle,
  PauseCircle,
  Trash2,
  Calendar,
  Target,
  Zap,
  Filter,
  Download,
  RefreshCw,
  Lightbulb,
  Settings,
  ArrowRight,
  Copy,
  ExternalLink
} from 'lucide-react';

// Types
interface EmailCampaign {
  campaign_id: string;
  name: string;
  objective: string;
  platform: string;
  status: 'draft' | 'scheduled' | 'sending' | 'sent' | 'paused' | 'completed' | 'failed';
  content: {
    subject: string;
    body_html: string;
    body_text: string;
    preheader?: string;
    call_to_action?: string;
    call_to_action_url?: string;
  };
  audience: {
    segment_id: string;
    name: string;
    estimated_size: number;
    tags: string[];
  };
  scheduled_at?: string;
  sent_at?: string;
  created_at: string;
  performance?: {
    emails_sent: number;
    emails_delivered: number;
    opens: number;
    clicks: number;
    unsubscribes: number;
    bounces: number;
    open_rate: number;
    click_rate: number;
    ctr: number;
    unsubscribe_rate: number;
    bounce_rate: number;
    revenue: number;
  };
}

interface OptimizationRecommendation {
  type: string;
  priority: 'high' | 'medium' | 'low';
  issue: string;
  current_value: string;
  recommendation: string;
  suggested_actions: string[];
}

interface AudienceSegment {
  segment_id: string;
  name: string;
  platform: string;
  estimated_size: number;
  tags: string[];
}

export default function EmailCampaignsPage() {
  // State management
  const [campaigns, setCampaigns] = useState<EmailCampaign[]>([]);
  const [selectedCampaign, setSelectedCampaign] = useState<EmailCampaign | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showPerformanceModal, setShowPerformanceModal] = useState(false);
  const [showRecommendationsModal, setShowRecommendationsModal] = useState(false);
  const [audienceSegments, setAudienceSegments] = useState<AudienceSegment[]>([]);
  const [recommendations, setRecommendations] = useState<OptimizationRecommendation[]>([]);
  const [loading, setLoading] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Campaign creation form state
  const [formData, setFormData] = useState({
    name: '',
    objective: 'newsletter',
    platform: 'mailchimp',
    tone: 'professional',
    audience_segment: '',
    scheduled_at: '',
    business_info: {
      name: 'LaunchMate DIAMOND',
      industry: 'technology'
    },
    additional_context: {}
  });

  // Load initial data
  useEffect(() => {
    loadCampaigns();
    loadAudienceSegments();
  }, []);

  // API functions
  const loadCampaigns = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/email-campaigns');
      if (response.ok) {
        const data = await response.json();
        setCampaigns(data.campaigns || []);
      }
    } catch (error) {
      console.error('Failed to load campaigns:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadAudienceSegments = async () => {
    try {
      const response = await fetch('/api/email-campaigns/audience-segments');
      if (response.ok) {
        const data = await response.json();
        setAudienceSegments(data.segments || []);
      }
    } catch (error) {
      console.error('Failed to load audience segments:', error);
    }
  };

  const createCampaign = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/email-campaigns/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        const data = await response.json();
        setCampaigns([data.campaign, ...campaigns]);
        setShowCreateModal(false);
        setFormData({
          name: '',
          objective: 'newsletter',
          platform: 'mailchimp',
          tone: 'professional',
          audience_segment: '',
          scheduled_at: '',
          business_info: {
            name: 'LaunchMate DIAMOND',
            industry: 'technology'
          },
          additional_context: {}
        });
        
        // Show success toast
        showToast('Campaign created successfully!', 'success');
      } else {
        throw new Error('Failed to create campaign');
      }
    } catch (error) {
      console.error('Failed to create campaign:', error);
      showToast('Failed to create campaign', 'error');
    } finally {
      setLoading(false);
    }
  };

  const sendTestEmail = async (campaignId: string, testEmail: string) => {
    try {
      const response = await fetch(`/api/email-campaigns/${campaignId}/test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ test_email: testEmail })
      });

      if (response.ok) {
        showToast('Test email sent successfully!', 'success');
      } else {
        throw new Error('Failed to send test email');
      }
    } catch (error) {
      console.error('Failed to send test email:', error);
      showToast('Failed to send test email', 'error');
    }
  };

  const sendCampaign = async (campaignId: string) => {
    try {
      setLoading(true);
      const response = await fetch(`/api/email-campaigns/${campaignId}/send`, {
        method: 'POST'
      });

      if (response.ok) {
        await loadCampaigns(); // Refresh campaigns
        showToast('Campaign sent successfully!', 'success');
      } else {
        throw new Error('Failed to send campaign');
      }
    } catch (error) {
      console.error('Failed to send campaign:', error);
      showToast('Failed to send campaign', 'error');
    } finally {
      setLoading(false);
    }
  };

  const loadRecommendations = async (campaignId: string) => {
    try {
      const response = await fetch(`/api/email-campaigns/${campaignId}/recommendations`);
      if (response.ok) {
        const data = await response.json();
        setRecommendations(data.recommendations || []);
        setShowRecommendationsModal(true);
      }
    } catch (error) {
      console.error('Failed to load recommendations:', error);
    }
  };

  const generateWithAI = async () => {
    try {
      setLoading(true);
      
      // Generate campaign content using AI
      const response = await fetch('/api/email-campaigns/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          business_info: formData.business_info,
          objective: formData.objective,
          tone: formData.tone,
          additional_context: formData.additional_context
        })
      });

      if (response.ok) {
        const data = await response.json();
        
        // Update form with generated content
        setFormData(prev => ({
          ...prev,
          name: data.suggested_name || prev.name,
          additional_context: {
            ...prev.additional_context,
            generated_subject: data.content.subject,
            generated_body: data.content.body_html,
            generated_preheader: data.content.preheader
          }
        }));
        
        showToast('Content generated with AI!', 'success');
      }
    } catch (error) {
      console.error('Failed to generate content:', error);
      showToast('Failed to generate content', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Utility functions
  const showToast = (message: string, type: 'success' | 'error' | 'info') => {
    // In a real app, you'd use a proper toast library
    alert(`${type.toUpperCase()}: ${message}`);
  };

  const getStatusColor = (status: string) => {
    const colors = {
      draft: 'text-gray-600 bg-gray-100',
      scheduled: 'text-blue-600 bg-blue-100',
      sending: 'text-yellow-600 bg-yellow-100',
      sent: 'text-green-600 bg-green-100',
      paused: 'text-orange-600 bg-orange-100',
      completed: 'text-purple-600 bg-purple-100',
      failed: 'text-red-600 bg-red-100'
    };
    return colors[status as keyof typeof colors] || 'text-gray-600 bg-gray-100';
  };

  const getStatusIcon = (status: string) => {
    const icons = {
      draft: <Edit className="w-4 h-4" />,
      scheduled: <Clock className="w-4 h-4" />,
      sending: <PlayCircle className="w-4 h-4" />,
      sent: <CheckCircle className="w-4 h-4" />,
      paused: <PauseCircle className="w-4 h-4" />,
      completed: <CheckCircle className="w-4 h-4" />,
      failed: <AlertCircle className="w-4 h-4" />
    };
    return icons[status as keyof typeof icons] || <Edit className="w-4 h-4" />;
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat().format(num);
  };

  const formatPercentage = (num: number) => {
    return `${(num * 100).toFixed(1)}%`;
  };

  const filteredCampaigns = campaigns.filter(campaign => 
    filterStatus === 'all' || campaign.status === filterStatus
  );

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Mail className="w-8 h-8 text-blue-600" />
                Email Campaigns
              </h1>
              <p className="text-gray-600 mt-2">
                Create, manage, and track AI-powered email campaigns
              </p>
            </div>
            
            <div className="flex items-center gap-4">
              <button
                onClick={loadCampaigns}
                disabled={loading}
                className="flex items-center gap-2 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </button>
              
              <button
                onClick={() => setShowCreateModal(true)}
                className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Plus className="w-4 h-4" />
                Create Campaign
              </button>
            </div>
          </div>
          
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8">
            <div className="bg-white p-6 rounded-lg shadow-sm border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Campaigns</p>
                  <p className="text-2xl font-bold text-gray-900">{campaigns.length}</p>
                </div>
                <Mail className="w-8 h-8 text-blue-600" />
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Emails Sent</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {formatNumber(campaigns.reduce((sum, c) => sum + (c.performance?.emails_sent || 0), 0))}
                  </p>
                </div>
                <Send className="w-8 h-8 text-green-600" />
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Avg. Open Rate</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {formatPercentage(
                      campaigns.filter(c => c.performance).length > 0
                        ? campaigns.reduce((sum, c) => sum + (c.performance?.open_rate || 0), 0) / campaigns.filter(c => c.performance).length
                        : 0
                    )}
                  </p>
                </div>
                <Eye className="w-8 h-8 text-purple-600" />
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Revenue Generated</p>
                  <p className="text-2xl font-bold text-gray-900">
                    ${formatNumber(campaigns.reduce((sum, c) => sum + (c.performance?.revenue || 0), 0))}
                  </p>
                </div>
                <TrendingUp className="w-8 h-8 text-orange-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="mb-6 flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-gray-500" />
            <span className="text-sm text-gray-700">Filter by status:</span>
          </div>
          
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All Campaigns</option>
            <option value="draft">Draft</option>
            <option value="scheduled">Scheduled</option>
            <option value="sent">Sent</option>
            <option value="completed">Completed</option>
          </select>
        </div>

        {/* Campaigns List */}
        <div className="bg-white rounded-lg shadow-sm border overflow-hidden">
          <div className="p-6 border-b">
            <h2 className="text-lg font-semibold text-gray-900">Email Campaigns</h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Campaign
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Audience
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Performance
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredCampaigns.map((campaign) => (
                  <tr key={campaign.campaign_id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {campaign.name}
                        </div>
                        <div className="text-sm text-gray-500">
                          {campaign.content.subject}
                        </div>
                        <div className="text-xs text-gray-400 mt-1">
                          {campaign.objective} • {campaign.platform}
                        </div>
                      </div>
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(campaign.status)}`}>
                        {getStatusIcon(campaign.status)}
                        {campaign.status}
                      </span>
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {campaign.audience.name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {formatNumber(campaign.audience.estimated_size)} contacts
                      </div>
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap">
                      {campaign.performance ? (
                        <div className="text-sm">
                          <div className="text-gray-900">
                            {formatPercentage(campaign.performance.open_rate)} open rate
                          </div>
                          <div className="text-gray-500">
                            {formatNumber(campaign.performance.clicks)} clicks
                          </div>
                        </div>
                      ) : (
                        <span className="text-gray-400 text-sm">No data yet</span>
                      )}
                    </td>
                    
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        {campaign.status === 'draft' && (
                          <button
                            onClick={() => sendCampaign(campaign.campaign_id)}
                            className="text-green-600 hover:text-green-700"
                            title="Send Campaign"
                          >
                            <Send className="w-4 h-4" />
                          </button>
                        )}
                        
                        <button
                          onClick={() => {
                            setSelectedCampaign(campaign);
                            setShowPerformanceModal(true);
                          }}
                          className="text-blue-600 hover:text-blue-700"
                          title="View Performance"
                        >
                          <BarChart3 className="w-4 h-4" />
                        </button>
                        
                        {campaign.performance && (
                          <button
                            onClick={() => loadRecommendations(campaign.campaign_id)}
                            className="text-purple-600 hover:text-purple-700"
                            title="Get Recommendations"
                          >
                            <Lightbulb className="w-4 h-4" />
                          </button>
                        )}
                        
                        <button
                          onClick={() => setSelectedCampaign(campaign)}
                          className="text-gray-600 hover:text-gray-700"
                          title="View Details"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            {filteredCampaigns.length === 0 && (
              <div className="text-center py-12">
                <Mail className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No campaigns found</h3>
                <p className="text-gray-600 mb-4">Get started by creating your first email campaign.</p>
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4" />
                  Create Campaign
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Create Campaign Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-gray-900">Create Email Campaign</h2>
                  <button
                    onClick={() => setShowCreateModal(false)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    ×
                  </button>
                </div>
              </div>
              
              <div className="p-6 space-y-6">
                {/* AI Generate Button */}
                <div className="text-center py-4 border-2 border-dashed border-blue-300 rounded-lg bg-blue-50">
                  <button
                    onClick={generateWithAI}
                    disabled={loading}
                    className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  >
                    <Zap className="w-4 h-4" />
                    {loading ? 'Generating...' : 'Generate with AI'}
                  </button>
                  <p className="text-sm text-blue-600 mt-2">
                    Let AI create your campaign content automatically
                  </p>
                </div>
                
                {/* Campaign Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Campaign Name
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter campaign name"
                  />
                </div>
                
                {/* Campaign Objective */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Campaign Objective
                  </label>
                  <select
                    value={formData.objective}
                    onChange={(e) => setFormData({...formData, objective: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="newsletter">Newsletter</option>
                    <option value="product_promotion">Product Promotion</option>
                    <option value="event_announcement">Event Announcement</option>
                    <option value="lead_nurturing">Lead Nurturing</option>
                    <option value="customer_retention">Customer Retention</option>
                    <option value="welcome_series">Welcome Series</option>
                  </select>
                </div>
                
                {/* Platform */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Platform
                  </label>
                  <select
                    value={formData.platform}
                    onChange={(e) => setFormData({...formData, platform: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="mailchimp">Mailchimp</option>
                    <option value="convertkit">ConvertKit</option>
                    <option value="internal">Internal System</option>
                  </select>
                </div>
                
                {/* Tone */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Tone
                  </label>
                  <select
                    value={formData.tone}
                    onChange={(e) => setFormData({...formData, tone: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="professional">Professional</option>
                    <option value="friendly">Friendly</option>
                    <option value="playful">Playful</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
                
                {/* Audience Segment */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Audience Segment
                  </label>
                  <select
                    value={formData.audience_segment}
                    onChange={(e) => setFormData({...formData, audience_segment: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">Select audience segment</option>
                    {audienceSegments.map((segment) => (
                      <option key={segment.segment_id} value={segment.segment_id}>
                        {segment.name} ({formatNumber(segment.estimated_size)} contacts)
                      </option>
                    ))}
                  </select>
                </div>
                
                {/* Schedule */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Schedule (Optional)
                  </label>
                  <input
                    type="datetime-local"
                    value={formData.scheduled_at}
                    onChange={(e) => setFormData({...formData, scheduled_at: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Leave empty to create as draft
                  </p>
                </div>
              </div>
              
              <div className="p-6 border-t flex items-center justify-end gap-4">
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={createCampaign}
                  disabled={loading || !formData.name || !formData.audience_segment}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {loading ? 'Creating...' : 'Create Campaign'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Performance Modal */}
        {showPerformanceModal && selectedCampaign && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-gray-900">
                    Campaign Performance: {selectedCampaign.name}
                  </h2>
                  <button
                    onClick={() => setShowPerformanceModal(false)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    ×
                  </button>
                </div>
              </div>
              
              <div className="p-6">
                {selectedCampaign.performance ? (
                  <div className="space-y-6">
                    {/* Performance Grid */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">
                          {formatNumber(selectedCampaign.performance.emails_sent)}
                        </div>
                        <div className="text-sm text-blue-600">Emails Sent</div>
                      </div>
                      
                      <div className="bg-green-50 p-4 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">
                          {formatPercentage(selectedCampaign.performance.open_rate)}
                        </div>
                        <div className="text-sm text-green-600">Open Rate</div>
                      </div>
                      
                      <div className="bg-purple-50 p-4 rounded-lg">
                        <div className="text-2xl font-bold text-purple-600">
                          {formatPercentage(selectedCampaign.performance.click_rate)}
                        </div>
                        <div className="text-sm text-purple-600">Click Rate</div>
                      </div>
                      
                      <div className="bg-orange-50 p-4 rounded-lg">
                        <div className="text-2xl font-bold text-orange-600">
                          ${formatNumber(selectedCampaign.performance.revenue)}
                        </div>
                        <div className="text-sm text-orange-600">Revenue</div>
                      </div>
                    </div>
                    
                    {/* Detailed Metrics */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h3 className="font-medium text-gray-900 mb-3">Engagement Metrics</h3>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Opens:</span>
                            <span className="font-medium">{formatNumber(selectedCampaign.performance.opens)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Clicks:</span>
                            <span className="font-medium">{formatNumber(selectedCampaign.performance.clicks)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">CTR:</span>
                            <span className="font-medium">{formatPercentage(selectedCampaign.performance.ctr)}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h3 className="font-medium text-gray-900 mb-3">Delivery Metrics</h3>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Delivered:</span>
                            <span className="font-medium">{formatNumber(selectedCampaign.performance.emails_delivered)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Bounces:</span>
                            <span className="font-medium">{formatNumber(selectedCampaign.performance.bounces)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Unsubscribes:</span>
                            <span className="font-medium">{formatNumber(selectedCampaign.performance.unsubscribes)}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No performance data available yet.</p>
                    <p className="text-sm text-gray-500">Performance data will appear after the campaign is sent.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Recommendations Modal */}
        {showRecommendationsModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full mx-4 max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
                    <Lightbulb className="w-5 h-5 text-yellow-500" />
                    Optimization Recommendations
                  </h2>
                  <button
                    onClick={() => setShowRecommendationsModal(false)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    ×
                  </button>
                </div>
              </div>
              
              <div className="p-6">
                {recommendations.length > 0 ? (
                  <div className="space-y-4">
                    {recommendations.map((rec, index) => (
                      <div key={index} className={`p-4 rounded-lg border-l-4 ${
                        rec.priority === 'high' ? 'border-red-500 bg-red-50' :
                        rec.priority === 'medium' ? 'border-yellow-500 bg-yellow-50' :
                        'border-blue-500 bg-blue-50'
                      }`}>
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h3 className="font-medium text-gray-900">{rec.issue}</h3>
                              <span className={`px-2 py-1 text-xs rounded-full ${
                                rec.priority === 'high' ? 'bg-red-100 text-red-700' :
                                rec.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                                'bg-blue-100 text-blue-700'
                              }`}>
                                {rec.priority}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600 mt-1">
                              Current: {rec.current_value}
                            </p>
                            <p className="text-sm text-gray-700 mt-2">
                              {rec.recommendation}
                            </p>
                            
                            {rec.suggested_actions.length > 0 && (
                              <div className="mt-3">
                                <p className="text-sm font-medium text-gray-700 mb-1">
                                  Suggested Actions:
                                </p>
                                <ul className="text-sm text-gray-600 space-y-1">
                                  {rec.suggested_actions.map((action, actionIndex) => (
                                    <li key={actionIndex} className="flex items-center gap-2">
                                      <ArrowRight className="w-3 h-3 text-gray-400" />
                                      {action}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Lightbulb className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No recommendations available.</p>
                    <p className="text-sm text-gray-500">Your campaign performance looks great!</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
} 