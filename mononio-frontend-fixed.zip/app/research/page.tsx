'use client';

import { useEffect, useState } from 'react';
import { useAuthStore } from '@/store/auth';
import { Business, MarketResearchRequest, MarketResearchResponse } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import {
  MagnifyingGlassIcon,
  ChartBarIcon,
  UserGroupIcon,
  BuildingOfficeIcon,
  LightBulbIcon,
  DocumentTextIcon,
  ArrowTrendingUpIcon,
  GlobeAltIcon,
  SparklesIcon,
  ClipboardDocumentIcon,
  VideoCameraIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { getErrorMessage } from '@/lib/getErrorMessage';

interface ResearchType {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
}

const researchTypes: ResearchType[] = [
  {
    id: 'competitor_analysis',
    name: 'Competitor Analysis',
    description: 'Analyze your competitors and their strategies',
    icon: BuildingOfficeIcon,
    color: 'bg-primary-100 text-primary-600',
  },
  {
    id: 'market_trends',
    name: 'Market Trends',
    description: 'Identify current and emerging market trends',
    icon: ArrowTrendingUpIcon,
    color: 'bg-success-100 text-success-600',
  },
  {
    id: 'audience_research',
    name: 'Audience Research',
    description: 'Understand your target audience better',
    icon: UserGroupIcon,
    color: 'bg-warning-100 text-warning-600',
  },
  {
    id: 'industry_analysis',
    name: 'Industry Analysis',
    description: 'Deep dive into your industry landscape',
    icon: GlobeAltIcon,
    color: 'bg-secondary-100 text-secondary-600',
  },
  {
    id: 'video_generation',
    name: 'Video Generation',
    description: 'Create marketing videos for your research findings',
    icon: VideoCameraIcon,
    color: 'bg-purple-100 text-purple-600',
  },
];

export default function ResearchPage() {
  const { isAuthenticated } = useAuthStore();
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null);
  const [researchType, setResearchType] = useState<'competitor_analysis' | 'market_trends' | 'audience_research' | 'video_generation'>('competitor_analysis');
  const [researchQuestion, setResearchQuestion] = useState('');
  const [loading, setLoading] = useState(false);
  const [researchResults, setResearchResults] = useState<MarketResearchResponse | null>(null);
  const [researchHistory, setResearchHistory] = useState<any[]>([]);

  // Agent-specific state
  const [topicClusters, setTopicClusters] = useState<any[]>([]);
  const [businessAnalytics, setBusinessAnalytics] = useState<any>(null);
  const [customerInsights, setCustomerInsights] = useState<any>(null);
  const [agentStatus, setAgentStatus] = useState<any>({});

  useEffect(() => {
    if (isAuthenticated) {
      fetchBusinesses();
      fetchAgentData();
    }
  }, [isAuthenticated]);

  const fetchBusinesses = async () => {
    try {
      const data = await apiClient.getBusinesses();
      setBusinesses(data);
      if (data.length > 0) {
        setSelectedBusiness(data[0]);
      }
    } catch (error) {
      console.error('Failed to fetch businesses:', error);
      toast.error('Failed to load businesses');
    }
  };

  const fetchAgentData = async () => {
    try {
      if (selectedBusiness) {
        // Fetch topic clusters
        const clustersResponse = await apiClient.getTopicClusters(selectedBusiness.id.toString());
        if (clustersResponse.success) {
          setTopicClusters(clustersResponse.clusters || []);
        }

        // Fetch business analytics
        const analyticsResponse = await apiClient.getBusinessAnalyticsByAgent(selectedBusiness.id.toString());
        if (analyticsResponse.success) {
          setBusinessAnalytics(analyticsResponse.analytics);
        }

        // Fetch customer insights
        const insightsResponse = await apiClient.getCustomerInsights(selectedBusiness.id.toString());
        if (insightsResponse.success) {
          setCustomerInsights(insightsResponse.insights);
        }

        // Fetch agent status
        const statusResponse = await apiClient.getAllAgentsStatus();
        if (statusResponse.success) {
          setAgentStatus(statusResponse.agents || {});
        }
      }
    } catch (error) {
      console.error('Failed to fetch agent data:', error);
    }
  };

  const handleConductResearch = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedBusiness) {
      toast.error('Please select a business');
      return;
    }
    
    // Handle video generation separately
    if (researchType === 'video_generation') {
      // Redirect to video generation page
      window.location.href = '/video';
      return;
    }
    
    setLoading(true);
    
    try {
      const request: MarketResearchRequest = {
        research_type: researchType as 'competitor_analysis' | 'market_trends' | 'audience_research',
        business_context: {
          name: selectedBusiness.name,
          industry: selectedBusiness.industry,
          target_audience: selectedBusiness.target_audience,
          brand_voice: selectedBusiness.brand_voice,
          location: selectedBusiness.location,
        },
        industry: selectedBusiness.industry,
        location: selectedBusiness.location,
      };
      
      const response = await apiClient.conductMarketResearch(request);
      setResearchResults(response);
      setResearchHistory([{ ...response, timestamp: new Date().toISOString() }, ...researchHistory]);
      toast.success('Research completed successfully!');
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to conduct research');
    } finally {
      setLoading(false);
    }
  };

  const handleAskQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!researchQuestion.trim()) {
      toast.error('Please enter a research question');
      return;
    }
    
    setLoading(true);
    
    try {
      const response = await apiClient.answerResearchQuestion(researchQuestion);
      setResearchHistory([{ question: researchQuestion, answer: response, timestamp: new Date().toISOString() }, ...researchHistory]);
      setResearchQuestion('');
      toast.success('Question answered successfully!');
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to answer question');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTopicCluster = async () => {
    if (!selectedBusiness || !researchQuestion.trim()) {
      toast.error('Please select a business and enter a research topic');
      return;
    }

    setLoading(true);
    try {
      const response = await apiClient.createTopicCluster({
        core_topic: researchQuestion,
        business_id: selectedBusiness.id.toString(),
        target_keywords: [researchQuestion.split(' ')[0], researchQuestion.split(' ')[1]] // Simple keyword extraction
      });

      if (response.success) {
        toast.success('Topic cluster created successfully!');
        await fetchAgentData(); // Refresh data
      } else {
        toast.error(getErrorMessage(response.error) || 'Failed to create topic cluster');
      }
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to create topic cluster');
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateBusinessInsights = async () => {
    if (!selectedBusiness) {
      toast.error('Please select a business');
      return;
    }

    setLoading(true);
    try {
      const response = await apiClient.generateBusinessInsights(selectedBusiness.id.toString(), 'market_analysis');
      if (response.success) {
        setBusinessAnalytics(response.insights);
        toast.success('Business insights generated!');
      } else {
        toast.error(getErrorMessage(response.error) || 'Failed to generate business insights');
      }
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to generate business insights');
    } finally {
      setLoading(false);
    }
  };

  const handleGetCustomerInsights = async () => {
    if (!selectedBusiness) {
      toast.error('Please select a business');
      return;
    }

    setLoading(true);
    try {
      const response = await apiClient.getCustomerInsights(selectedBusiness.id.toString());
      if (response.success) {
        setCustomerInsights(response.insights);
        toast.success('Customer insights retrieved!');
      } else {
        toast.error(getErrorMessage(response.error) || 'Failed to get customer insights');
      }
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to get customer insights');
    } finally {
      setLoading(false);
    }
  };

  const handleCopyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  if (!isAuthenticated) {
    return <div>Please log in to access research tools.</div>;
  }

  return (
    <div className="flex h-screen bg-secondary-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-secondary-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-secondary-900">
                Market Research
              </h1>
              <p className="text-secondary-600">
                AI-powered market research and competitive intelligence
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => window.location.href = '/video'}
                variant="secondary"
                leftIcon={<VideoCameraIcon className="h-4 w-4" />}
                className="flex items-center space-x-2"
              >
                Video Generation
              </Button>
              <div className="flex items-center space-x-2">
                <SparklesIcon className="h-6 w-6 text-primary-600" />
                <span className="text-sm font-medium text-primary-600">AI Powered</span>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Research Tools */}
            <div className="space-y-6">
              {/* Business Selection */}
              <div className="card">
                <div className="card-header">
                  <h3 className="card-title">Select Business</h3>
                  <p className="card-subtitle">Choose the business for research</p>
                </div>
                <select
                  value={selectedBusiness?.id || ''}
                  onChange={(e) => {
                    const business = businesses.find(b => b.id === Number(e.target.value));
                    setSelectedBusiness(business || null);
                  }}
                  className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
                >
                  {businesses.map((business) => (
                    <option key={business.id} value={business.id}>
                      {business.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Research Types */}
              <div className="card">
                <div className="card-header">
                  <h3 className="card-title">Research Type</h3>
                  <p className="card-subtitle">Select the type of research to conduct</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {researchTypes.map((type) => {
                    const Icon = type.icon;
                    const isSelected = researchType === type.id;
                    
                    return (
                      <button
                        key={type.id}
                                                 onClick={() => setResearchType(type.id as 'competitor_analysis' | 'market_trends' | 'audience_research' | 'video_generation')}
                        className={`p-4 border rounded-lg text-left transition-colors ${
                          isSelected
                            ? 'border-primary-300 bg-primary-50'
                            : 'border-secondary-200 hover:bg-secondary-50'
                        }`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`h-8 w-8 rounded-lg flex items-center justify-center ${type.color}`}>
                            <Icon className="h-4 w-4" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-secondary-900">{type.name}</p>
                            <p className="text-xs text-secondary-500">{type.description}</p>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
                <Button
                  onClick={handleConductResearch}
                  loading={loading}
                  className="w-full mt-4"
                  leftIcon={<MagnifyingGlassIcon className="h-4 w-4" />}
                >
                  Conduct Research
                </Button>
              </div>

              {/* Quick Questions */}
              <div className="card">
                <div className="card-header">
                  <h3 className="card-title">Ask Research Questions</h3>
                  <p className="card-subtitle">Get quick answers to specific questions</p>
                </div>
                <form onSubmit={handleAskQuestion} className="space-y-4">
                  <Input
                    label="Research Question"
                    value={researchQuestion}
                    onChange={(e) => setResearchQuestion(e.target.value)}
                    placeholder="e.g., What are the top trends in SaaS marketing?"
                    required
                  />
                  <Button type="submit" loading={loading} className="w-full">
                    Ask Question
                  </Button>
                </form>
              </div>
            </div>

            {/* Research Results */}
            <div className="space-y-6">
              {/* Current Research Results */}
              {researchResults && (
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Research Results</h3>
                    <p className="card-subtitle">Latest research findings</p>
                  </div>
                  <div className="space-y-4">
                    {/* Market Analysis */}
                    <div>
                      <h4 className="text-sm font-medium text-secondary-900 mb-2">Market Analysis</h4>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="p-3 bg-secondary-50 rounded-lg">
                          <p className="text-secondary-500">Market Size</p>
                          <p className="font-medium text-secondary-900">{researchResults.analysis.market_size}</p>
                        </div>
                        <div className="p-3 bg-secondary-50 rounded-lg">
                          <p className="text-secondary-500">Growth Rate</p>
                          <p className="font-medium text-secondary-900">{researchResults.analysis.growth_rate}</p>
                        </div>
                      </div>
                    </div>

                    {/* Key Trends */}
                    <div>
                      <h4 className="text-sm font-medium text-secondary-900 mb-2">Key Trends</h4>
                      <ul className="space-y-1">
                                                 {researchResults.analysis.key_trends.map((trend: string, index: number) => (
                           <li key={index} className="text-sm text-secondary-700 flex items-center">
                             <ArrowTrendingUpIcon className="h-4 w-4 mr-2 text-success-500" />
                             {trend}
                           </li>
                         ))}
                      </ul>
                    </div>

                    {/* Insights */}
                    <div>
                      <h4 className="text-sm font-medium text-secondary-900 mb-2">Key Insights</h4>
                      <ul className="space-y-2">
                        {researchResults.insights.map((insight, index) => (
                          <li key={index} className="text-sm text-secondary-700 flex items-start">
                            <LightBulbIcon className="h-4 w-4 mr-2 text-warning-500 mt-0.5 flex-shrink-0" />
                            {insight}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Recommendations */}
                    <div>
                      <h4 className="text-sm font-medium text-secondary-900 mb-2">Recommendations</h4>
                      <ul className="space-y-2">
                        {researchResults.recommendations.map((recommendation, index) => (
                          <li key={index} className="text-sm text-secondary-700 flex items-start">
                            <ChartBarIcon className="h-4 w-4 mr-2 text-primary-500 mt-0.5 flex-shrink-0" />
                            {recommendation}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Competitors */}
                    <div>
                      <h4 className="text-sm font-medium text-secondary-900 mb-2">Competitor Analysis</h4>
                      <div className="space-y-2">
                        {researchResults.competitors.map((competitor, index) => (
                          <div key={index} className="p-3 border border-secondary-200 rounded-lg">
                            <p className="text-sm font-medium text-secondary-900">{competitor.name}</p>
                            <div className="grid grid-cols-2 gap-2 mt-2 text-xs">
                              <div>
                                <p className="text-secondary-500">Strength</p>
                                <p className="text-secondary-700">{competitor.strength}</p>
                              </div>
                              <div>
                                <p className="text-secondary-500">Weakness</p>
                                <p className="text-secondary-700">{competitor.weakness}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Button
                      onClick={() => handleCopyToClipboard(JSON.stringify(researchResults, null, 2))}
                      variant="secondary"
                      leftIcon={<ClipboardDocumentIcon className="h-4 w-4" />}
                    >
                      Copy Results
                    </Button>
                  </div>
                </div>
              )}

              {/* Research History */}
              <div className="card">
                <div className="card-header">
                  <h3 className="card-title">Research History</h3>
                  <p className="card-subtitle">Previous research and questions</p>
                </div>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {researchHistory.map((item, index) => (
                    <div key={index} className="p-3 border border-secondary-200 rounded-lg">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          {item.question ? (
                            <>
                              <p className="text-sm font-medium text-secondary-900">Q: {item.question}</p>
                              <p className="text-sm text-secondary-600 mt-1">
                                {item.answer?.data?.answer || 'Answer not available'}
                              </p>
                            </>
                          ) : (
                            <>
                              <p className="text-sm font-medium text-secondary-900">
                                {item.analysis?.market_size ? 'Market Research' : 'Research'}
                              </p>
                              <p className="text-sm text-secondary-600 mt-1">
                                {item.insights?.[0] || 'Research completed'}
                              </p>
                            </>
                          )}
                        </div>
                        <span className="text-xs text-secondary-500 ml-2">
                          {new Date(item.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    </div>
                  ))}
                  {researchHistory.length === 0 && (
                    <p className="text-sm text-secondary-500 text-center py-4">
                      No research history yet. Start by conducting research or asking questions.
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
} 