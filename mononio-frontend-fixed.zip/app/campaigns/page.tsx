'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth';
import { 
  Campaign, 
  CampaignCreate, 
  Business, 
  CampaignAnalytics,
  ABTestVariantCreate,
  AutomationRuleCreate
} from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import ClientOnly from '@/components/auth/ClientOnly';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import {
  PlusIcon,
  MegaphoneIcon,
  CalendarIcon,
  CurrencyDollarIcon,
  EyeIcon,
  CursorArrowRaysIcon,
  UserGroupIcon,
  ChartBarIcon,
  BeakerIcon,
  CogIcon,
  PencilIcon,
  TrashIcon,
  PlayIcon,
  PauseIcon,
  StopIcon,
  FunnelIcon,
  ArrowTrendingUpIcon,
  GlobeAltIcon,
  SparklesIcon,
  ClockIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { getErrorMessage } from '@/lib/getErrorMessage';

export default function CampaignsPage() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showAnalyticsModal, setShowAnalyticsModal] = useState(false);
  const [showABTestModal, setShowABTestModal] = useState(false);
  const [showAutomationModal, setShowAutomationModal] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [campaignAnalytics, setCampaignAnalytics] = useState<CampaignAnalytics | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const [formData, setFormData] = useState<CampaignCreate>({
    business_id: 0,
    name: '',
    campaign_type: 'social_media',
    budget: 0,
    start_date: '',
    end_date: '',
    description: '',
    goal: '',
    target_audience: '',
    channels: [],
    ab_testing_enabled: false,
  });

  const [abTestData, setABTestData] = useState<ABTestVariantCreate>({
    name: '',
    description: '',
    traffic_percentage: 50,
  });

  const [automationData, setAutomationData] = useState<AutomationRuleCreate>({
    name: '',
    condition: '',
    action: '',
    enabled: true,
  });

  useEffect(() => {
    if (isAuthenticated) {
      fetchData();
    }
  }, [isAuthenticated]);

  const fetchData = async () => {
    try {
      const [campaignsData, businessesData] = await Promise.all([
        apiClient.getCampaigns(),
        apiClient.getBusinesses(),
      ]);
      setCampaigns(campaignsData);
      setBusinesses(businessesData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
      toast.error('Failed to load campaigns');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCampaign = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.business_id) {
      toast.error('Please select a business');
      return;
    }
    
    try {
      const newCampaign = await apiClient.createCampaign(formData);
      setCampaigns([...campaigns, newCampaign]);
      setShowCreateModal(false);
      resetFormData();
      toast.success('Campaign created successfully!');
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to create campaign');
    }
  };

  const handleUpdateCampaign = async (campaign: Campaign) => {
    try {
      const updatedCampaign = await apiClient.updateCampaign(campaign.id, {
        business_id: campaign.business_id,
        name: campaign.name,
        campaign_type: campaign.campaign_type,
        budget: campaign.budget,
        start_date: campaign.start_date,
        end_date: campaign.end_date,
        description: campaign.description,
        goal: campaign.goal,
        target_audience: campaign.target_audience,
        channels: campaign.channels,
        ab_testing_enabled: campaign.ab_testing_enabled,
      });
      
      setCampaigns(campaigns.map(c => c.id === campaign.id ? updatedCampaign : c));
      toast.success('Campaign updated successfully!');
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to update campaign');
    }
  };

  const handleDeleteCampaign = async (campaignId: number) => {
    if (!confirm('Are you sure you want to delete this campaign?')) return;
    
    try {
      await apiClient.deleteCampaign(campaignId);
      setCampaigns(campaigns.filter(c => c.id !== campaignId));
      toast.success('Campaign deleted successfully!');
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to delete campaign');
    }
  };

  const handleViewAnalytics = async (campaign: Campaign) => {
    try {
      const analytics = await apiClient.getCampaignAnalytics(campaign.id);
      setCampaignAnalytics(analytics);
      setSelectedCampaign(campaign);
      setShowAnalyticsModal(true);
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to load analytics');
    }
  };

  const handleCreateABTest = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedCampaign) return;
    
    try {
      await apiClient.createABTestVariant(selectedCampaign.id, abTestData);
      setShowABTestModal(false);
      setABTestData({ name: '', description: '', traffic_percentage: 50 });
      fetchData(); // Refresh to get updated campaign data
      toast.success('A/B test variant created successfully!');
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to create A/B test variant');
    }
  };

  const handleCreateAutomation = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedCampaign) return;
    
    try {
      await apiClient.createAutomationRule(selectedCampaign.id, automationData);
      setShowAutomationModal(false);
      setAutomationData({ name: '', condition: '', action: '', enabled: true });
      fetchData(); // Refresh to get updated campaign data
      toast.success('Automation rule created successfully!');
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to create automation rule');
    }
  };

  const resetFormData = () => {
    setFormData({
      business_id: 0,
      name: '',
      campaign_type: 'social_media',
      budget: 0,
      start_date: '',
      end_date: '',
      description: '',
      goal: '',
      target_audience: '',
      channels: [],
      ab_testing_enabled: false,
    });
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      draft: { label: 'Draft', className: 'bg-gray-100 text-gray-800' },
      active: { label: 'Active', className: 'bg-green-100 text-green-800' },
      paused: { label: 'Paused', className: 'bg-yellow-100 text-yellow-800' },
      completed: { label: 'Completed', className: 'bg-blue-100 text-blue-800' },
      scheduled: { label: 'Scheduled', className: 'bg-purple-100 text-purple-800' },
    };
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.draft;
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.className}`}>
        {config.label}
      </span>
    );
  };

  const getCampaignTypeIcon = (type: string) => {
    const icons = {
      social_media: MegaphoneIcon,
      email: EyeIcon,
      advertising: CursorArrowRaysIcon,
      content: ChartBarIcon,
      multi_channel: GlobeAltIcon,
      ab_testing: BeakerIcon,
    };
    const Icon = icons[type as keyof typeof icons] || MegaphoneIcon;
    return <Icon className="h-5 w-5" />;
  };

  const filteredCampaigns = campaigns.filter(campaign => {
    const matchesSearch = campaign.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         campaign.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || campaign.status === filterStatus;
    const matchesType = filterType === 'all' || campaign.campaign_type === filterType;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  if (!isAuthenticated) {
    return <div>Please log in to access campaigns.</div>;
  }

  return (
    <ClientOnly>
      <ProtectedRoute>
        <div className="flex h-screen bg-gray-50">
          <Sidebar />
          
          <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="bg-white border-b border-gray-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Campaigns
                </h1>
                <p className="text-gray-600">
                  Create and manage your marketing campaigns with advanced analytics
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  onClick={() => setShowCreateModal(true)}
                  variant="secondary"
                  leftIcon={<PlusIcon className="h-4 w-4" />}
                >
                  Quick Create
                </Button>
                <Button
                  onClick={() => router.push('/campaigns/create')}
                  leftIcon={<PlusIcon className="h-4 w-4" />}
                >
                  Campaign Wizard
                </Button>
              </div>
            </div>
          </header>

          {/* Filters and Controls */}
          <div className="bg-white border-b border-gray-200 px-6 py-4">
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div className="flex flex-col sm:flex-row gap-4 items-center">
                <Input
                  placeholder="Search campaigns..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full sm:w-64"
                />
                
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="all">All Status</option>
                  <option value="draft">Draft</option>
                  <option value="active">Active</option>
                  <option value="paused">Paused</option>
                  <option value="completed">Completed</option>
                  <option value="scheduled">Scheduled</option>
                </select>
                
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="all">All Types</option>
                  <option value="social_media">Social Media</option>
                  <option value="email">Email</option>
                  <option value="advertising">Advertising</option>
                  <option value="content">Content</option>
                  <option value="multi_channel">Multi-Channel</option>
                  <option value="ab_testing">A/B Testing</option>
                </select>
              </div>
              
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-lg ${viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'}`}
                >
                  <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                  </svg>
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-lg ${viewMode === 'list' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'}`}
                >
                  <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto p-6">
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
              </div>
            ) : (
              <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-6'}>
                {filteredCampaigns.map((campaign) => (
                  <div key={campaign.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                    {/* Campaign Header */}
                    <div className="p-6 border-b border-gray-100">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            {getCampaignTypeIcon(campaign.campaign_type)}
                          </div>
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold text-gray-900">
                              {campaign.name}
                            </h3>
                            <p className="text-sm text-gray-500">
                              {businesses.find(b => b.id === campaign.business_id)?.name}
                            </p>
                          </div>
                        </div>
                        {getStatusBadge(campaign.status)}
                      </div>
                      
                      {campaign.description && (
                        <p className="text-sm text-gray-600 mb-4">{campaign.description}</p>
                      )}
                      
                      {/* Performance Metrics */}
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="text-center p-3 bg-gray-50 rounded-lg">
                          <p className="text-2xl font-bold text-gray-900">
                            {campaign.impressions.toLocaleString()}
                          </p>
                          <p className="text-xs text-gray-500">Impressions</p>
                        </div>
                        <div className="text-center p-3 bg-gray-50 rounded-lg">
                          <p className="text-2xl font-bold text-gray-900">
                            {campaign.conversions.toLocaleString()}
                          </p>
                          <p className="text-xs text-gray-500">Conversions</p>
                        </div>
                      </div>
                      
                      {/* ROI and Budget */}
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center">
                            <CurrencyDollarIcon className="h-4 w-4 mr-1 text-gray-400" />
                            <span className="text-gray-600">
                              ${campaign.budget_spent?.toLocaleString() || 0} / ${campaign.budget.toLocaleString()}
                            </span>
                          </div>
                                                   {campaign.roi && (
                             <div className="flex items-center">
                               <ArrowTrendingUpIcon className="h-4 w-4 mr-1 text-green-500" />
                               <span className="text-green-600 font-medium">
                                 {campaign.roi.toFixed(2)}x ROI
                               </span>
                             </div>
                           )}
                        </div>
                        <div className="flex items-center space-x-2">
                          {campaign.ab_testing_enabled && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                              <BeakerIcon className="h-3 w-3 mr-1" />
                              A/B Test
                            </span>
                          )}
                          {campaign.channels && campaign.channels.length > 1 && (
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              <GlobeAltIcon className="h-3 w-3 mr-1" />
                              Multi-Channel
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {/* Campaign Actions */}
                    <div className="p-4 bg-gray-50">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => handleViewAnalytics(campaign)}
                            leftIcon={<ChartBarIcon className="h-4 w-4" />}
                          >
                            Analytics
                          </Button>
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => {
                              setSelectedCampaign(campaign);
                              setShowABTestModal(true);
                            }}
                            leftIcon={<BeakerIcon className="h-4 w-4" />}
                          >
                            A/B Test
                          </Button>
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => {
                              setSelectedCampaign(campaign);
                              setShowAutomationModal(true);
                            }}
                            leftIcon={<CogIcon className="h-4 w-4" />}
                          >
                            Automation
                          </Button>
                        </div>
                        
                        <div className="flex items-center space-x-1">
                          <button
                            onClick={() => handleUpdateCampaign(campaign)}
                            className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                          >
                            <PencilIcon className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteCampaign(campaign.id)}
                            className="p-2 text-gray-400 hover:text-red-600 rounded-lg hover:bg-red-50"
                          >
                            <TrashIcon className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {filteredCampaigns.length === 0 && (
                  <div className="col-span-full text-center py-12">
                    <MegaphoneIcon className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">No campaigns found</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      {searchTerm || filterStatus !== 'all' || filterType !== 'all' 
                        ? 'Try adjusting your filters or search terms.'
                        : 'Get started by creating your first marketing campaign.'
                      }
                    </p>
                    {!searchTerm && filterStatus === 'all' && filterType === 'all' && (
                      <div className="mt-6">
                        <Button onClick={() => setShowCreateModal(true)}>
                          <PlusIcon className="h-4 w-4 mr-2" />
                          Create Campaign
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </main>
        </div>

        {/* Create Campaign Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">
                  Create New Campaign
                </h2>
                
                <form onSubmit={handleCreateCampaign} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Business
                      </label>
                      <select
                        value={formData.business_id}
                        onChange={(e) => setFormData({ ...formData, business_id: Number(e.target.value) })}
                        className="block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        required
                      >
                        <option value={0}>Select a business</option>
                        {businesses.map((business) => (
                          <option key={business.id} value={business.id}>
                            {business.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Campaign Type
                      </label>
                      <select
                        value={formData.campaign_type}
                        onChange={(e) => setFormData({ ...formData, campaign_type: e.target.value as any })}
                        className="block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                        required
                      >
                        <option value="social_media">Social Media</option>
                        <option value="email">Email Marketing</option>
                        <option value="advertising">Digital Advertising</option>
                        <option value="content">Content Marketing</option>
                        <option value="multi_channel">Multi-Channel</option>
                        <option value="ab_testing">A/B Testing</option>
                      </select>
                    </div>
                  </div>
                  
                  <Input
                    label="Campaign Name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter campaign name"
                    required
                  />
                  
                  <Input
                    label="Description"
                    value={formData.description || ''}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe your campaign"
                  />
                  
                  <Input
                    label="Goal"
                    value={formData.goal || ''}
                    onChange={(e) => setFormData({ ...formData, goal: e.target.value })}
                    placeholder="What do you want to achieve?"
                  />
                  
                  <Input
                    label="Target Audience"
                    value={formData.target_audience || ''}
                    onChange={(e) => setFormData({ ...formData, target_audience: e.target.value })}
                    placeholder="Who is your target audience?"
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      label="Budget ($)"
                      type="number"
                      value={formData.budget}
                      onChange={(e) => setFormData({ ...formData, budget: Number(e.target.value) })}
                      placeholder="Enter budget amount"
                      required
                    />
                    
                    <Input
                      label="Start Date"
                      type="date"
                      value={formData.start_date}
                      onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                      required
                    />
                  </div>
                  
                  <Input
                    label="End Date (Optional)"
                    type="date"
                    value={formData.end_date || ''}
                    onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                  />
                  
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="ab_testing"
                      checked={formData.ab_testing_enabled}
                      onChange={(e) => setFormData({ ...formData, ab_testing_enabled: e.target.checked })}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <label htmlFor="ab_testing" className="text-sm text-gray-700">
                      Enable A/B Testing
                    </label>
                  </div>
                  
                  <div className="flex space-x-3 pt-4">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setShowCreateModal(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button type="submit" className="flex-1">
                      Create Campaign
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}

        {/* Analytics Modal */}
        {showAnalyticsModal && campaignAnalytics && selectedCampaign && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-gray-900">
                    Campaign Analytics: {selectedCampaign.name}
                  </h2>
                  <button
                    onClick={() => setShowAnalyticsModal(false)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
                
                {/* Overview Metrics */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <p className="text-2xl font-bold text-blue-900">{campaignAnalytics.overview.impressions.toLocaleString()}</p>
                    <p className="text-sm text-blue-600">Impressions</p>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <p className="text-2xl font-bold text-green-900">{campaignAnalytics.overview.conversions.toLocaleString()}</p>
                    <p className="text-sm text-green-600">Conversions</p>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <p className="text-2xl font-bold text-purple-900">${campaignAnalytics.overview.revenue.toLocaleString()}</p>
                    <p className="text-sm text-purple-600">Revenue</p>
                  </div>
                  <div className="bg-orange-50 p-4 rounded-lg">
                    <p className="text-2xl font-bold text-orange-900">{campaignAnalytics.overview.roi.toFixed(2)}x</p>
                    <p className="text-sm text-orange-600">ROI</p>
                  </div>
                </div>
                
                {/* Channel Breakdown */}
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Channel Performance</h3>
                  <div className="space-y-3">
                    {campaignAnalytics.channel_breakdown.map((channel, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="h-8 w-8 bg-blue-100 rounded-lg flex items-center justify-center">
                            <GlobeAltIcon className="h-4 w-4 text-blue-600" />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900 capitalize">{channel.channel}</p>
                            <p className="text-sm text-gray-500">{channel.impressions.toLocaleString()} impressions</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900">{channel.conversion_rate.toFixed(1)}% conversion</p>
                          <p className="text-sm text-gray-500">${channel.revenue.toLocaleString()} revenue</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Recommendations */}
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Recommendations</h3>
                  <div className="space-y-2">
                    {campaignAnalytics.recommendations.map((recommendation, index) => (
                      <div key={index} className="flex items-start space-x-2 p-3 bg-yellow-50 rounded-lg">
                        <SparklesIcon className="h-5 w-5 text-yellow-600 mt-0.5" />
                        <p className="text-sm text-yellow-800">{recommendation}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* A/B Test Modal */}
        {showABTestModal && selectedCampaign && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">
                  Create A/B Test Variant
                </h2>
                
                <form onSubmit={handleCreateABTest} className="space-y-4">
                  <Input
                    label="Variant Name"
                    value={abTestData.name}
                    onChange={(e) => setABTestData({ ...abTestData, name: e.target.value })}
                    placeholder="e.g., Casual Headline"
                    required
                  />
                  
                  <Input
                    label="Description"
                    value={abTestData.description}
                    onChange={(e) => setABTestData({ ...abTestData, description: e.target.value })}
                    placeholder="Describe what you're testing"
                    required
                  />
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Traffic Percentage
                    </label>
                    <input
                      type="range"
                      min="10"
                      max="50"
                      value={abTestData.traffic_percentage}
                      onChange={(e) => setABTestData({ ...abTestData, traffic_percentage: Number(e.target.value) })}
                      className="w-full"
                    />
                    <p className="text-sm text-gray-500 mt-1">{abTestData.traffic_percentage}% of traffic</p>
                  </div>
                  
                  <div className="flex space-x-3 pt-4">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setShowABTestModal(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button type="submit" className="flex-1">
                      Create Variant
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}

        {/* Automation Modal */}
        {showAutomationModal && selectedCampaign && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">
                  Create Automation Rule
                </h2>
                
                <form onSubmit={handleCreateAutomation} className="space-y-4">
                  <Input
                    label="Rule Name"
                    value={automationData.name}
                    onChange={(e) => setAutomationData({ ...automationData, name: e.target.value })}
                    placeholder="e.g., Budget Alert"
                    required
                  />
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Condition
                    </label>
                    <select
                      value={automationData.condition}
                      onChange={(e) => setAutomationData({ ...automationData, condition: e.target.value })}
                      className="block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      required
                    >
                      <option value="">Select condition</option>
                      <option value="budget_spent &gt; 80%">Budget spent &gt; 80%</option>
                      <option value="ctr &lt; 2%">CTR &lt; 2%</option>
                      <option value="conversion_rate &lt; 5%">Conversion rate &lt; 5%</option>
                      <option value="cost &gt; budget * 0.9">Cost &gt; 90% of budget</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Action
                    </label>
                    <select
                      value={automationData.action}
                      onChange={(e) => setAutomationData({ ...automationData, action: e.target.value })}
                      className="block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                      required
                    >
                      <option value="">Select action</option>
                      <option value="send_notification">Send notification</option>
                      <option value="pause_campaign">Pause campaign</option>
                      <option value="adjust_bid">Adjust bid</option>
                      <option value="change_targeting">Change targeting</option>
                    </select>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="enabled"
                      checked={automationData.enabled}
                      onChange={(e) => setAutomationData({ ...automationData, enabled: e.target.checked })}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <label htmlFor="enabled" className="text-sm text-gray-700">
                      Enable rule immediately
                    </label>
                  </div>
                  
                  <div className="flex space-x-3 pt-4">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setShowAutomationModal(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button type="submit" className="flex-1">
                      Create Rule
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
      </ProtectedRoute>
    </ClientOnly>
  );
} 