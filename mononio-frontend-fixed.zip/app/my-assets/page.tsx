'use client';

import { useEffect, useState } from 'react';
import { useAuthStore } from '@/store/auth';
import { Business } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import {
  DocumentTextIcon,
  PhotoIcon,
  VideoCameraIcon,
  BuildingOfficeIcon,
  CalendarIcon,
  ChartBarIcon,
  RectangleStackIcon,
  BeakerIcon,
  ClockIcon,
  ChartBarSquareIcon,
  UsersIcon,
  GlobeAltIcon,
  PlusIcon,
  RocketLaunchIcon,
  MagnifyingGlassIcon,
  FunnelIcon,
  EyeIcon,
  PencilIcon,
  TrashIcon,
  ArrowDownTrayIcon,
  ShareIcon,
  StarIcon,
  FireIcon,
  SparklesIcon,
  DocumentIcon,
  FolderIcon,
  LinkIcon,
  PlayIcon,
  CameraIcon,
  DocumentDuplicateIcon,
  PresentationChartLineIcon,
  MegaphoneIcon,
  CurrencyDollarIcon,
  UserGroupIcon,
  CogIcon,
  CheckCircleIcon,
  ExclamationTriangleIcon,
  ClockIcon as ClockIconSolid,
} from '@heroicons/react/24/outline';
import { ChatBubbleLeftRightIcon } from '@heroicons/react/24/solid';
import toast from 'react-hot-toast';
import { getErrorMessage } from '@/lib/getErrorMessage';

interface PortfolioAsset {
  id: string;
  content_type: string;
  content_name: string;
  business_id: string;
  business_name: string;
  created_at: string;
  updated_at: string;
  status: string;
  category: string;
  preview_url?: string;
  download_url?: string;
  description?: string;
  tags?: string[];
  performance_metrics?: {
    views?: number;
    clicks?: number;
    conversions?: number;
    engagement_rate?: number;
  };
  metadata?: {
    file_size?: string;
    dimensions?: string;
    duration?: string;
    platform?: string;
    campaign_id?: string;
    landing_page_id?: string;
  };
}

interface AssetFilters {
  content_type: string;
  business_id: string;
  status: string;
  date_range: string;
  search: string;
}

const CONTENT_TYPE_LABELS: Record<string, string> = {
  'landing_page': 'Landing Page',
  'campaign': 'Campaign',
  'document': 'Document',
  'image': 'Image',
  'video': 'Video',
  'social_post': 'Social Post',
  'email': 'Email',
  'ad': 'Advertisement',
  'presentation': 'Presentation',
  'report': 'Report',
  'template': 'Template',
  'orchestrator_campaign': 'Orchestrator Campaign',
};

const CONTENT_TYPE_ICONS: Record<string, any> = {
  'landing_page': GlobeAltIcon,
  'campaign': MegaphoneIcon,
  'document': DocumentTextIcon,
  'image': PhotoIcon,
  'video': VideoCameraIcon,
  'social_post': ChatBubbleLeftRightIcon,
  'email': DocumentDuplicateIcon,
  'ad': CurrencyDollarIcon,
  'presentation': PresentationChartLineIcon,
  'report': ChartBarIcon,
  'template': RectangleStackIcon,
  'orchestrator_campaign': RocketLaunchIcon,
};

const STATUS_COLORS: Record<string, string> = {
  'active': 'bg-green-100 text-green-800',
  'draft': 'bg-yellow-100 text-yellow-800',
  'archived': 'bg-gray-100 text-gray-800',
  'published': 'bg-blue-100 text-blue-800',
  'scheduled': 'bg-purple-100 text-purple-800',
  'completed': 'bg-green-100 text-green-800',
  'paused': 'bg-red-100 text-red-800',
};

export default function MyAssetsPage() {
  const { isAuthenticated, isLoading: authLoading } = useAuthStore();
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [allAssets, setAllAssets] = useState<PortfolioAsset[]>([]);
  const [filteredAssets, setFilteredAssets] = useState<PortfolioAsset[]>([]);
  const [pageLoading, setPageLoading] = useState(true);
  const [loading, setLoading] = useState(false);
  const [selectedAssets, setSelectedAssets] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'created_at' | 'updated_at' | 'content_name' | 'business_name'>('created_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  
  // Filters
  const [filters, setFilters] = useState<AssetFilters>({
    content_type: '',
    business_id: '',
    status: '',
    date_range: 'all',
    search: '',
  });

  // Statistics
  const [stats, setStats] = useState({
    total_assets: 0,
    total_businesses: 0,
    asset_types: {} as Record<string, number>,
    recent_activity: 0,
    total_views: 0,
    total_engagements: 0,
  });

  useEffect(() => {
    const initializePage = async () => {
      setPageLoading(true);
      try {
        await fetchBusinesses();
        await fetchAllAssets();
        await calculateStats();
      } catch (error) {
        console.error('Failed to initialize My Assets page:', error);
        toast.error('Failed to load assets');
      } finally {
        setPageLoading(false);
      }
    };
    
    initializePage();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [allAssets, filters, sortBy, sortOrder]);

  const fetchBusinesses = async () => {
    try {
      const data = await apiClient.getBusinesses();
      setBusinesses(data);
    } catch (error) {
      console.error('Failed to fetch businesses:', error);
      toast.error('Failed to load businesses');
    }
  };

  const fetchAllAssets = async () => {
    setLoading(true);
    try {
      const allPortfolioAssets: PortfolioAsset[] = [];
      
      // Fetch assets from all businesses
      for (const business of businesses) {
        try {
          const response = await apiClient.getBusinessPortfolio(business.id.toString());
          if (response.success && response.portfolio_items) {
            // Add business information to each asset
            const assetsWithBusiness = response.portfolio_items.map((asset: any) => ({
              ...asset,
              business_id: business.id.toString(),
              business_name: business.name,
            }));
            allPortfolioAssets.push(...assetsWithBusiness);
          }
        } catch (error) {
          console.error(`Failed to fetch assets for business ${business.id}:`, error);
        }
      }
      
      setAllAssets(allPortfolioAssets);
    } catch (error) {
      console.error('Failed to fetch all assets:', error);
      toast.error('Failed to load assets');
    } finally {
      setLoading(false);
    }
  };

  const calculateStats = () => {
    const assetTypes: Record<string, number> = {};
    let totalViews = 0;
    let totalEngagements = 0;
    let recentActivity = 0;
    
    allAssets.forEach(asset => {
      // Count asset types
      assetTypes[asset.content_type] = (assetTypes[asset.content_type] || 0) + 1;
      
      // Sum performance metrics
      if (asset.performance_metrics) {
        totalViews += asset.performance_metrics.views || 0;
        totalEngagements += asset.performance_metrics.engagement_rate || 0;
      }
      
      // Count recent activity (last 7 days)
      const assetDate = new Date(asset.created_at);
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      if (assetDate > weekAgo) {
        recentActivity++;
      }
    });
    
    setStats({
      total_assets: allAssets.length,
      total_businesses: businesses.length,
      asset_types: assetTypes,
      recent_activity: recentActivity,
      total_views: totalViews,
      total_engagements: totalEngagements,
    });
  };

  const applyFilters = () => {
    let filtered = [...allAssets];
    
    // Apply content type filter
    if (filters.content_type) {
      filtered = filtered.filter(asset => asset.content_type === filters.content_type);
    }
    
    // Apply business filter
    if (filters.business_id) {
      filtered = filtered.filter(asset => asset.business_id === filters.business_id);
    }
    
    // Apply status filter
    if (filters.status) {
      filtered = filtered.filter(asset => asset.status === filters.status);
    }
    
    // Apply date range filter
    if (filters.date_range !== 'all') {
      const now = new Date();
      let cutoffDate = new Date();
      
      switch (filters.date_range) {
        case 'today':
          cutoffDate.setHours(0, 0, 0, 0);
          break;
        case 'week':
          cutoffDate.setDate(now.getDate() - 7);
          break;
        case 'month':
          cutoffDate.setMonth(now.getMonth() - 1);
          break;
        case 'quarter':
          cutoffDate.setMonth(now.getMonth() - 3);
          break;
        case 'year':
          cutoffDate.setFullYear(now.getFullYear() - 1);
          break;
      }
      
      filtered = filtered.filter(asset => new Date(asset.created_at) >= cutoffDate);
    }
    
    // Apply search filter
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      filtered = filtered.filter(asset =>
        asset.content_name.toLowerCase().includes(searchLower) ||
        asset.business_name.toLowerCase().includes(searchLower) ||
        asset.description?.toLowerCase().includes(searchLower) ||
        asset.tags?.some(tag => tag.toLowerCase().includes(searchLower))
      );
    }
    
    // Apply sorting
    filtered.sort((a, b) => {
      let aValue: any;
      let bValue: any;
      
      switch (sortBy) {
        case 'created_at':
          aValue = new Date(a.created_at);
          bValue = new Date(b.created_at);
          break;
        case 'updated_at':
          aValue = new Date(a.updated_at);
          bValue = new Date(b.updated_at);
          break;
        case 'content_name':
          aValue = a.content_name;
          bValue = b.content_name;
          break;
        case 'business_name':
          aValue = a.business_name;
          bValue = b.business_name;
          break;
        default:
          aValue = new Date(a.created_at);
          bValue = new Date(b.created_at);
      }
      
      if (sortOrder === 'asc') {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });
    
    setFilteredAssets(filtered);
  };

  const handleAssetSelection = (assetId: string) => {
    setSelectedAssets(prev => 
      prev.includes(assetId) 
        ? prev.filter(id => id !== assetId)
        : [...prev, assetId]
    );
  };

  const handleBulkAction = async (action: 'delete' | 'archive' | 'export') => {
    if (selectedAssets.length === 0) {
      toast.error('Please select assets first');
      return;
    }
    
    try {
      switch (action) {
        case 'delete':
          toast.success(`Deleted ${selectedAssets.length} assets`);
          break;
        case 'archive':
          toast.success(`Archived ${selectedAssets.length} assets`);
          break;
        case 'export':
          toast.success(`Exported ${selectedAssets.length} assets`);
          break;
      }
      setSelectedAssets([]);
    } catch (error) {
      toast.error('Failed to perform bulk action');
    }
  };

  const handleAssetAction = async (assetId: string, action: string) => {
    try {
      switch (action) {
        case 'view':
          break;
        case 'edit':
          break;
        case 'duplicate':
          toast.success('Asset duplicated');
          break;
        case 'share':
          toast.success('Share link copied');
          break;
      }
    } catch (error) {
      toast.error('Failed to perform action');
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return 'Today';
    if (diffDays === 2) return 'Yesterday';
    if (diffDays <= 7) return `${diffDays - 1} days ago`;
    
    return date.toLocaleDateString();
  };

  const getAssetIcon = (contentType: string) => {
    const IconComponent = CONTENT_TYPE_ICONS[contentType] || DocumentIcon;
    return <IconComponent className="w-5 h-5" />;
  };

  if (authLoading || pageLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-gray-50">
        <Sidebar />
        <div className="flex-1 overflow-auto">
          <div className="p-6">
            {/* Header */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">My Assets</h1>
                  <p className="text-gray-600">Manage all your content across businesses</p>
                </div>
                <div className="flex items-center space-x-3">
                  <Button
                    onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
                    variant="secondary"
                    size="sm"
                  >
                    {viewMode === 'grid' ? 'List View' : 'Grid View'}
                  </Button>
                  <Button
                    onClick={() => window.open('/content', '_blank')}
                    variant="secondary"
                    size="sm"
                  >
                    <PlusIcon className="w-4 h-4 mr-2" />
                    Create Content
                  </Button>
                </div>
              </div>

              {/* Statistics */}
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-6">
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center">
                    <DocumentIcon className="w-8 h-8 text-blue-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-600">Total Assets</p>
                      <p className="text-2xl font-bold text-gray-900">{stats.total_assets}</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center">
                    <BuildingOfficeIcon className="w-8 h-8 text-green-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-600">Businesses</p>
                      <p className="text-2xl font-bold text-gray-900">{stats.total_businesses}</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center">
                    <FireIcon className="w-8 h-8 text-orange-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-600">Recent Activity</p>
                      <p className="text-2xl font-bold text-gray-900">{stats.recent_activity}</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center">
                    <EyeIcon className="w-8 h-8 text-purple-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-600">Total Views</p>
                      <p className="text-2xl font-bold text-gray-900">{stats.total_views.toLocaleString()}</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center">
                    <ChartBarIcon className="w-8 h-8 text-indigo-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-600">Engagement</p>
                      <p className="text-2xl font-bold text-gray-900">{stats.total_engagements.toFixed(1)}%</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex items-center">
                    <SparklesIcon className="w-8 h-8 text-yellow-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-600">Asset Types</p>
                      <p className="text-2xl font-bold text-gray-900">{Object.keys(stats.asset_types).length}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Filters */}
            <div className="bg-white p-6 rounded-lg shadow-sm mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Filters</h3>
                <Button
                  onClick={() => setFilters({
                    content_type: '',
                    business_id: '',
                    status: '',
                    date_range: 'all',
                    search: '',
                  })}
                  variant="secondary"
                  size="sm"
                >
                  Clear Filters
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
                  <div className="relative">
                    <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      type="text"
                      placeholder="Search assets..."
                      value={filters.search}
                      onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                      className="pl-10"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Asset Type</label>
                  <select
                    value={filters.content_type}
                    onChange={(e) => setFilters(prev => ({ ...prev, content_type: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">All Types</option>
                    {Object.entries(CONTENT_TYPE_LABELS).map(([key, label]) => (
                      <option key={key} value={key}>{label}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Business</label>
                  <select
                    value={filters.business_id}
                    onChange={(e) => setFilters(prev => ({ ...prev, business_id: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">All Businesses</option>
                    {businesses.map(business => (
                      <option key={business.id} value={business.id}>{business.name}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                  <select
                    value={filters.status}
                    onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">All Status</option>
                    <option value="active">Active</option>
                    <option value="draft">Draft</option>
                    <option value="archived">Archived</option>
                    <option value="published">Published</option>
                    <option value="scheduled">Scheduled</option>
                    <option value="completed">Completed</option>
                    <option value="paused">Paused</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Date Range</label>
                  <select
                    value={filters.date_range}
                    onChange={(e) => setFilters(prev => ({ ...prev, date_range: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="all">All Time</option>
                    <option value="today">Today</option>
                    <option value="week">Last 7 Days</option>
                    <option value="month">Last 30 Days</option>
                    <option value="quarter">Last 3 Months</option>
                    <option value="year">Last Year</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Sort By</label>
                  <select
                    value={`${sortBy}-${sortOrder}`}
                    onChange={(e) => {
                      const [field, order] = e.target.value.split('-');
                      setSortBy(field as any);
                      setSortOrder(order as any);
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="created_at-desc">Newest First</option>
                    <option value="created_at-asc">Oldest First</option>
                    <option value="updated_at-desc">Recently Updated</option>
                    <option value="content_name-asc">Name A-Z</option>
                    <option value="business_name-asc">Business A-Z</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Bulk Actions */}
            {selectedAssets.length > 0 && (
              <div className="bg-blue-50 p-4 rounded-lg mb-6">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-blue-900">
                    {selectedAssets.length} asset{selectedAssets.length !== 1 ? 's' : ''} selected
                  </span>
                  <div className="flex space-x-2">
                    <Button
                      onClick={() => handleBulkAction('export')}
                      variant="secondary"
                      size="sm"
                    >
                      <ArrowDownTrayIcon className="w-4 h-4 mr-2" />
                      Export
                    </Button>
                    <Button
                      onClick={() => handleBulkAction('archive')}
                      variant="secondary"
                      size="sm"
                    >
                      Archive
                    </Button>
                    <Button
                      onClick={() => handleBulkAction('delete')}
                      variant="secondary"
                      size="sm"
                      className="text-red-600 border-red-600 hover:bg-red-50"
                    >
                      <TrashIcon className="w-4 h-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {/* Assets Grid/List */}
            <div className="bg-white rounded-lg shadow-sm">
              {loading ? (
                <div className="flex items-center justify-center p-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : filteredAssets.length === 0 ? (
                <div className="text-center p-12">
                  <DocumentIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No assets found</h3>
                  <p className="text-gray-600 mb-4">Try adjusting your filters or create new content.</p>
                  <Button onClick={() => window.open('/content', '_blank')}>
                    <PlusIcon className="w-4 h-4 mr-2" />
                    Create Content
                  </Button>
                </div>
              ) : (
                <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 p-6' : 'divide-y divide-gray-200'}>
                  {filteredAssets.map((asset) => (
                    <div
                      key={asset.id}
                      className={`relative bg-white border rounded-lg overflow-hidden transition-all duration-200 hover:shadow-md ${
                        selectedAssets.includes(asset.id) ? 'ring-2 ring-blue-500' : 'border-gray-200'
                      }`}
                    >
                      {/* Asset Preview */}
                      <div className="aspect-video bg-gray-100 flex items-center justify-center">
                        {asset.preview_url ? (
                          <img
                            src={asset.preview_url}
                            alt={asset.content_name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="flex items-center justify-center text-gray-400">
                            {getAssetIcon(asset.content_type)}
                          </div>
                        )}
                      </div>

                      {/* Asset Info */}
                      <div className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            {getAssetIcon(asset.content_type)}
                            <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">
                              {CONTENT_TYPE_LABELS[asset.content_type] || asset.content_type}
                            </span>
                          </div>
                          <input
                            type="checkbox"
                            checked={selectedAssets.includes(asset.id)}
                            onChange={() => handleAssetSelection(asset.id)}
                            className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          />
                        </div>

                        <h3 className="font-semibold text-gray-900 mb-1 truncate">
                          {asset.content_name}
                        </h3>
                        
                        <p className="text-sm text-gray-600 mb-2">
                          {asset.business_name}
                        </p>

                        {asset.description && (
                          <p className="text-sm text-gray-500 mb-3 line-clamp-2">
                            {asset.description}
                          </p>
                        )}

                        <div className="flex items-center justify-between mb-3">
                          <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${STATUS_COLORS[asset.status] || 'bg-gray-100 text-gray-800'}`}>
                            {asset.status}
                          </span>
                          <span className="text-xs text-gray-500">
                            {formatDate(asset.created_at)}
                          </span>
                        </div>

                        {/* Performance Metrics */}
                        {asset.performance_metrics && (
                          <div className="grid grid-cols-3 gap-2 mb-3 text-xs">
                            {asset.performance_metrics.views && (
                              <div className="text-center">
                                <div className="font-medium text-gray-900">{asset.performance_metrics.views.toLocaleString()}</div>
                                <div className="text-gray-500">Views</div>
                              </div>
                            )}
                            {asset.performance_metrics.clicks && (
                              <div className="text-center">
                                <div className="font-medium text-gray-900">{asset.performance_metrics.clicks.toLocaleString()}</div>
                                <div className="text-gray-500">Clicks</div>
                              </div>
                            )}
                            {asset.performance_metrics.engagement_rate && (
                              <div className="text-center">
                                <div className="font-medium text-gray-900">{asset.performance_metrics.engagement_rate.toFixed(1)}%</div>
                                <div className="text-gray-500">Engagement</div>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Action Buttons */}
                        <div className="flex items-center justify-between">
                          <div className="flex space-x-1">
                            <Button
                              onClick={() => handleAssetAction(asset.id, 'view')}
                              variant="secondary"
                              size="sm"
                              className="text-xs"
                            >
                              <EyeIcon className="w-3 h-3 mr-1" />
                              View
                            </Button>
                            <Button
                              onClick={() => handleAssetAction(asset.id, 'edit')}
                              variant="secondary"
                              size="sm"
                              className="text-xs"
                            >
                              <PencilIcon className="w-3 h-3 mr-1" />
                              Edit
                            </Button>
                          </div>
                          <div className="flex space-x-1">
                            <Button
                              onClick={() => handleAssetAction(asset.id, 'duplicate')}
                              variant="secondary"
                              size="sm"
                              className="text-xs"
                            >
                              <DocumentDuplicateIcon className="w-3 h-3" />
                            </Button>
                            <Button
                              onClick={() => handleAssetAction(asset.id, 'share')}
                              variant="secondary"
                              size="sm"
                              className="text-xs"
                            >
                              <ShareIcon className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Results Summary */}
            <div className="mt-6 text-center text-sm text-gray-600">
              Showing {filteredAssets.length} of {allAssets.length} assets
            </div>
          </div>
        </div>
      </div>
    </ProtectedRoute>
  );
} 