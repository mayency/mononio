'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import { Label } from '@/components/ui/Label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/Tabs';
import { Badge } from '@/components/ui/Badge';
import apiClient from '@/lib/api';

interface VideoTemplate {
  template_id: string;
  name: string;
  description: string;
  category: string;
  duration: number;
  scenes: Array<{
    type: string;
    duration: number;
    text: string;
  }>;
  thumbnail_url: string;
  tags: string[];
}

interface VideoGenerationRequest {
  title: string;
  description: string;
  duration: number;
  style: string;
  format: string;
  resolution: string;
  background_music?: string;
  voice_over?: string;
  scenes: any[];
  branding?: any;
}

interface VideoGenerationResponse {
  video_id: string;
  status: string;
  download_url?: string;
  preview_url?: string;
  duration: number;
  file_size?: number;
  created_at: string;
  metadata: any;
}

export default function VideoPage() {
  const [templates, setTemplates] = useState<VideoTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<VideoTemplate | null>(null);
  const [generatedVideos, setGeneratedVideos] = useState<VideoGenerationResponse[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [formData, setFormData] = useState<VideoGenerationRequest>({
    title: '',
    description: '',
    duration: 30,
    style: 'modern',
    format: 'mp4',
    resolution: '1080p',
    scenes: []
  });
  const [activeTab, setActiveTab] = useState('create');

  useEffect(() => {
    fetchTemplates();
    fetchGeneratedVideos();
  }, []);

  const fetchTemplates = async () => {
    try {
      const response = await apiClient.getVideoTemplates();
      if (response.success) {
        setTemplates(response.data);
      }
    } catch (error) {
      console.error('Error fetching templates:', error);
    }
  };

  const fetchGeneratedVideos = async () => {
    try {
      const response = await apiClient.getAllVideos();
      if (response.success) {
        setGeneratedVideos(response.data);
      }
    } catch (error) {
      console.error('Error fetching videos:', error);
    }
  };

  const handleTemplateSelect = (template: VideoTemplate) => {
    setSelectedTemplate(template);
    setFormData(prev => ({
      ...prev,
      title: template.name,
      description: template.description,
      duration: template.duration,
      scenes: template.scenes
    }));
  };

  const handleGenerateVideo = async () => {
    if (!formData.title || !formData.description) {
      alert('Please fill in title and description');
      return;
    }

    setIsGenerating(true);
    try {
      const data = await apiClient.generateVideo(formData);
      if (data.video_id) {
        setGeneratedVideos(prev => [data, ...prev]);
        setFormData({
          title: '',
          description: '',
          duration: 30,
          style: 'modern',
          format: 'mp4',
          resolution: '1080p',
          scenes: []
        });
        setSelectedTemplate(null);
        alert('Video generated successfully!');
      }
    } catch (error) {
      console.error('Error generating video:', error);
      alert('Error generating video');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleInputChange = (field: keyof VideoGenerationRequest, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Video Generation</h1>
        <Badge variant="secondary">AI-Powered</Badge>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList>
          <TabsTrigger value="create">Create Video</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="library">Video Library</TabsTrigger>
        </TabsList>

        <TabsContent value="create" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Create New Video</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Video Title</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => handleInputChange('title', e.target.value)}
                    placeholder="Enter video title"
                  />
                </div>
                <div>
                  <Label htmlFor="duration">Duration (seconds)</Label>
                  <Input
                    id="duration"
                    type="number"
                    value={formData.duration}
                    onChange={(e) => handleInputChange('duration', parseInt(e.target.value))}
                    min="5"
                    max="600"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="description">Description</Label>
                <textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  placeholder="Describe your video content"
                  className="w-full p-3 border border-gray-300 rounded-md h-24 resize-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="style">Style</Label>
                  <select
                    id="style"
                    value={formData.style}
                    onChange={(e) => handleInputChange('style', e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md"
                  >
                    <option value="modern">Modern</option>
                    <option value="classic">Classic</option>
                    <option value="minimalist">Minimalist</option>
                    <option value="bold">Bold</option>
                    <option value="elegant">Elegant</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="resolution">Resolution</Label>
                  <select
                    id="resolution"
                    value={formData.resolution}
                    onChange={(e) => handleInputChange('resolution', e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md"
                  >
                    <option value="720p">720p</option>
                    <option value="1080p">1080p</option>
                    <option value="4k">4K</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="format">Format</Label>
                  <select
                    id="format"
                    value={formData.format}
                    onChange={(e) => handleInputChange('format', e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md"
                  >
                    <option value="mp4">MP4</option>
                    <option value="mov">MOV</option>
                    <option value="avi">AVI</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end">
                <Button
                  onClick={handleGenerateVideo}
                  disabled={isGenerating}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isGenerating ? 'Generating...' : 'Generate Video'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Video Templates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {templates.map((template) => (
                  <Card
                    key={template.template_id}
                    className={`cursor-pointer transition-all hover:shadow-lg ${
                      selectedTemplate?.template_id === template.template_id
                        ? 'ring-2 ring-blue-500'
                        : ''
                    }`}
                    onClick={() => handleTemplateSelect(template)}
                  >
                    <CardContent className="p-4">
                      <img
                        src={template.thumbnail_url}
                        alt={template.name}
                        className="w-full h-32 object-cover rounded-md mb-3"
                      />
                      <h3 className="font-semibold text-lg mb-2">{template.name}</h3>
                      <p className="text-gray-600 text-sm mb-3">{template.description}</p>
                      <div className="flex justify-between items-center">
                                                 <Badge variant="secondary">{template.category}</Badge>
                        <span className="text-sm text-gray-500">{template.duration}s</span>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {template.tags.map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="library" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Generated Videos</CardTitle>
            </CardHeader>
            <CardContent>
              {generatedVideos.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No videos generated yet</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {generatedVideos.map((video) => (
                    <Card key={video.video_id}>
                      <CardContent className="p-4">
                        <img
                          src={video.preview_url || 'https://via.placeholder.com/300x200?text=Video+Preview'}
                          alt={video.metadata.title}
                          className="w-full h-32 object-cover rounded-md mb-3"
                        />
                        <h3 className="font-semibold text-lg mb-2">{video.metadata.title}</h3>
                        <p className="text-gray-600 text-sm mb-3">{video.metadata.description}</p>
                        <div className="flex justify-between items-center mb-3">
                          <Badge variant={video.status === 'completed' ? 'default' : 'secondary'}>
                            {video.status}
                          </Badge>
                          <span className="text-sm text-gray-500">{video.duration}s</span>
                        </div>
                        <div className="flex gap-2">
                          {video.download_url && (
                            <Button
                              size="sm"
                              onClick={() => window.open(video.download_url, '_blank')}
                              className="flex-1"
                            >
                              Download
                            </Button>
                          )}
                          {video.preview_url && (
                            <Button
                              size="sm"
                              variant="secondary"
                              onClick={() => window.open(video.preview_url, '_blank')}
                              className="flex-1"
                            >
                              Preview
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
} 