'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth';
import { Business, BusinessAnalytics } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/Button';
import ClientOnly from '@/components/auth/ClientOnly';
import {
  BuildingOfficeIcon,
  MapPinIcon,
  UsersIcon,
  ChatBubbleLeftRightIcon,
  ChartBarIcon,
  CurrencyDollarIcon,
  UserGroupIcon,
  ArrowLeftIcon,
  PencilIcon,
  PlusIcon,
  Cog6ToothIcon,
  UserPlusIcon,
  DocumentIcon,
  ExclamationTriangleIcon,
  DocumentTextIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

interface BusinessWithAnalytics extends Business {
  analytics?: BusinessAnalytics;
}

export default function BusinessDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { isAuthenticated, isLoading } = useAuthStore();
  const [business, setBusiness] = useState<BusinessWithAnalytics | null>(null);
  const [analytics, setAnalytics] = useState<BusinessAnalytics | null>(null);
  const [loading, setLoading] = useState(true);

  const businessId = parseInt(params.id as string);

  useEffect(() => {
    if (isAuthenticated && !isLoading && businessId) {
      fetchBusinessData();
    }
  }, [isAuthenticated, isLoading, businessId]);

  const fetchBusinessData = async () => {
    try {
      setLoading(true);
      
      // Fetch business details
      const businessData = await apiClient.getBusiness(businessId);
      setBusiness(businessData);

      // Fetch analytics
      try {
        const analyticsData = await apiClient.getBusinessAnalytics(businessId);
        setAnalytics(analyticsData);
      } catch (error) {
        console.error('Failed to fetch analytics:', error);
      }

    } catch (error) {
      console.error('Failed to fetch business data:', error);
      toast.error('Failed to load business details');
    } finally {
      setLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-secondary-900 mb-2">Authentication Required</h2>
            <p className="text-secondary-600">Please log in to access business details.</p>
          </div>
        </div>
      </div>
    );
  }

  if (!business) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-secondary-900 mb-2">Business Not Found</h2>
            <p className="text-secondary-600">The business you're looking for doesn't exist.</p>
            <Button onClick={() => router.push('/businesses')} className="mt-4">
              Back to Businesses
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ClientOnly>
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-secondary-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => router.push('/businesses')}
                leftIcon={<ArrowLeftIcon className="h-4 w-4" />}
              >
                Back
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-secondary-900">
                  {business.name}
                </h1>
                <p className="text-secondary-600">
                  Business Details & Analytics
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Button
                variant="secondary"
                leftIcon={<PencilIcon className="h-4 w-4" />}
                onClick={() => router.push(`/businesses/${business.id}/edit`)}
              >
                Edit Business
              </Button>
              <Button
                leftIcon={<PlusIcon className="h-4 w-4" />}
                onClick={() => router.push(`/campaigns/create?businessId=${business.id}`)}
              >
                New Campaign
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Business Info & Analytics */}
            <div className="lg:col-span-2 space-y-6">
              {/* Business Information */}
              <div className="bg-white rounded-lg border border-secondary-200 p-6">
                <h2 className="text-lg font-semibold text-secondary-900 mb-4">Business Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-3">
                    <BuildingOfficeIcon className="h-5 w-5 text-primary-600" />
                    <div>
                      <p className="text-sm font-medium text-secondary-600">Industry</p>
                      <p className="text-secondary-900">{business.industry}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPinIcon className="h-5 w-5 text-primary-600" />
                    <div>
                      <p className="text-sm font-medium text-secondary-600">Location</p>
                      <p className="text-secondary-900">{business.location}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <UsersIcon className="h-5 w-5 text-primary-600" />
                    <div>
                      <p className="text-sm font-medium text-secondary-600">Target Audience</p>
                      <p className="text-secondary-900">{business.target_audience}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <ChatBubbleLeftRightIcon className="h-5 w-5 text-primary-600" />
                    <div>
                      <p className="text-sm font-medium text-secondary-600">Brand Voice</p>
                      <p className="text-secondary-900">{business.brand_voice}</p>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-secondary-200">
                  <div className="flex items-center justify-between text-sm text-secondary-500">
                    <span>Created {new Date(business.created_at).toLocaleDateString()}</span>
                    <span>Last updated {new Date(business.updated_at).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>

              {/* Analytics Overview */}
              {analytics && (
                <div className="bg-white rounded-lg border border-secondary-200 p-6">
                  <h2 className="text-lg font-semibold text-secondary-900 mb-4">Performance Analytics</h2>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="flex items-center justify-center mb-2">
                        <ChartBarIcon className="h-8 w-8 text-green-600" />
                      </div>
                      <p className="text-2xl font-bold text-secondary-900">{analytics.active_campaigns}</p>
                      <p className="text-sm text-secondary-600">Active Campaigns</p>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center mb-2">
                        <UserGroupIcon className="h-8 w-8 text-blue-600" />
                      </div>
                      <p className="text-2xl font-bold text-secondary-900">{analytics.total_leads}</p>
                      <p className="text-sm text-secondary-600">Total Leads</p>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center mb-2">
                        <CurrencyDollarIcon className="h-8 w-8 text-yellow-600" />
                      </div>
                      <p className="text-2xl font-bold text-secondary-900">{analytics.conversion_rate}%</p>
                      <p className="text-sm text-secondary-600">Conversion Rate</p>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center mb-2">
                        <CurrencyDollarIcon className="h-8 w-8 text-purple-600" />
                      </div>
                      <p className="text-2xl font-bold text-secondary-900">
                        ${analytics.campaign_performance?.reduce((sum, p) => sum + p.revenue, 0) || 0}
                      </p>
                      <p className="text-sm text-secondary-600">Total Revenue</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Right Column - Quick Actions */}
            <div className="space-y-6">
              {/* Quick Actions */}
              <div className="bg-white rounded-lg border border-secondary-200 p-6">
                <h2 className="text-lg font-semibold text-secondary-900 mb-4">Quick Actions</h2>
                <div className="space-y-3">
                  <Button 
                    className="w-full justify-start" 
                    variant="secondary"
                    onClick={() => router.push(`/campaigns/create?businessId=${business.id}`)}
                  >
                    <PlusIcon className="h-4 w-4 mr-2" />
                    Create Campaign
                  </Button>
                  <Button 
                    className="w-full justify-start" 
                    variant="secondary"
                    onClick={() => router.push(`/leads?businessId=${business.id}`)}
                  >
                    <UserGroupIcon className="h-4 w-4 mr-2" />
                    Add Lead
                  </Button>
                  <Button 
                    className="w-full justify-start" 
                    variant="secondary"
                    onClick={() => router.push(`/analytics?businessId=${business.id}`)}
                  >
                    <ChartBarIcon className="h-4 w-4 mr-2" />
                    View Analytics
                  </Button>
                  <Button 
                    className="w-full justify-start" 
                    variant="secondary"
                    onClick={() => router.push(`/content?businessId=${business.id}`)}
                  >
                    <ChatBubbleLeftRightIcon className="h-4 w-4 mr-2" />
                    Generate Content
                  </Button>
                  <Button 
                    className="w-full justify-start" 
                    variant="secondary"
                    onClick={() => router.push(`/landing-pages?businessId=${business.id}`)}
                  >
                    <BuildingOfficeIcon className="h-4 w-4 mr-2" />
                    Create Landing Page
                  </Button>
                  <Button 
                    className="w-full justify-start" 
                    variant="secondary"
                    onClick={() => router.push(`/settings?businessId=${business.id}`)}
                  >
                    <Cog6ToothIcon className="h-4 w-4 mr-2" />
                    Settings & API Keys
                  </Button>
                  <Button 
                    className="w-full justify-start" 
                    variant="secondary"
                    onClick={() => router.push(`/target-audiences?businessId=${business.id}`)}
                  >
                    <UserPlusIcon className="h-4 w-4 mr-2" />
                    Target Audiences
                  </Button>
                  <Button 
                    className="w-full justify-start" 
                    variant="secondary"
                    onClick={() => router.push(`/businesses/${business.id}/documents`)}
                  >
                    <DocumentIcon className="h-4 w-4 mr-2" />
                    Documents & Files
                  </Button>
                  <Button 
                    className="w-full justify-start" 
                    variant="secondary"
                    onClick={() => router.push(`/businesses/${business.id}/competitors`)}
                  >
                    <ExclamationTriangleIcon className="h-4 w-4 mr-2" />
                    Competitor Tracking
                  </Button>
                  <Button 
                    className="w-full justify-start" 
                    variant="secondary"
                    onClick={() => router.push(`/businesses/${business.id}/portfolio`)}
                  >
                    <DocumentTextIcon className="h-4 w-4 mr-2" />
                    Content Portfolio
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
    </ClientOnly>
  );
} 