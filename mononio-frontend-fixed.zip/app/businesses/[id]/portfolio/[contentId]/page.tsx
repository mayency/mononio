'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth';
import { Business } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import Input from '@/components/ui/Input';
import ClientOnly from '@/components/auth/ClientOnly';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import {
  ArrowLeftIcon,
  PencilIcon,
  TrashIcon,
  DocumentTextIcon,
  PhotoIcon,
  VideoCameraIcon,
  GlobeAltIcon,
  UserGroupIcon,
  ChartBarIcon,
  CalendarIcon,
  TagIcon,
  ClockIcon,
  StarIcon,
  ChatBubbleLeftIcon,
  ShareIcon,
  CogIcon,
  PlayIcon,
  PauseIcon,
  CheckIcon,
  XMarkIcon,
  EyeIcon,
  DownloadIcon,
  ArchiveBoxIcon,
  DocumentDuplicateIcon,
  HistoryIcon,
  UserIcon,
  HeartIcon,
  ReplyIcon,
  FlagIcon,
  EllipsisVerticalIcon
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

interface PortfolioItem {
  id: number;
  content_id: string;
  content_type: string;
  content_name: string;
  content_description: string;
  category: string;
  subcategory: string;
  platform: string;
  content_data: any;
  content_metadata: any;
  version: number;
  is_draft: boolean;
  is_published: boolean;
  status: string;
  performance_metrics: any;
  created_at: string;
  updated_at: string;
  published_at: string | null;
  view_count: number;
  edit_count: number;
  last_accessed_at: string;
  tags: string[];
  keywords: string[];
  seo_title: string;
  seo_description: string;
  attachments: any[];
  ai_generated: boolean;
  ai_prompt: string;
  ai_model: string;
  ai_confidence: number;
  analytics?: any[];
}

interface Version {
  id: number;
  version_number: number;
  version_name: string;
  version_description: string;
  content_data: any;
  content_metadata: any;
  created_by: string;
  created_at: string;
  change_summary: string;
  is_current: boolean;
}

interface Comment {
  id: number;
  user_id: string;
  comment_text: string;
  comment_type: string;
  parent_comment_id?: number;
  is_resolved: boolean;
  is_private: boolean;
  created_at: string;
  updated_at: string;
  likes: number;
  replies: number;
  is_flagged: boolean;
}

const CONTENT_TYPE_ICONS: { [key: string]: any } = {
  campaign: ChartBarIcon,
  post: DocumentTextIcon,
  video: VideoCameraIcon,
  landing_page: GlobeAltIcon,
  target_audience: UserGroupIcon,
  ad: PhotoIcon,
  email: DocumentTextIcon,
  article: DocumentTextIcon,
  story: DocumentTextIcon,
  general: DocumentTextIcon
};

const CONTENT_TYPE_LABELS: { [key: string]: string } = {
  campaign: 'Campaign',
  post: 'Social Post',
  video: 'Video',
  landing_page: 'Landing Page',
  target_audience: 'Target Audience',
  ad: 'Advertisement',
  email: 'Email',
  article: 'Article',
  story: 'Story',
  general: 'Content'
};

const STATUS_COLORS: { [key: string]: string } = {
  draft: 'bg-gray-100 text-gray-800',
  published: 'bg-green-100 text-green-800',
  archived: 'bg-yellow-100 text-yellow-800',
  deleted: 'bg-red-100 text-red-800'
};

export default function PortfolioItemPage() {
  const params = useParams();
  const router = useRouter();
  const { isAuthenticated, isLoading } = useAuthStore();
  const [business, setBusiness] = useState<Business | null>(null);
  const [portfolioItem, setPortfolioItem] = useState<PortfolioItem | null>(null);
  const [versions, setVersions] = useState<Version[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [analytics, setAnalytics] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showVersionModal, setShowVersionModal] = useState(false);
  const [showCommentModal, setShowCommentModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'versions' | 'comments' | 'analytics'>('overview');
  const [newComment, setNewComment] = useState('');
  const [selectedVersion, setSelectedVersion] = useState<Version | null>(null);

  const businessId = params.id as string;
  const contentId = params.contentId as string;

  useEffect(() => {
    if (isAuthenticated && !isLoading && businessId && contentId) {
      fetchBusinessData();
      fetchPortfolioItem();
    }
  }, [isAuthenticated, isLoading, businessId, contentId]);

  const fetchBusinessData = async () => {
    try {
      const businessData = await apiClient.getBusiness(parseInt(businessId));
      setBusiness(businessData);
    } catch (error) {
      console.error('Failed to fetch business data:', error);
      toast.error('Failed to load business details');
    }
  };

  const fetchPortfolioItem = async () => {
    try {
      setLoading(true);
      const response = await apiClient.getBusinessPortfolioItem(businessId, contentId);
      
      if (response.success) {
        setPortfolioItem(response.portfolio_item);
        setVersions(response.versions || []);
        setComments(response.comments || []);
        setAnalytics(response.analytics || []);
      } else {
        toast.error(response.error || 'Failed to load portfolio item');
        router.push(`/businesses/${businessId}/portfolio`);
      }
    } catch (error) {
      console.error('Failed to fetch portfolio item:', error);
      toast.error('Failed to load portfolio item');
      router.push(`/businesses/${businessId}/portfolio`);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateItem = async () => {
    if (!portfolioItem) return;
    
    try {
      const response = await apiClient.updateBusinessPortfolioItem(
        businessId,
        contentId,
        {
          content_name: portfolioItem.content_name,
          content_description: portfolioItem.content_description,
          category: portfolioItem.category,
          subcategory: portfolioItem.subcategory,
          platform: portfolioItem.platform,
          content_data: portfolioItem.content_data,
          content_metadata: portfolioItem.content_metadata,
          is_draft: portfolioItem.is_draft,
          is_published: portfolioItem.is_published,
          status: portfolioItem.status,
          tags: portfolioItem.tags,
          keywords: portfolioItem.keywords,
          seo_title: portfolioItem.seo_title,
          seo_description: portfolioItem.seo_description,
          attachments: portfolioItem.attachments,
          version_name: `Version ${portfolioItem.version + 1}`,
          version_description: 'Content updated',
          change_summary: 'Content updated'
        }
      );
      
      if (response.success) {
        toast.success('Content updated successfully!');
        setEditing(false);
        fetchPortfolioItem();
      } else {
        toast.error(response.error || 'Failed to update content');
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to update content');
    }
  };

  const handleDeleteItem = async () => {
    try {
      const response = await apiClient.deleteBusinessPortfolioItem(businessId, contentId);
      
      if (response.success) {
        toast.success('Content deleted successfully!');
        router.push(`/businesses/${businessId}/portfolio`);
      } else {
        toast.error(response.error || 'Failed to delete content');
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete content');
    }
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newComment.trim()) return;
    
    try {
      const response = await apiClient.addPortfolioComment(businessId, contentId, {
        comment_text: newComment,
        comment_type: 'general'
      });
      
      if (response.success) {
        toast.success('Comment added successfully!');
        setNewComment('');
        setShowCommentModal(false);
        fetchPortfolioItem();
      } else {
        toast.error(response.error || 'Failed to add comment');
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to add comment');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getContentTypeIcon = (contentType: string) => {
    return CONTENT_TYPE_ICONS[contentType] || DocumentTextIcon;
  };

  const getContentTypeLabel = (contentType: string) => {
    return CONTENT_TYPE_LABELS[contentType] || 'Content';
  };

  const renderContentPreview = () => {
    if (!portfolioItem) return null;

    const contentType = portfolioItem.content_type;
    const contentData = portfolioItem.content_data;

    switch (contentType) {
      case 'landing_page':
        return (
          <div className="bg-white border rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Landing Page Preview</h3>
            <div className="space-y-4">
              {contentData.hero && (
                <div>
                  <h4 className="font-medium text-secondary-900">Hero Section</h4>
                  <p className="text-secondary-600">{contentData.hero.headline}</p>
                  <p className="text-secondary-500 text-sm">{contentData.hero.subheadline}</p>
                </div>
              )}
              {contentData.features && (
                <div>
                  <h4 className="font-medium text-secondary-900">Features</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {contentData.features.map((feature: any, index: number) => (
                      <div key={index} className="p-3 bg-secondary-50 rounded">
                        <div className="text-2xl mb-2">{feature.icon}</div>
                        <h5 className="font-medium">{feature.title}</h5>
                        <p className="text-sm text-secondary-600">{feature.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        );

      case 'post':
        return (
          <div className="bg-white border rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Social Post Preview</h3>
            <div className="space-y-4">
              <p className="text-secondary-900">{contentData.text}</p>
              {contentData.media && (
                <div className="bg-secondary-100 rounded-lg p-4 text-center">
                  <PhotoIcon className="h-12 w-12 text-secondary-400 mx-auto mb-2" />
                  <p className="text-sm text-secondary-600">Media attached</p>
                </div>
              )}
            </div>
          </div>
        );

      case 'video':
        return (
          <div className="bg-white border rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Video Preview</h3>
            <div className="space-y-4">
              <div className="bg-secondary-100 rounded-lg p-4 text-center">
                <VideoCameraIcon className="h-12 w-12 text-secondary-400 mx-auto mb-2" />
                <p className="text-sm text-secondary-600">Video content</p>
              </div>
              {contentData.description && (
                <p className="text-secondary-900">{contentData.description}</p>
              )}
            </div>
          </div>
        );

      default:
        return (
          <div className="bg-white border rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Content Preview</h3>
            <pre className="text-sm text-secondary-600 bg-secondary-50 p-4 rounded overflow-auto">
              {JSON.stringify(contentData, null, 2)}
            </pre>
          </div>
        );
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (!portfolioItem) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-secondary-900 mb-2">Content Not Found</h2>
            <p className="text-secondary-600">The content you're looking for doesn't exist.</p>
            <Button onClick={() => router.push(`/businesses/${businessId}/portfolio`)} className="mt-4">
              Back to Portfolio
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const IconComponent = getContentTypeIcon(portfolioItem.content_type);

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="bg-white border-b border-secondary-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  variant="ghost"
                  onClick={() => router.push(`/businesses/${businessId}/portfolio`)}
                  leftIcon={<ArrowLeftIcon className="h-4 w-4" />}
                >
                  Back
                </Button>
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-primary-100 rounded-lg">
                    <IconComponent className="h-6 w-6 text-primary-600" />
                  </div>
                  <div>
                    <h1 className="text-xl font-bold text-secondary-900">
                      {portfolioItem.content_name}
                    </h1>
                    <p className="text-secondary-600">
                      {getContentTypeLabel(portfolioItem.content_type)} • {business?.name}
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <span className={`px-3 py-1 text-sm font-medium rounded-full ${STATUS_COLORS[portfolioItem.status] || STATUS_COLORS.draft}`}>
                  {portfolioItem.status}
                </span>
                {portfolioItem.ai_generated && (
                  <div className="flex items-center space-x-1 text-yellow-600">
                    <StarIcon className="h-4 w-4" />
                    <span className="text-sm">AI Generated</span>
                  </div>
                )}
                <Button
                  variant="secondary"
                  onClick={() => setShowCommentModal(true)}
                  leftIcon={<ChatBubbleLeftIcon className="h-4 w-4" />}
                >
                  Comment
                </Button>
                <Button
                  variant="secondary"
                  onClick={() => setEditing(!editing)}
                  leftIcon={<PencilIcon className="h-4 w-4" />}
                >
                  {editing ? 'Cancel' : 'Edit'}
                </Button>
                <Button
                  variant="secondary"
                  onClick={() => setShowDeleteModal(true)}
                  leftIcon={<TrashIcon className="h-4 w-4" />}
                  className="text-red-600 hover:text-red-700"
                >
                  Delete
                </Button>
              </div>
            </div>
          </header>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto p-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main Content Area */}
              <div className="lg:col-span-2 space-y-6">
                {/* Content Details */}
                <Card>
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h2 className="text-lg font-semibold text-secondary-900">Content Details</h2>
                      <div className="flex items-center space-x-2 text-sm text-secondary-500">
                        <span>v{portfolioItem.version}</span>
                        <span>•</span>
                        <span>{portfolioItem.view_count} views</span>
                        <span>•</span>
                        <span>{portfolioItem.edit_count} edits</span>
                      </div>
                    </div>
                    
                    {editing ? (
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-secondary-700 mb-1">
                            Content Name
                          </label>
                          <input
                            type="text"
                            value={portfolioItem.content_name}
                            onChange={(e) => setPortfolioItem({ ...portfolioItem, content_name: e.target.value })}
                            className="w-full px-3 py-2 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-secondary-700 mb-1">
                            Description
                          </label>
                          <textarea
                            value={portfolioItem.content_description}
                            onChange={(e) => setPortfolioItem({ ...portfolioItem, content_description: e.target.value })}
                            className="w-full px-3 py-2 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                            rows={3}
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-secondary-700 mb-1">
                              Category
                            </label>
                            <select
                              value={portfolioItem.category}
                              onChange={(e) => setPortfolioItem({ ...portfolioItem, category: e.target.value })}
                              className="w-full px-3 py-2 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                            >
                              <option value="marketing">Marketing</option>
                              <option value="sales">Sales</option>
                              <option value="branding">Branding</option>
                              <option value="content">Content</option>
                            </select>
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium text-secondary-700 mb-1">
                              Platform
                            </label>
                            <select
                              value={portfolioItem.platform}
                              onChange={(e) => setPortfolioItem({ ...portfolioItem, platform: e.target.value })}
                              className="w-full px-3 py-2 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                            >
                              <option value="general">General</option>
                              <option value="facebook">Facebook</option>
                              <option value="instagram">Instagram</option>
                              <option value="twitter">Twitter</option>
                              <option value="linkedin">LinkedIn</option>
                              <option value="website">Website</option>
                            </select>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center">
                            <input
                              type="checkbox"
                              id="is_draft"
                              checked={portfolioItem.is_draft}
                              onChange={(e) => setPortfolioItem({ ...portfolioItem, is_draft: e.target.checked })}
                              className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-secondary-300 rounded"
                            />
                            <label htmlFor="is_draft" className="ml-2 block text-sm text-secondary-900">
                              Draft
                            </label>
                          </div>
                          
                          <div className="flex items-center">
                            <input
                              type="checkbox"
                              id="is_published"
                              checked={portfolioItem.is_published}
                              onChange={(e) => setPortfolioItem({ ...portfolioItem, is_published: e.target.checked })}
                              className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-secondary-300 rounded"
                            />
                            <label htmlFor="is_published" className="ml-2 block text-sm text-secondary-900">
                              Published
                            </label>
                          </div>
                        </div>
                        
                        <div className="flex space-x-3 pt-4">
                          <Button
                            variant="secondary"
                            onClick={() => setEditing(false)}
                            className="flex-1"
                          >
                            Cancel
                          </Button>
                          <Button
                            onClick={handleUpdateItem}
                            className="flex-1"
                          >
                            Save Changes
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div>
                          <h3 className="font-medium text-secondary-900">Description</h3>
                          <p className="text-secondary-600">{portfolioItem.content_description || 'No description available'}</p>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <h3 className="font-medium text-secondary-900">Category</h3>
                            <p className="text-secondary-600 capitalize">{portfolioItem.category}</p>
                          </div>
                          <div>
                            <h3 className="font-medium text-secondary-900">Platform</h3>
                            <p className="text-secondary-600 capitalize">{portfolioItem.platform}</p>
                          </div>
                        </div>
                        
                        {portfolioItem.tags.length > 0 && (
                          <div>
                            <h3 className="font-medium text-secondary-900 mb-2">Tags</h3>
                            <div className="flex flex-wrap gap-2">
                              {portfolioItem.tags.map((tag, index) => (
                                <span
                                  key={index}
                                  className="px-2 py-1 text-xs bg-secondary-100 text-secondary-700 rounded-full"
                                >
                                  {tag}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <h3 className="font-medium text-secondary-900">Created</h3>
                            <p className="text-secondary-600">{formatDate(portfolioItem.created_at)}</p>
                          </div>
                          <div>
                            <h3 className="font-medium text-secondary-900">Last Updated</h3>
                            <p className="text-secondary-600">{formatDate(portfolioItem.updated_at)}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </Card>

                {/* Content Preview */}
                {renderContentPreview()}

                {/* Tabs */}
                <Card>
                  <div className="p-6">
                    <div className="border-b border-secondary-200 mb-6">
                      <nav className="flex space-x-8">
                        {[
                          { id: 'overview', label: 'Overview', icon: EyeIcon },
                          { id: 'versions', label: 'Versions', icon: HistoryIcon },
                          { id: 'comments', label: 'Comments', icon: ChatBubbleLeftIcon },
                          { id: 'analytics', label: 'Analytics', icon: ChartBarIcon }
                        ].map((tab) => {
                          const IconComponent = tab.icon;
                          return (
                            <button
                              key={tab.id}
                              onClick={() => setActiveTab(tab.id as any)}
                              className={`flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm ${
                                activeTab === tab.id
                                  ? 'border-primary-500 text-primary-600'
                                  : 'border-transparent text-secondary-500 hover:text-secondary-700 hover:border-secondary-300'
                              }`}
                            >
                              <IconComponent className="h-4 w-4" />
                              <span>{tab.label}</span>
                            </button>
                          );
                        })}
                      </nav>
                    </div>

                    {/* Tab Content */}
                    {activeTab === 'overview' && (
                      <div className="space-y-4">
                        <div>
                          <h3 className="font-medium text-secondary-900 mb-2">Performance Metrics</h3>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div className="text-center p-3 bg-secondary-50 rounded">
                              <div className="text-2xl font-bold text-primary-600">{portfolioItem.view_count}</div>
                              <div className="text-sm text-secondary-600">Views</div>
                            </div>
                            <div className="text-center p-3 bg-secondary-50 rounded">
                              <div className="text-2xl font-bold text-green-600">{portfolioItem.edit_count}</div>
                              <div className="text-sm text-secondary-600">Edits</div>
                            </div>
                            <div className="text-center p-3 bg-secondary-50 rounded">
                              <div className="text-2xl font-bold text-blue-600">{comments.length}</div>
                              <div className="text-sm text-secondary-600">Comments</div>
                            </div>
                            <div className="text-center p-3 bg-secondary-50 rounded">
                              <div className="text-2xl font-bold text-purple-600">{versions.length}</div>
                              <div className="text-sm text-secondary-600">Versions</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}

                    {activeTab === 'versions' && (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium text-secondary-900">Version History</h3>
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => setShowVersionModal(true)}
                          >
                            Create Version
                          </Button>
                        </div>
                        
                        <div className="space-y-3">
                          {versions.map((version) => (
                            <div
                              key={version.id}
                              className={`p-4 border rounded-lg ${
                                version.is_current ? 'border-primary-200 bg-primary-50' : 'border-secondary-200'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <div>
                                  <h4 className="font-medium text-secondary-900">
                                    {version.version_name}
                                  </h4>
                                  <p className="text-sm text-secondary-600">{version.version_description}</p>
                                  <p className="text-xs text-secondary-500 mt-1">
                                    {formatDate(version.created_at)} by {version.created_by}
                                  </p>
                                </div>
                                <div className="flex items-center space-x-2">
                                  {version.is_current && (
                                    <span className="px-2 py-1 text-xs bg-primary-100 text-primary-800 rounded-full">
                                      Current
                                    </span>
                                  )}
                                  <Button
                                    size="sm"
                                    variant="secondary"
                                    onClick={() => setSelectedVersion(version)}
                                  >
                                    View
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {activeTab === 'comments' && (
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium text-secondary-900">Comments & Feedback</h3>
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => setShowCommentModal(true)}
                          >
                            Add Comment
                          </Button>
                        </div>
                        
                        <div className="space-y-4">
                          {comments.map((comment) => (
                            <div key={comment.id} className="p-4 border border-secondary-200 rounded-lg">
                              <div className="flex items-start justify-between">
                                <div className="flex items-start space-x-3">
                                  <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                                    <UserIcon className="h-4 w-4 text-primary-600" />
                                  </div>
                                  <div className="flex-1">
                                    <div className="flex items-center space-x-2 mb-1">
                                      <span className="font-medium text-secondary-900">{comment.user_id}</span>
                                      <span className="text-xs text-secondary-500">{formatDate(comment.created_at)}</span>
                                    </div>
                                    <p className="text-secondary-700">{comment.comment_text}</p>
                                  </div>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <button className="p-1 text-secondary-400 hover:text-secondary-600">
                                    <HeartIcon className="h-4 w-4" />
                                  </button>
                                  <button className="p-1 text-secondary-400 hover:text-secondary-600">
                                    <ReplyIcon className="h-4 w-4" />
                                  </button>
                                  <button className="p-1 text-secondary-400 hover:text-secondary-600">
                                    <FlagIcon className="h-4 w-4" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {activeTab === 'analytics' && (
                      <div className="space-y-4">
                        <h3 className="font-medium text-secondary-900">Performance Analytics</h3>
                        
                        {analytics.length > 0 ? (
                          <div className="space-y-4">
                            {analytics.map((analytic, index) => (
                              <div key={index} className="p-4 border border-secondary-200 rounded-lg">
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                  <div>
                                    <div className="text-sm text-secondary-600">Views</div>
                                    <div className="text-lg font-semibold">{analytic.views || 0}</div>
                                  </div>
                                  <div>
                                    <div className="text-sm text-secondary-600">Engagements</div>
                                    <div className="text-lg font-semibold">{analytic.engagements || 0}</div>
                                  </div>
                                  <div>
                                    <div className="text-sm text-secondary-600">Conversions</div>
                                    <div className="text-lg font-semibold">{analytic.conversions || 0}</div>
                                  </div>
                                  <div>
                                    <div className="text-sm text-secondary-600">Revenue</div>
                                    <div className="text-lg font-semibold">${analytic.revenue || 0}</div>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-8">
                            <ChartBarIcon className="mx-auto h-12 w-12 text-secondary-400" />
                            <h3 className="mt-2 text-sm font-medium text-secondary-900">No analytics data</h3>
                            <p className="mt-1 text-sm text-secondary-500">
                              Analytics data will appear here once the content is published and starts receiving traffic.
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </Card>
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Quick Actions */}
                <Card>
                  <div className="p-6">
                    <h3 className="font-medium text-secondary-900 mb-4">Quick Actions</h3>
                    <div className="space-y-3">
                      <Button
                        variant="secondary"
                        className="w-full justify-start"
                        leftIcon={<DocumentDuplicateIcon className="h-4 w-4" />}
                      >
                        Duplicate
                      </Button>
                      <Button
                        variant="secondary"
                        className="w-full justify-start"
                        leftIcon={<ShareIcon className="h-4 w-4" />}
                      >
                        Share
                      </Button>
                      <Button
                        variant="secondary"
                        className="w-full justify-start"
                        leftIcon={<DownloadIcon className="h-4 w-4" />}
                      >
                        Export
                      </Button>
                      <Button
                        variant="secondary"
                        className="w-full justify-start"
                        leftIcon={<ArchiveBoxIcon className="h-4 w-4" />}
                      >
                        Archive
                      </Button>
                    </div>
                  </div>
                </Card>

                {/* AI Generation Info */}
                {portfolioItem.ai_generated && (
                  <Card>
                    <div className="p-6">
                      <div className="flex items-center space-x-2 mb-4">
                        <StarIcon className="h-5 w-5 text-yellow-500" />
                        <h3 className="font-medium text-secondary-900">AI Generated</h3>
                      </div>
                      <div className="space-y-3 text-sm">
                        <div>
                          <div className="text-secondary-600">Model</div>
                          <div className="font-medium">{portfolioItem.ai_model}</div>
                        </div>
                        <div>
                          <div className="text-secondary-600">Confidence</div>
                          <div className="font-medium">{(portfolioItem.ai_confidence * 100).toFixed(1)}%</div>
                        </div>
                        {portfolioItem.ai_prompt && (
                          <div>
                            <div className="text-secondary-600">Prompt</div>
                            <div className="text-xs bg-secondary-50 p-2 rounded">
                              {portfolioItem.ai_prompt}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                )}

                {/* Attachments */}
                {portfolioItem.attachments.length > 0 && (
                  <Card>
                    <div className="p-6">
                      <h3 className="font-medium text-secondary-900 mb-4">Attachments</h3>
                      <div className="space-y-2">
                        {portfolioItem.attachments.map((attachment, index) => (
                          <div key={index} className="flex items-center space-x-3 p-2 bg-secondary-50 rounded">
                            <DocumentTextIcon className="h-4 w-4 text-secondary-400" />
                            <span className="text-sm text-secondary-700 flex-1 truncate">
                              {attachment.name || `Attachment ${index + 1}`}
                            </span>
                            <Button size="sm" variant="ghost">
                              <DownloadIcon className="h-3 w-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </Card>
                )}
              </div>
            </div>
          </main>
        </div>

        {/* Comment Modal */}
        {showCommentModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
              <div className="p-6">
                <h2 className="text-xl font-semibold text-secondary-900 mb-4">
                  Add Comment
                </h2>
                
                <form onSubmit={handleAddComment} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-secondary-700 mb-1">
                      Comment
                    </label>
                    <textarea
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      className="w-full px-3 py-2 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                      rows={4}
                      placeholder="Enter your comment..."
                      required
                    />
                  </div>
                  
                  <div className="flex space-x-3 pt-4">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setShowCommentModal(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button type="submit" className="flex-1">
                      Add Comment
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}

        {/* Delete Modal */}
        {showDeleteModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
              <div className="p-6">
                <h2 className="text-xl font-semibold text-secondary-900 mb-4">
                  Delete Content
                </h2>
                <p className="text-secondary-600 mb-6">
                  Are you sure you want to delete "{portfolioItem?.content_name}"? This action cannot be undone.
                </p>
                <div className="flex space-x-3">
                  <Button
                    variant="secondary"
                    onClick={() => setShowDeleteModal(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleDeleteItem}
                    className="flex-1 bg-red-600 hover:bg-red-700"
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
} 