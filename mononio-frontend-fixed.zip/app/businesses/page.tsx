'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth';
import { Business, BusinessCreate, BusinessAnalytics } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import ClientOnly from '@/components/auth/ClientOnly';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import {
  PlusIcon,
  MagnifyingGlassIcon,
  BuildingOfficeIcon,
  MapPinIcon,
  UsersIcon,
  ChatBubbleLeftRightIcon,
  EyeIcon,
  PencilIcon,
  TrashIcon,
  FunnelIcon,
  ChartBarIcon,
  CogIcon,
  CalendarIcon,
  CurrencyDollarIcon,
  UserGroupIcon,
  SparklesIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  CheckCircleIcon,
  ExclamationTriangleIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { getErrorMessage } from '@/lib/getErrorMessage';

interface BusinessWithAnalytics extends Business {
  analytics?: BusinessAnalytics;
}

export default function BusinessesPage() {
  const router = useRouter();
  const { isAuthenticated, isLoading } = useAuthStore();
  const [businesses, setBusinesses] = useState<BusinessWithAnalytics[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedBusiness, setSelectedBusiness] = useState<BusinessWithAnalytics | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'created_at' | 'industry'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [filterIndustry, setFilterIndustry] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [formData, setFormData] = useState<BusinessCreate>({
    name: '',
    industry: '',
    location: '',
    target_audience: '',
    brand_voice: '',
  });

  useEffect(() => {
    if (isAuthenticated && !isLoading) {
      fetchBusinesses();
    }
  }, [isAuthenticated, isLoading]);

  const fetchBusinesses = async () => {
    try {
      const data = await apiClient.getBusinesses();
      const businessesWithAnalytics = await Promise.all(
        data.map(async (business) => {
          try {
            const analytics = await apiClient.getBusinessAnalytics(business.id);
            return { ...business, analytics };
          } catch (error) {
            console.error(`Failed to fetch analytics for business ${business.id}:`, error);
            return business;
          }
        })
      );
      setBusinesses(businessesWithAnalytics);
    } catch (error) {
      console.error('Failed to fetch businesses:', error);
      toast.error('Failed to load businesses');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateBusiness = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const newBusiness = await apiClient.createBusiness(formData);
      setBusinesses([...businesses, newBusiness]);
      setShowCreateModal(false);
      setFormData({
        name: '',
        industry: '',
        location: '',
        target_audience: '',
        brand_voice: '',
      });
      toast.success('Business created successfully!');
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to create business');
    }
  };

  const handleEditBusiness = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBusiness) return;
    
    try {
      const updatedBusiness = await apiClient.updateBusiness(selectedBusiness.id, formData);
      setBusinesses(businesses.map(b => b.id === selectedBusiness.id ? { ...b, ...updatedBusiness } : b));
      setShowEditModal(false);
      setSelectedBusiness(null);
      toast.success('Business updated successfully!');
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to update business');
    }
  };

  const handleDeleteBusiness = async () => {
    if (!selectedBusiness) return;
    
    try {
      await apiClient.deleteBusiness(selectedBusiness.id);
      setBusinesses(businesses.filter(b => b.id !== selectedBusiness.id));
      setShowDeleteModal(false);
      setSelectedBusiness(null);
      toast.success('Business deleted successfully!');
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to delete business');
    }
  };

  const openEditModal = (business: BusinessWithAnalytics) => {
    setSelectedBusiness(business);
    setFormData({
      name: business.name,
      industry: business.industry,
      location: business.location,
      target_audience: business.target_audience,
      brand_voice: business.brand_voice,
    });
    setShowEditModal(true);
  };

  const openDeleteModal = (business: BusinessWithAnalytics) => {
    setSelectedBusiness(business);
    setShowDeleteModal(true);
  };

  const getIndustryOptions = () => {
    const industries = Array.from(new Set(businesses.map(b => b.industry)));
    return industries.sort();
  };

  const filteredAndSortedBusinesses = businesses
    .filter(business =>
      business.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      business.industry.toLowerCase().includes(searchTerm.toLowerCase()) ||
      business.location.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .filter(business => !filterIndustry || business.industry === filterIndustry)
    .sort((a, b) => {
      let aValue = a[sortBy];
      let bValue = b[sortBy];
      
      if (sortBy === 'created_at') {
        aValue = new Date(a.created_at).getTime().toString();
        bValue = new Date(b.created_at).getTime().toString();
      }
      
      if (sortOrder === 'asc') {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });

  const toggleSort = (field: typeof sortBy) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-secondary-900 mb-2">Authentication Required</h2>
            <p className="text-secondary-600">Please log in to access businesses.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="bg-white border-b border-secondary-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-secondary-900">
                  Businesses
                </h1>
                <p className="text-secondary-600">
                  Manage your business profiles and settings
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <Button
                  variant="secondary"
                  onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
                >
                  {viewMode === 'grid' ? 'List View' : 'Grid View'}
                </Button>
                <Button
                  onClick={() => setShowCreateModal(true)}
                  leftIcon={<PlusIcon className="h-4 w-4" />}
                >
                  Add Business
                </Button>
              </div>
            </div>
          </header>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto p-6">
            {/* Search and Filters */}
            <div className="mb-6 space-y-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1">
                  <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-secondary-400" />
                  <Input
                    type="text"
                    placeholder="Search businesses..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <select
                  value={filterIndustry}
                  onChange={(e) => setFilterIndustry(e.target.value)}
                  className="px-3 py-2 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="">All Industries</option>
                  {getIndustryOptions().map(industry => (
                    <option key={industry} value={industry}>{industry}</option>
                  ))}
                </select>
              </div>

              {/* Sort Controls */}
              <div className="flex items-center space-x-4 text-sm">
                <span className="text-secondary-600">Sort by:</span>
                <button
                  onClick={() => toggleSort('name')}
                  className={`flex items-center space-x-1 px-3 py-1 rounded-md transition-colors ${
                    sortBy === 'name' ? 'bg-primary-100 text-primary-700' : 'text-secondary-600 hover:bg-secondary-100'
                  }`}
                >
                  <span>Name</span>
                  {sortBy === 'name' && (
                    sortOrder === 'asc' ? <ArrowUpIcon className="h-3 w-3" /> : <ArrowDownIcon className="h-3 w-3" />
                  )}
                </button>
                <button
                  onClick={() => toggleSort('industry')}
                  className={`flex items-center space-x-1 px-3 py-1 rounded-md transition-colors ${
                    sortBy === 'industry' ? 'bg-primary-100 text-primary-700' : 'text-secondary-600 hover:bg-secondary-100'
                  }`}
                >
                  <span>Industry</span>
                  {sortBy === 'industry' && (
                    sortOrder === 'asc' ? <ArrowUpIcon className="h-3 w-3" /> : <ArrowDownIcon className="h-3 w-3" />
                  )}
                </button>
                <button
                  onClick={() => toggleSort('created_at')}
                  className={`flex items-center space-x-1 px-3 py-1 rounded-md transition-colors ${
                    sortBy === 'created_at' ? 'bg-primary-100 text-primary-700' : 'text-secondary-600 hover:bg-secondary-100'
                  }`}
                >
                  <span>Created</span>
                  {sortBy === 'created_at' && (
                    sortOrder === 'asc' ? <ArrowUpIcon className="h-3 w-3" /> : <ArrowDownIcon className="h-3 w-3" />
                  )}
                </button>
              </div>
            </div>

            {loading ? (
              <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
              </div>
            ) : (
              <>
                {/* Stats Summary */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                  <div className="bg-white rounded-lg p-4 border border-secondary-200">
                    <div className="flex items-center">
                      <BuildingOfficeIcon className="h-8 w-8 text-primary-600" />
                      <div className="ml-3">
                        <p className="text-sm font-medium text-secondary-600">Total Businesses</p>
                        <p className="text-2xl font-bold text-secondary-900">{businesses.length}</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-4 border border-secondary-200">
                    <div className="flex items-center">
                      <ChartBarIcon className="h-8 w-8 text-green-600" />
                      <div className="ml-3">
                        <p className="text-sm font-medium text-secondary-600">Active Campaigns</p>
                        <p className="text-2xl font-bold text-secondary-900">
                          {businesses.reduce((sum, b) => sum + (b.analytics?.active_campaigns || 0), 0)}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-4 border border-secondary-200">
                    <div className="flex items-center">
                      <UserGroupIcon className="h-8 w-8 text-blue-600" />
                      <div className="ml-3">
                        <p className="text-sm font-medium text-secondary-600">Total Leads</p>
                        <p className="text-2xl font-bold text-secondary-900">
                          {businesses.reduce((sum, b) => sum + (b.analytics?.total_leads || 0), 0)}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-4 border border-secondary-200">
                    <div className="flex items-center">
                      <CurrencyDollarIcon className="h-8 w-8 text-yellow-600" />
                      <div className="ml-3">
                        <p className="text-sm font-medium text-secondary-600">Avg. Conversion</p>
                        <p className="text-2xl font-bold text-secondary-900">
                          {businesses.length > 0 
                            ? Math.round(businesses.reduce((sum, b) => sum + (b.analytics?.conversion_rate || 0), 0) / businesses.length)
                            : 0}%
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Business Cards/List */}
                {viewMode === 'grid' ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredAndSortedBusinesses.map((business) => (
                      <div key={business.id} className="card hover:shadow-lg transition-shadow">
                        <div className="flex items-start justify-between mb-4">
                          <div className="h-12 w-12 bg-primary-100 rounded-lg flex items-center justify-center">
                            <BuildingOfficeIcon className="h-6 w-6 text-primary-600" />
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="badge badge-primary">Active</span>
                            <div className="relative">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => openEditModal(business)}
                              >
                                <PencilIcon className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => openDeleteModal(business)}
                              >
                                <TrashIcon className="h-4 w-4 text-red-600" />
                              </Button>
                            </div>
                          </div>
                        </div>
                        
                        <h3 className="text-lg font-semibold text-secondary-900 mb-2">
                          {business.name}
                        </h3>
                        
                        <div className="space-y-2 text-sm text-secondary-600 mb-4">
                          <div className="flex items-center">
                            <BuildingOfficeIcon className="h-4 w-4 mr-2" />
                            {business.industry}
                          </div>
                          <div className="flex items-center">
                            <MapPinIcon className="h-4 w-4 mr-2" />
                            {business.location}
                          </div>
                          <div className="flex items-center">
                            <UsersIcon className="h-4 w-4 mr-2" />
                            {business.target_audience}
                          </div>
                          <div className="flex items-center">
                            <ChatBubbleLeftRightIcon className="h-4 w-4 mr-2" />
                            {business.brand_voice}
                          </div>
                        </div>

                        {/* Analytics Summary */}
                        {business.analytics && (
                          <div className="bg-secondary-50 rounded-lg p-3 mb-4">
                            <h4 className="text-sm font-medium text-secondary-900 mb-2">Performance</h4>
                            <div className="grid grid-cols-2 gap-2 text-xs">
                              <div>
                                <span className="text-secondary-600">Campaigns:</span>
                                <span className="font-medium ml-1">{business.analytics.active_campaigns}</span>
                              </div>
                              <div>
                                <span className="text-secondary-600">Leads:</span>
                                <span className="font-medium ml-1">{business.analytics.total_leads}</span>
                              </div>
                              <div>
                                <span className="text-secondary-600">Conversion:</span>
                                <span className="font-medium ml-1">{business.analytics.conversion_rate}%</span>
                              </div>
                              <div>
                                <span className="text-secondary-600">Revenue:</span>
                                <span className="font-medium ml-1">${business.analytics.campaign_performance?.reduce((sum, p) => sum + p.revenue, 0) || 0}</span>
                              </div>
                            </div>
                          </div>
                        )}
                        
                        <div className="flex items-center justify-between text-xs text-secondary-500">
                          <span>Created {new Date(business.created_at).toLocaleDateString()}</span>
                          <div className="flex items-center space-x-2">
                            <Button 
                              size="sm" 
                              variant="secondary"
                              onClick={() => router.push(`/businesses/${business.id}`)}
                            >
                              <EyeIcon className="h-3 w-3 mr-1" />
                              View
                            </Button>
                            <Button 
                              size="sm" 
                              variant="secondary"
                              onClick={() => router.push(`/businesses/${business.id}`)}
                            >
                              <CogIcon className="h-3 w-3 mr-1" />
                              Settings
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-white rounded-lg border border-secondary-200 overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-secondary-200">
                        <thead className="bg-secondary-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                              Business
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                              Industry
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                              Location
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                              Performance
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-secondary-500 uppercase tracking-wider">
                              Created
                            </th>
                            <th className="px-6 py-3 text-right text-xs font-medium text-secondary-500 uppercase tracking-wider">
                              Actions
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-secondary-200">
                          {filteredAndSortedBusinesses.map((business) => (
                            <tr key={business.id} className="hover:bg-secondary-50">
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="flex items-center">
                                  <div className="h-10 w-10 bg-primary-100 rounded-lg flex items-center justify-center">
                                    <BuildingOfficeIcon className="h-5 w-5 text-primary-600" />
                                  </div>
                                  <div className="ml-4">
                                    <div className="text-sm font-medium text-secondary-900">{business.name}</div>
                                    <div className="text-sm text-secondary-500">{business.target_audience}</div>
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-900">
                                {business.industry}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-900">
                                {business.location}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                {business.analytics ? (
                                  <div className="text-sm">
                                    <div className="flex items-center space-x-4">
                                      <span className="text-secondary-600">
                                        {business.analytics.active_campaigns} campaigns
                                      </span>
                                      <span className="text-secondary-600">
                                        {business.analytics.total_leads} leads
                                      </span>
                                      <span className="text-green-600 font-medium">
                                        {business.analytics.conversion_rate}% conv.
                                      </span>
                                    </div>
                                  </div>
                                ) : (
                                  <span className="text-secondary-400 text-sm">No data</span>
                                )}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-secondary-500">
                                {new Date(business.created_at).toLocaleDateString()}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <div className="flex items-center justify-end space-x-2">
                                  <Button 
                                    size="sm" 
                                    variant="secondary"
                                    onClick={() => router.push(`/businesses/${business.id}`)}
                                  >
                                    <EyeIcon className="h-3 w-3" />
                                  </Button>
                                  <Button size="sm" variant="secondary" onClick={() => openEditModal(business)}>
                                    <PencilIcon className="h-3 w-3" />
                                  </Button>
                                  <Button size="sm" variant="secondary" onClick={() => openDeleteModal(business)}>
                                    <TrashIcon className="h-3 w-3 text-red-600" />
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </>
            )}

            {!loading && filteredAndSortedBusinesses.length === 0 && (
              <div className="text-center py-12">
                <BuildingOfficeIcon className="mx-auto h-12 w-12 text-secondary-400" />
                <h3 className="mt-2 text-sm font-medium text-secondary-900">No businesses found</h3>
                <p className="mt-1 text-sm text-secondary-500">
                  {searchTerm || filterIndustry ? 'Try adjusting your search terms or filters.' : 'Get started by creating your first business.'}
                </p>
                {!searchTerm && !filterIndustry && (
                  <div className="mt-6">
                    <Button onClick={() => setShowCreateModal(true)}>
                      <PlusIcon className="h-4 w-4 mr-2" />
                      Add Business
                    </Button>
                  </div>
                )}
              </div>
            )}
          </main>
        </div>

        {/* Create Business Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
              <div className="p-6">
                <h2 className="text-xl font-semibold text-secondary-900 mb-4">
                  Create New Business
                </h2>
                
                <form onSubmit={handleCreateBusiness} className="space-y-4">
                  <Input
                    label="Business Name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter business name"
                    required
                  />
                  
                  <Input
                    label="Industry"
                    value={formData.industry}
                    onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                    placeholder="e.g., Technology, Healthcare, Retail"
                    required
                  />
                  
                  <Input
                    label="Location"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="City, State or Country"
                    required
                  />
                  
                  <Input
                    label="Target Audience"
                    value={formData.target_audience}
                    onChange={(e) => setFormData({ ...formData, target_audience: e.target.value })}
                    placeholder="e.g., Small business owners, 25-45 years old"
                    required
                  />
                  
                  <Input
                    label="Brand Voice"
                    value={formData.brand_voice}
                    onChange={(e) => setFormData({ ...formData, brand_voice: e.target.value })}
                    placeholder="e.g., Professional, Friendly, Innovative"
                    required
                  />
                  
                  <div className="flex space-x-3 pt-4">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setShowCreateModal(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button type="submit" className="flex-1">
                      Create Business
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}

        {/* Edit Business Modal */}
        {showEditModal && selectedBusiness && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
              <div className="p-6">
                <h2 className="text-xl font-semibold text-secondary-900 mb-4">
                  Edit Business
                </h2>
                
                <form onSubmit={handleEditBusiness} className="space-y-4">
                  <Input
                    label="Business Name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter business name"
                    required
                  />
                  
                  <Input
                    label="Industry"
                    value={formData.industry}
                    onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                    placeholder="e.g., Technology, Healthcare, Retail"
                    required
                  />
                  
                  <Input
                    label="Location"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="City, State or Country"
                    required
                  />
                  
                  <Input
                    label="Target Audience"
                    value={formData.target_audience}
                    onChange={(e) => setFormData({ ...formData, target_audience: e.target.value })}
                    placeholder="e.g., Small business owners, 25-45 years old"
                    required
                  />
                  
                  <Input
                    label="Brand Voice"
                    value={formData.brand_voice}
                    onChange={(e) => setFormData({ ...formData, brand_voice: e.target.value })}
                    placeholder="e.g., Professional, Friendly, Innovative"
                    required
                  />
                  
                  <div className="flex space-x-3 pt-4">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setShowEditModal(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button type="submit" className="flex-1">
                      Update Business
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}

        {/* Delete Business Modal */}
        {showDeleteModal && selectedBusiness && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <ExclamationTriangleIcon className="h-6 w-6 text-red-600 mr-3" />
                  <h2 className="text-xl font-semibold text-secondary-900">
                    Delete Business
                  </h2>
                </div>
                
                <p className="text-secondary-600 mb-6">
                  Are you sure you want to delete <strong>{selectedBusiness.name}</strong>? This action cannot be undone and will remove all associated data including campaigns, leads, and analytics.
                </p>
                
                <div className="flex space-x-3">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => setShowDeleteModal(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="button"
                    variant="danger"
                    onClick={handleDeleteBusiness}
                    className="flex-1"
                  >
                    Delete Business
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
} 