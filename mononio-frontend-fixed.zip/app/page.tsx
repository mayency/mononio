'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth';

export default function HomePage() {
  const router = useRouter();
  const { user, isAuthenticated, isLoading, initialize, _hasHydrated, setHasHydrated } = useAuthStore();
  const [redirecting, setRedirecting] = useState(false);
  const [forceHydration, setForceHydration] = useState(false);

  useEffect(() => {
    // Initialize auth state on component mount
    initialize();
    
    // Fallback: force hydration completion after 1 second
    const fallbackTimer = setTimeout(() => {
      if (!_hasHydrated) {
        console.log('🔐 Auth store: Fallback - forcing hydration completion');
        setHasHydrated(true);
        setForceHydration(true);
      }
    }, 1000);

    return () => clearTimeout(fallbackTimer);
  }, [initialize, _hasHydrated, setHasHydrated]);

  useEffect(() => {
    // Only redirect after hydration is complete and loading is done
    if ((_hasHydrated || forceHydration) && !isLoading && !redirecting) {
      setRedirecting(true);
      
      if (isAuthenticated && user) {
        // User is authenticated, redirect to dashboard
        console.log('🔄 Redirecting authenticated user to dashboard');
        router.push('/dashboard');
      } else {
        // User is not authenticated, redirect to login
        console.log('🔄 Redirecting unauthenticated user to login');
        router.push('/login');
      }
    }
  }, [isAuthenticated, isLoading, user, router, _hasHydrated, redirecting, forceHydration]);

  // Show loading spinner while initializing or redirecting
  if (isLoading || (!_hasHydrated && !forceHydration) || redirecting) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">
            {!isLoading && !_hasHydrated && !forceHydration ? 'Initializing...' : 
             redirecting ? 'Redirecting...' : 'Loading LaunchMate DIAMOND...'}
          </p>
        </div>
      </div>
    );
  }

  // This should not render if redirects are working properly
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">Preparing your dashboard...</p>
      </div>
    </div>
  );
} 