'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Edit3, Palette, Type, Wand2, Download, Save, X, Plus,
  Monitor, Tablet, Smartphone, Settings, Loader2, Sparkles
} from 'lucide-react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import { Label } from '@/components/ui/Label';
import toast from 'react-hot-toast';
import apiClient from '@/lib/api';
import { getErrorMessage } from '@/lib/getErrorMessage';

interface VisualLandingPageBuilderProps {
  businessInfo: any;
  onSave: (data: any) => void;
  onClose: () => void;
}

// Industry-specific icons and colors
const INDUSTRY_ICONS = {
  technology: ["💻", "🚀", "⚡", "🔧", "🌐", "📱"],
  healthcare: ["🏥", "⚕️", "💊", "🩺", "❤️", "🦠"],
  finance: ["💰", "📊", "💳", "🏦", "📈", "💎"],
  education: ["📚", "🎓", "✏️", "🎯", "🌟", "📖"],
  real_estate: ["🏠", "🏢", "🔑", "📋", "📍", "💰"],
  legal: ["⚖️", "📜", "👨‍⚖️", "🔒", "📋", "💼"],
  marketing: ["📢", "🎯", "📈", "💡", "🚀", "📱"],
  design: ["🎨", "✨", "🎯", "💡", "🌟", "🎭"],
  fitness: ["💪", "🏃‍♂️", "🏋️‍♂️", "🥗", "💧", "🎯"],
  beauty: ["💄", "✨", "🌸", "💅", "🪞", "🌟"],
  food: ["🍽️", "👨‍🍳", "🥘", "🍕", "🍰", "☕"],
  automotive: ["🚗", "🔧", "⛽", "🛣️", "🚙", "🏁"],
  travel: ["✈️", "🌍", "🏖️", "🗺️", "🎒", "📸"],
  entertainment: ["🎬", "🎵", "🎮", "🎭", "🎪", "🎨"],
  service: ["🎯", "🤝", "💼", "📈", "⭐", "🔧"],
  consulting: ["💡", "📊", "🎯", "🚀", "💼", "📈"],
  coaching: ["🎯", "💪", "🌟", "📚", "🚀", "💡"],
  agency: ["🎨", "📢", "🚀", "💡", "📈", "🌟"],
  product: ["📦", "⭐", "🚀", "💎", "🎯", "✨"],
  software: ["💻", "⚡", "🔧", "🚀", "📱", "🌐"],
  course: ["📚", "🎓", "🎯", "📖", "✏️", "🌟"],
  ebook: ["📖", "📚", "💡", "🎯", "📝", "✨"]
};

const INDUSTRY_COLORS = {
  technology: { primary: "#3B82F6", secondary: "#1E40AF", accent: "#06B6D4" },
  healthcare: { primary: "#10B981", secondary: "#059669", accent: "#F59E0B" },
  finance: { primary: "#8B5CF6", secondary: "#7C3AED", accent: "#F59E0B" },
  education: { primary: "#F59E0B", secondary: "#D97706", accent: "#10B981" },
  real_estate: { primary: "#EF4444", secondary: "#DC2626", accent: "#F59E0B" },
  legal: { primary: "#6B7280", secondary: "#4B5563", accent: "#8B5CF6" },
  marketing: { primary: "#EC4899", secondary: "#DB2777", accent: "#8B5CF6" },
  design: { primary: "#8B5CF6", secondary: "#7C3AED", accent: "#EC4899" },
  fitness: { primary: "#EF4444", secondary: "#DC2626", accent: "#10B981" },
  beauty: { primary: "#EC4899", secondary: "#DB2777", accent: "#F59E0B" },
  food: { primary: "#F59E0B", secondary: "#D97706", accent: "#EF4444" },
  automotive: { primary: "#6B7280", secondary: "#4B5563", accent: "#EF4444" },
  travel: { primary: "#06B6D4", secondary: "#0891B2", accent: "#10B981" },
  entertainment: { primary: "#EC4899", secondary: "#DB2777", accent: "#8B5CF6" },
  service: { primary: "#667eea", secondary: "#764ba2", accent: "#ff6b6b" },
  consulting: { primary: "#3B82F6", secondary: "#1E40AF", accent: "#10B981" },
  coaching: { primary: "#8B5CF6", secondary: "#7C3AED", accent: "#F59E0B" },
  agency: { primary: "#EC4899", secondary: "#DB2777", accent: "#8B5CF6" },
  product: { primary: "#10B981", secondary: "#059669", accent: "#F59E0B" },
  software: { primary: "#3B82F6", secondary: "#1E40AF", accent: "#06B6D4" },
  course: { primary: "#F59E0B", secondary: "#D97706", accent: "#10B981" },
  ebook: { primary: "#8B5CF6", secondary: "#7C3AED", accent: "#F59E0B" }
};

const VisualLandingPageBuilder: React.FC<VisualLandingPageBuilderProps> = ({
  businessInfo,
  onSave,
  onClose
}) => {
  const [isEditing, setIsEditing] = useState(true);
  const [activeTab, setActiveTab] = useState('content');
  const [previewMode, setPreviewMode] = useState('desktop');
  const [currentSection, setCurrentSection] = useState('hero');
  const [aiGenerating, setAiGenerating] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [selectedAnimation, setSelectedAnimation] = useState('fadeIn');
  
  const businessType = businessInfo?.type?.toLowerCase() || 'service';
  const industryIcons = INDUSTRY_ICONS[businessType as keyof typeof INDUSTRY_ICONS] || INDUSTRY_ICONS.service;
  const industryColors = INDUSTRY_COLORS[businessType as keyof typeof INDUSTRY_COLORS] || INDUSTRY_COLORS.service;
  
  const [colors, setColors] = useState({
    primary: industryColors.primary,
    secondary: industryColors.secondary,
    accent: industryColors.accent,
    text: '#1F2937',
    textLight: '#6B7280',
    background: '#FFFFFF',
    backgroundLight: '#F9FAFB',
  });

  const [content, setContent] = useState({
    hero: {
      headline: `Transform Your Business with ${businessInfo.business_name}`,
      subheadline: businessInfo.description || 'Professional landing page for your business.',
      ctaText: 'Get Started Free',
      secondaryCta: 'Watch Demo',
      heroImage: industryIcons[0] || '🚀',
    },
    features: [
      {
        icon: industryIcons[0] || '🎯',
        title: 'Smart Automation',
        description: 'Automate repetitive tasks and workflows to save time.'
      },
      {
        icon: industryIcons[1] || '📊',
        title: 'Advanced Analytics',
        description: 'Get deep insights into your business performance.'
      },
      {
        icon: industryIcons[2] || '🔒',
        title: 'Enterprise Security',
        description: 'Bank-level security ensures your data is protected.'
      },
    ],
  });

  const updateContent = (section: string, field: string, value: any, index: number | null = null) => {
    setContent(prev => {
      const newContent = { ...prev };
      if (index !== null) {
        if (Array.isArray(newContent[section as keyof typeof newContent])) {
          (newContent[section as keyof typeof newContent] as any)[index] = {
            ...(newContent[section as keyof typeof newContent] as any)[index],
            [field]: value
          };
        }
      } else if (typeof newContent[section as keyof typeof newContent] === 'object') {
        (newContent[section as keyof typeof newContent] as any) = {
          ...(newContent[section as keyof typeof newContent] as any),
          [field]: value
        };
      }
      return newContent;
    });
  };

  // Animation variants for Framer Motion
  const animationVariants = {
    fadeIn: {
      initial: { opacity: 0, y: 20 },
      animate: { opacity: 1, y: 0 },
      exit: { opacity: 0, y: -20 }
    },
    slideIn: {
      initial: { opacity: 0, x: -20 },
      animate: { opacity: 1, x: 0 },
      exit: { opacity: 0, x: 20 }
    },
    scaleIn: {
      initial: { opacity: 0, scale: 0.9 },
      animate: { opacity: 1, scale: 1 },
      exit: { opacity: 0, scale: 0.9 }
    },
    bounce: {
      initial: { opacity: 0, y: 50 },
      animate: { opacity: 1, y: 0 },
      exit: { opacity: 0, y: -50 }
    }
  };

  const handleSave = () => {
    const pageData = {
      content,
      colors,
      businessInfo,
      previewMode
    };
    onSave(pageData);
    toast.success('Landing page saved successfully!');
  };

  const generateAIContent = async (section: string) => {
    if (!aiPrompt.trim()) {
      toast.error('Please enter a prompt for AI content generation');
      return;
    }

    setAiGenerating(true);
    try {
      // Try to use the landing page agent first for better results
      let response;
      try {
        const landingPageResponse = await apiClient.generateLandingPage(
          businessInfo.id?.toString() || '1',
          {
            section: section,
            prompt: aiPrompt,
            business_info: businessInfo
          }
        );
        
        if (landingPageResponse.success && landingPageResponse.landing_page) {
          response = landingPageResponse;
        } else {
          // Fallback to general AI content generation
          const prompt = `Generate ${section} content for a landing page about ${businessInfo.business_name}. 
          Business description: ${businessInfo.description || 'Professional business services'}
          Specific request: ${aiPrompt}
          
          Please provide compelling, conversion-focused content that matches the business type and target audience.`;

          response = await apiClient.generateAIContent({
            prompt: prompt,
            content_type: 'text',
            platform: 'landing_page',
            target_audience: 'business customers',
            provider: 'openai'
          });
        }
      } catch (error) {
        // Fallback to general AI content generation
        const prompt = `Generate ${section} content for a landing page about ${businessInfo.business_name}. 
        Business description: ${businessInfo.description || 'Professional business services'}
        Specific request: ${aiPrompt}
        
        Please provide compelling, conversion-focused content that matches the business type and target audience.`;

        response = await apiClient.generateAIContent({
          prompt: prompt,
          content_type: 'text',
          platform: 'landing_page',
          target_audience: 'business customers',
          provider: 'openai'
        });
      }

      if (response.success && response.content) {
        // Parse the AI response and update content
        const aiContent = response.content;
        
        if (section === 'hero') {
          // Extract headline and subheadline from AI response
          const lines = aiContent.split('\n').filter((line: string) => line.trim());
          const headline = lines[0] || content.hero.headline;
          const subheadline = lines[1] || content.hero.subheadline;
          
          updateContent('hero', 'headline', headline);
          updateContent('hero', 'subheadline', subheadline);
        } else if (section === 'features') {
          // Generate feature content
          const featureResponse = await apiClient.generateAIContent({
            prompt: `Generate 3 feature descriptions for ${businessInfo.business_name}`,
            content_type: 'text',
            platform: 'landing_page',
            target_audience: 'business customers',
            provider: 'openai'
          });

          if (featureResponse.success && featureResponse.content) {
            const featureLines = featureResponse.content.split('\n').filter((line: string) => line.trim());
            const newFeatures = featureLines.slice(0, 3).map((line: string, index: number) => ({
              icon: industryIcons[index] || ['🎯', '📊', '🔒'][index] || '✨',
              title: line.split(':')[0] || `Feature ${index + 1}`,
              description: line.split(':')[1] || line
            }));
            
            setContent(prev => ({
              ...prev,
              features: newFeatures
            }));
          }
        }
        
        toast.success('AI content generated successfully!');
        setAiPrompt('');
      } else {
        toast.error(getErrorMessage(response.error) || 'Failed to generate AI content');
      }
    } catch (error: any) {
      console.error('AI content generation error:', error);
      toast.error(getErrorMessage(error) || 'Failed to generate AI content');
    } finally {
      setAiGenerating(false);
    }
  };

  const AIPanel = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="space-y-4"
    >
      <motion.div 
        className="flex items-center gap-2 mb-4"
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.1 }}
      >
        <motion.div
          animate={{ rotate: [0, 10, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          <Sparkles className="w-5 h-5 text-purple-500" />
        </motion.div>
        <h3 className="text-lg font-semibold">AI Content Generator</h3>
      </motion.div>
      
      <motion.div 
        className="space-y-3"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <div>
          <Label htmlFor="aiPrompt">What would you like to generate?</Label>
          <motion.textarea
            id="aiPrompt"
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            placeholder="e.g., Create a compelling headline for a tech startup..."
            className="w-full p-3 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            rows={3}
            whileFocus={{ scale: 1.02 }}
            transition={{ duration: 0.2 }}
          />
        </div>
        
        <motion.div 
          className="flex gap-2"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <motion.div 
            className="flex-1"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button
              onClick={() => generateAIContent('hero')}
              disabled={aiGenerating || !aiPrompt.trim()}
              className="w-full"
            >
              {aiGenerating ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Wand2 className="w-4 h-4" />
              )}
              Generate Hero
            </Button>
          </motion.div>
          
          <motion.div 
            className="flex-1"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button
              onClick={() => generateAIContent('features')}
              disabled={aiGenerating || !aiPrompt.trim()}
              className="w-full"
            >
              {aiGenerating ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Wand2 className="w-4 h-4" />
              )}
              Generate Features
            </Button>
          </motion.div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: aiGenerating ? 1 : 0 }}
          className="text-center text-sm text-gray-600"
        >
          {aiGenerating && "Generating AI content..."}
        </motion.div>
      </motion.div>
    </motion.div>
  );

  const EditPanel = () => (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="space-y-6"
    >
      <motion.div 
        className="flex items-center justify-between"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <h3 className="text-lg font-semibold">Edit Content</h3>
        <motion.div 
          className="flex gap-2"
          whileHover={{ scale: 1.05 }}
        >
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsEditing(!isEditing)}
          >
            <Edit3 className="w-4 h-4" />
            {isEditing ? 'Preview' : 'Edit'}
          </Button>
        </motion.div>
      </motion.div>

      <AnimatePresence mode="wait">
        {isEditing ? (
          <motion.div
            key="edit"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="space-y-4"
          >
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Label>Hero Headline</Label>
              <Input
                value={content.hero.headline}
                onChange={(e) => updateContent('hero', 'headline', e.target.value)}
                placeholder="Enter your headline..."
                className="focus:ring-2 focus:ring-blue-500"
              />
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Label>Hero Subheadline</Label>
              <Input
                value={content.hero.subheadline}
                onChange={(e) => updateContent('hero', 'subheadline', e.target.value)}
                placeholder="Enter your subheadline..."
                className="focus:ring-2 focus:ring-blue-500"
              />
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Label>Call to Action</Label>
              <Input
                value={content.hero.ctaText}
                onChange={(e) => updateContent('hero', 'ctaText', e.target.value)}
                placeholder="Get Started Today"
                className="focus:ring-2 focus:ring-blue-500"
              />
            </motion.div>

            <motion.div 
              className="space-y-3"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Label>Features</Label>
              {content.features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                  className="p-3 border border-gray-200 rounded-lg space-y-2 hover:border-blue-300 transition-colors"
                  whileHover={{ scale: 1.02 }}
                >
                  <div className="flex items-center gap-2">
                    <Input
                      value={feature.icon}
                      onChange={(e) => updateContent('features', 'icon', e.target.value, index)}
                      className="w-16 text-center"
                      placeholder="🎯"
                    />
                    <Input
                      value={feature.title}
                      onChange={(e) => updateContent('features', 'title', e.target.value, index)}
                      placeholder="Feature title"
                    />
                  </div>
                  <Input
                    value={feature.description}
                    onChange={(e) => updateContent('features', 'description', e.target.value, index)}
                    placeholder="Feature description"
                  />
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        ) : (
          <motion.div
            key="preview"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="space-y-4"
          >
            <motion.div 
              className="p-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg"
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.2 }}
            >
              <h2 className="text-2xl font-bold mb-2">{content.hero.headline}</h2>
              <p className="text-lg mb-4">{content.hero.subheadline}</p>
              <Button className="bg-white text-blue-600 hover:bg-gray-100">
                {content.hero.ctaText}
              </Button>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {content.features.map((feature, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.05 }}
                  className="p-4 border border-gray-200 rounded-lg text-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="text-3xl mb-2">{feature.icon}</div>
                  <h3 className="font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-gray-600">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );

  const ColorPanel = () => (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className="space-y-4"
    >
      <motion.h3 
        className="text-lg font-semibold"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        Color Scheme
      </motion.h3>
      
      <motion.div 
        className="grid grid-cols-2 gap-4"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Label>Primary Color</Label>
          <div className="flex items-center gap-2 mt-1">
            <motion.input
              type="color"
              value={colors.primary}
              onChange={(e) => setColors(prev => ({ ...prev, primary: e.target.value }))}
              className="w-10 h-10 rounded border cursor-pointer"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            />
            <Input
              value={colors.primary}
              onChange={(e) => setColors(prev => ({ ...prev, primary: e.target.value }))}
              className="flex-1"
            />
          </div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Label>Secondary Color</Label>
          <div className="flex items-center gap-2 mt-1">
            <motion.input
              type="color"
              value={colors.secondary}
              onChange={(e) => setColors(prev => ({ ...prev, secondary: e.target.value }))}
              className="w-10 h-10 rounded border cursor-pointer"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            />
            <Input
              value={colors.secondary}
              onChange={(e) => setColors(prev => ({ ...prev, secondary: e.target.value }))}
              className="flex-1"
            />
          </div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Label>Accent Color</Label>
          <div className="flex items-center gap-2 mt-1">
            <motion.input
              type="color"
              value={colors.accent}
              onChange={(e) => setColors(prev => ({ ...prev, accent: e.target.value }))}
              className="w-10 h-10 rounded border cursor-pointer"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            />
            <Input
              value={colors.accent}
              onChange={(e) => setColors(prev => ({ ...prev, accent: e.target.value }))}
              className="flex-1"
            />
          </div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Label>Text Color</Label>
          <div className="flex items-center gap-2 mt-1">
            <motion.input
              type="color"
              value={colors.text}
              onChange={(e) => setColors(prev => ({ ...prev, text: e.target.value }))}
              className="w-10 h-10 rounded border cursor-pointer"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            />
            <Input
              value={colors.text}
              onChange={(e) => setColors(prev => ({ ...prev, text: e.target.value }))}
              className="flex-1"
            />
          </div>
        </motion.div>
      </motion.div>
      
      <motion.div 
        className="p-4 bg-gray-50 rounded-lg"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
      >
        <h4 className="font-medium mb-2">Industry Presets</h4>
        <div className="grid grid-cols-3 gap-2">
          {Object.entries(INDUSTRY_COLORS).slice(0, 6).map(([industry, colorScheme], index) => (
            <motion.button
              key={industry}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setColors(prev => ({
                ...prev,
                primary: colorScheme.primary,
                secondary: colorScheme.secondary,
                accent: colorScheme.accent
              }))}
              className="p-2 text-xs rounded border hover:border-blue-500"
              style={{
                background: `linear-gradient(45deg, ${colorScheme.primary}, ${colorScheme.secondary})`
              }}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.8 + index * 0.1 }}
            >
              <div className="text-white font-medium capitalize">{industry}</div>
            </motion.button>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );

  const PreviewSelector = () => (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center gap-2"
    >
      <Button
        variant={previewMode === 'desktop' ? 'primary' : 'ghost'}
        size="sm"
        onClick={() => setPreviewMode('desktop')}
      >
        <Monitor className="w-4 h-4" />
      </Button>
      <Button
        variant={previewMode === 'tablet' ? 'primary' : 'ghost'}
        size="sm"
        onClick={() => setPreviewMode('tablet')}
      >
        <Tablet className="w-4 h-4" />
      </Button>
      <Button
        variant={previewMode === 'mobile' ? 'primary' : 'ghost'}
        size="sm"
        onClick={() => setPreviewMode('mobile')}
      >
        <Smartphone className="w-4 h-4" />
      </Button>
    </motion.div>
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-lg shadow-2xl w-full max-w-7xl h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b">
          <div>
            <h2 className="text-2xl font-bold">Visual Landing Page Builder</h2>
            <p className="text-gray-600">Create stunning landing pages with AI assistance</p>
          </div>
          <div className="flex items-center gap-4">
            <PreviewSelector />
            <Button onClick={handleSave}>
              <Save className="w-4 h-4 mr-2" />
              Save
            </Button>
            <Button variant="ghost" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex">
          {/* Sidebar */}
          <motion.div
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            className="w-80 border-r bg-gray-50 p-6 overflow-y-auto"
          >
            <div className="space-y-6">
              <div className="flex gap-2">
                <Button
                  variant={activeTab === 'content' ? 'primary' : 'ghost'}
                  onClick={() => setActiveTab('content')}
                  className="flex-1"
                >
                  <Type className="w-4 h-4 mr-2" />
                  Content
                </Button>
                <Button
                  variant={activeTab === 'ai' ? 'primary' : 'ghost'}
                  onClick={() => setActiveTab('ai')}
                  className="flex-1"
                >
                  <Wand2 className="w-4 h-4 mr-2" />
                  AI
                </Button>
                <Button
                  variant={activeTab === 'colors' ? 'primary' : 'ghost'}
                  onClick={() => setActiveTab('colors')}
                  className="flex-1"
                >
                  <Palette className="w-4 h-4 mr-2" />
                  Colors
                </Button>
              </div>

              <AnimatePresence mode="wait">
                {activeTab === 'content' && <EditPanel key="content" />}
                {activeTab === 'ai' && <AIPanel key="ai" />}
                {activeTab === 'colors' && <ColorPanel key="colors" />}
              </AnimatePresence>
            </div>
          </motion.div>

          {/* Preview Area */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="flex-1 p-6 overflow-y-auto"
          >
            <div className={`mx-auto ${previewMode === 'mobile' ? 'max-w-sm' : previewMode === 'tablet' ? 'max-w-md' : 'max-w-4xl'}`}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-lg shadow-lg overflow-hidden"
                style={{
                  '--primary-color': colors.primary,
                  '--secondary-color': colors.secondary,
                  '--accent-color': colors.accent,
                } as React.CSSProperties}
              >
                {/* Hero Section */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                  className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-12 text-center"
                  style={{
                    background: `linear-gradient(135deg, ${colors.primary}, ${colors.secondary})`
                  }}
                >
                  <motion.h1
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="text-4xl font-bold mb-4"
                  >
                    {content.hero.headline}
                  </motion.h1>
                  <motion.p
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                    className="text-xl mb-8"
                  >
                    {content.hero.subheadline}
                  </motion.p>
                  <motion.button
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.6 }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors"
                  >
                    {content.hero.ctaText}
                  </motion.button>
                </motion.div>

                {/* Features Section */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.7 }}
                  className="p-12 bg-gray-50"
                >
                  <div className="text-center mb-12">
                    <h2 className="text-3xl font-bold mb-4">Why Choose Us</h2>
                    <p className="text-gray-600">Everything you need to succeed</p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {content.features.map((feature, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.8 + index * 0.1 }}
                        whileHover={{ y: -5 }}
                        className="text-center p-6 bg-white rounded-lg shadow-md"
                      >
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ delay: 0.9 + index * 0.1 }}
                          className="text-4xl mb-4"
                        >
                          {feature.icon}
                        </motion.div>
                        <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                        <p className="text-gray-600">{feature.description}</p>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>

                {/* Contact Section */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.0 }}
                  className="p-12 bg-white"
                >
                  <div className="text-center mb-8">
                    <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
                    <p className="text-gray-600">Join thousands of satisfied customers</p>
                  </div>
                  
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1.1 }}
                    className="max-w-md mx-auto"
                  >
                    <form className="space-y-4">
                      <input
                        type="text"
                        placeholder="Your Name"
                        className="w-full p-3 border border-gray-300 rounded-lg"
                      />
                      <input
                        type="email"
                        placeholder="Your Email"
                        className="w-full p-3 border border-gray-300 rounded-lg"
                      />
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                        style={{ backgroundColor: colors.primary }}
                      >
                        Get Started
                      </motion.button>
                    </form>
                  </motion.div>
                </motion.div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default VisualLandingPageBuilder; 