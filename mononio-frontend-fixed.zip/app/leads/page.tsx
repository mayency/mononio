'use client';

import { useEffect, useState } from 'react';
import { useAuthStore } from '@/store/auth';
import { Lead, LeadCreate, Business } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import {
  PlusIcon,
  MagnifyingGlassIcon,
  UserGroupIcon,
  FunnelIcon,
  PhoneIcon,
  EnvelopeIcon,
  MapPinIcon,
  CalendarIcon,
  CheckCircleIcon,
  ClockIcon,
  ExclamationTriangleIcon,
  XCircleIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

export default function LeadsPage() {
  const { isAuthenticated } = useAuthStore();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedBusiness, setSelectedBusiness] = useState<number | null>(null);
  const [formData, setFormData] = useState<LeadCreate>({
    business_id: 0,
    name: '',
    email: '',
    phone: '',
    source: '',
  });

  useEffect(() => {
    if (isAuthenticated) {
      fetchData();
    }
  }, [isAuthenticated]);

  const fetchData = async () => {
    try {
      const [businessesData] = await Promise.all([
        apiClient.getBusinesses(),
      ]);
      setBusinesses(businessesData);
      
      // Fetch leads for all businesses
      const allLeads: Lead[] = [];
      for (const business of businessesData) {
        try {
          const businessLeads = await apiClient.getBusinessLeads(business.id);
          allLeads.push(...businessLeads);
        } catch (error) {
          console.error(`Failed to fetch leads for business ${business.id}:`, error);
        }
      }
      setLeads(allLeads);
    } catch (error) {
      console.error('Failed to fetch data:', error);
      toast.error('Failed to load leads');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateLead = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.business_id) {
      toast.error('Please select a business');
      return;
    }
    
    try {
      const newLead = await apiClient.createLead(formData);
      setLeads([...leads, newLead]);
      setShowCreateModal(false);
      setFormData({
        business_id: 0,
        name: '',
        email: '',
        phone: '',
        source: '',
      });
      toast.success('Lead created successfully!');
    } catch (error: any) {
      toast.error(error.message || 'Failed to create lead');
    }
  };

  const handleStatusUpdate = async (leadId: number, newStatus: string) => {
    try {
      const updatedLead = await apiClient.updateLeadStatus(leadId, newStatus);
      setLeads(leads.map(lead => lead.id === leadId ? updatedLead : lead));
      toast.success('Lead status updated!');
    } catch (error: any) {
      toast.error('Failed to update lead status');
    }
  };

  const getStatusIcon = (status: string) => {
    const icons = {
      new: ClockIcon,
      contacted: PhoneIcon,
      qualified: CheckCircleIcon,
      converted: CheckCircleIcon,
      lost: XCircleIcon,
    };
    const Icon = icons[status as keyof typeof icons] || ClockIcon;
    return <Icon className="h-4 w-4" />;
  };

  const getStatusColor = (status: string) => {
    const colors = {
      new: 'text-secondary-600 bg-secondary-100',
      contacted: 'text-primary-600 bg-primary-100',
      qualified: 'text-warning-600 bg-warning-100',
      converted: 'text-success-600 bg-success-100',
      lost: 'text-danger-600 bg-danger-100',
    };
    return colors[status as keyof typeof colors] || colors.new;
  };

  const filteredLeads = leads.filter(lead => {
    const matchesSearch = 
      lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.phone?.includes(searchTerm) ||
      lead.source.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || lead.status === statusFilter;
    const matchesBusiness = !selectedBusiness || lead.business_id === selectedBusiness;
    
    return matchesSearch && matchesStatus && matchesBusiness;
  });

  const leadStats = {
    total: leads.length,
    new: leads.filter(l => l.status === 'new').length,
    contacted: leads.filter(l => l.status === 'contacted').length,
    qualified: leads.filter(l => l.status === 'qualified').length,
    converted: leads.filter(l => l.status === 'converted').length,
    lost: leads.filter(l => l.status === 'lost').length,
  };

  if (!isAuthenticated) {
    return <div>Please log in to access leads.</div>;
  }

  return (
    <div className="flex h-screen bg-secondary-50">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-secondary-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-secondary-900">
                Leads
              </h1>
              <p className="text-secondary-600">
                Manage and track your lead pipeline
              </p>
            </div>
            <Button
              onClick={() => setShowCreateModal(true)}
              leftIcon={<PlusIcon className="h-4 w-4" />}
            >
              Add Lead
            </Button>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-6">
            <div className="stat-card">
              <p className="stat-value">{leadStats.total}</p>
              <p className="stat-label">Total Leads</p>
            </div>
            <div className="stat-card">
              <p className="stat-value">{leadStats.new}</p>
              <p className="stat-label">New</p>
            </div>
            <div className="stat-card">
              <p className="stat-value">{leadStats.contacted}</p>
              <p className="stat-label">Contacted</p>
            </div>
            <div className="stat-card">
              <p className="stat-value">{leadStats.qualified}</p>
              <p className="stat-label">Qualified</p>
            </div>
            <div className="stat-card">
              <p className="stat-value">{leadStats.converted}</p>
              <p className="stat-label">Converted</p>
            </div>
            <div className="stat-card">
              <p className="stat-value">{leadStats.lost}</p>
              <p className="stat-label">Lost</p>
            </div>
          </div>

          {/* Filters */}
          <div className="bg-white rounded-lg border border-secondary-200 p-4 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-secondary-400" />
                <Input
                  type="text"
                  placeholder="Search leads..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
              >
                <option value="all">All Statuses</option>
                <option value="new">New</option>
                <option value="contacted">Contacted</option>
                <option value="qualified">Qualified</option>
                <option value="converted">Converted</option>
                <option value="lost">Lost</option>
              </select>
              
              <select
                value={selectedBusiness || ''}
                onChange={(e) => setSelectedBusiness(e.target.value ? Number(e.target.value) : null)}
                className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
              >
                <option value="">All Businesses</option>
                {businesses.map((business) => (
                  <option key={business.id} value={business.id}>
                    {business.name}
                  </option>
                ))}
              </select>
              
              <Button
                variant="secondary"
                onClick={() => {
                  setSearchTerm('');
                  setStatusFilter('all');
                  setSelectedBusiness(null);
                }}
                leftIcon={<FunnelIcon className="h-4 w-4" />}
              >
                Clear Filters
              </Button>
            </div>
          </div>

          {/* Leads List */}
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredLeads.map((lead) => (
                <div key={lead.id} className="card">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="h-10 w-10 bg-primary-100 rounded-full flex items-center justify-center">
                        <UserGroupIcon className="h-5 w-5 text-primary-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-secondary-900">
                          {lead.name}
                        </h3>
                        <div className="flex items-center space-x-4 text-sm text-secondary-500">
                          <div className="flex items-center">
                            <EnvelopeIcon className="h-4 w-4 mr-1" />
                            {lead.email}
                          </div>
                          {lead.phone && (
                            <div className="flex items-center">
                              <PhoneIcon className="h-4 w-4 mr-1" />
                              {lead.phone}
                            </div>
                          )}
                          <div className="flex items-center">
                            <MapPinIcon className="h-4 w-4 mr-1" />
                            {businesses.find(b => b.id === lead.business_id)?.name}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <span className={`badge ${getStatusColor(lead.status)}`}>
                        {getStatusIcon(lead.status)}
                        <span className="ml-1">{lead.status}</span>
                      </span>
                      
                      <select
                        value={lead.status}
                        onChange={(e) => handleStatusUpdate(lead.id, e.target.value)}
                        className="text-sm border border-secondary-300 rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-primary-500"
                      >
                        <option value="new">New</option>
                        <option value="contacted">Contacted</option>
                        <option value="qualified">Qualified</option>
                        <option value="converted">Converted</option>
                        <option value="lost">Lost</option>
                      </select>
                      
                      <div className="text-right">
                        <p className="text-sm text-secondary-500">
                          Score: {lead.lead_score}
                        </p>
                        <p className="text-xs text-secondary-400">
                          {new Date(lead.created_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {filteredLeads.length === 0 && (
                <div className="text-center py-12">
                  <UserGroupIcon className="mx-auto h-12 w-12 text-secondary-400" />
                  <h3 className="mt-2 text-sm font-medium text-secondary-900">No leads found</h3>
                  <p className="mt-1 text-sm text-secondary-500">
                    {searchTerm || statusFilter !== 'all' || selectedBusiness 
                      ? 'Try adjusting your filters.' 
                      : 'Get started by adding your first lead.'}
                  </p>
                  {!searchTerm && statusFilter === 'all' && !selectedBusiness && (
                    <div className="mt-6">
                      <Button onClick={() => setShowCreateModal(true)}>
                        <PlusIcon className="h-4 w-4 mr-2" />
                        Add Lead
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </main>
      </div>

      {/* Create Lead Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-secondary-900 mb-4">
                Add New Lead
              </h2>
              
              <form onSubmit={handleCreateLead} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-1">
                    Business
                  </label>
                  <select
                    value={formData.business_id}
                    onChange={(e) => setFormData({ ...formData, business_id: Number(e.target.value) })}
                    className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
                    required
                  >
                    <option value={0}>Select a business</option>
                    {businesses.map((business) => (
                      <option key={business.id} value={business.id}>
                        {business.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <Input
                  label="Full Name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter full name"
                  required
                />
                
                <Input
                  label="Email Address"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="Enter email address"
                  required
                />
                
                <Input
                  label="Phone Number (Optional)"
                  type="tel"
                  value={formData.phone || ''}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="Enter phone number"
                />
                
                <Input
                  label="Lead Source"
                  value={formData.source}
                  onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                  placeholder="e.g., Website, Social Media, Referral"
                  required
                />
                
                <div className="flex space-x-3 pt-4">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => setShowCreateModal(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button type="submit" className="flex-1">
                    Add Lead
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
} 