# LaunchMate DIAMOND Frontend

A modern, responsive React frontend for the LaunchMate DIAMOND AI-powered business management platform.

## 🚀 Features

### ✨ Modern UI/UX
- **Beautiful Design**: Clean, professional interface with modern aesthetics
- **Responsive Layout**: Works perfectly on desktop, tablet, and mobile
- **Dark/Light Mode**: Adaptive color schemes
- **Smooth Animations**: Framer Motion powered transitions
- **Accessibility**: WCAG compliant components

### 🔐 Authentication System
- **Secure Login**: JWT-based authentication
- **Protected Routes**: Automatic redirect for unauthenticated users
- **Session Management**: Persistent login state
- **User Profile**: Display user information and settings

### 📊 Dashboard
- **Overview Statistics**: Key business metrics at a glance
- **Recent Activity**: Latest updates and actions
- **Quick Actions**: Fast access to common tasks
- **Real-time Updates**: Live data refresh

### 🏢 Business Management
- **Business Profiles**: Create and manage multiple businesses
- **Search & Filter**: Find businesses quickly
- **Business Analytics**: Performance insights per business
- **Settings Management**: Configure business preferences

### 📢 Campaign Management
- **Campaign Creation**: Easy campaign setup wizard
- **Multi-type Support**: Social media, email, advertising, content
- **Performance Tracking**: Real-time metrics and analytics
- **Status Management**: Draft, active, paused, completed states

### 🎯 Lead Management
- **Lead Capture**: Add and manage leads
- **Lead Scoring**: Automated lead qualification
- **Status Tracking**: Visual lead progression
- **CRM Integration**: Complete customer relationship management

### 📈 Analytics & Reporting
- **Performance Metrics**: Comprehensive business analytics
- **Visual Charts**: Interactive data visualization
- **Export Options**: Download reports in multiple formats
- **Custom Dashboards**: Personalized analytics views

### 🤖 AI-Powered Features
- **Content Generation**: AI-powered marketing content
- **Market Research**: Automated competitor analysis
- **Smart Recommendations**: Data-driven insights
- **Automated Workflows**: Intelligent business processes

## 🛠️ Tech Stack

- **Framework**: Next.js 14 with App Router
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **State Management**: Zustand
- **HTTP Client**: Axios
- **Icons**: Heroicons
- **Animations**: Framer Motion
- **Charts**: Recharts
- **Forms**: React Hook Form
- **Notifications**: React Hot Toast
- **Date Handling**: date-fns

## 📦 Installation

### Prerequisites
- Node.js 18+ 
- npm or yarn
- LaunchMate DIAMOND backend running on `http://localhost:8000`

### Setup Steps

1. **Install Dependencies**
```bash
cd frontend
npm install
```

2. **Environment Configuration**
Create a `.env.local` file:
```env
NEXT_PUBLIC_API_URL=http://localhost:8000
```

3. **Start Development Server**
```bash
npm run dev
```

4. **Open Browser**
Navigate to `http://localhost:3000`

## 🏗️ Project Structure

```
frontend/
├── app/                    # Next.js App Router pages
│   ├── dashboard/         # Dashboard page
│   ├── businesses/        # Business management
│   ├── campaigns/         # Campaign management
│   ├── leads/            # Lead management
│   ├── analytics/        # Analytics & reporting
│   ├── content/          # Content generation
│   ├── research/         # Market research
│   ├── financials/       # Financial management
│   ├── ai-tools/         # AI-powered features
│   ├── settings/         # User settings
│   ├── login/           # Authentication
│   ├── globals.css      # Global styles
│   ├── layout.tsx       # Root layout
│   └── page.tsx         # Home page
├── components/           # Reusable components
│   ├── ui/              # Base UI components
│   │   ├── Button.tsx
│   │   ├── Input.tsx
│   │   └── ...
│   └── layout/          # Layout components
│       └── Sidebar.tsx
├── lib/                 # Utility libraries
│   └── api.ts          # API client
├── store/              # State management
│   └── auth.ts         # Authentication store
├── types/              # TypeScript definitions
│   └── index.ts        # API types
├── hooks/              # Custom React hooks
├── styles/             # Additional styles
└── public/             # Static assets
```

## 🎨 Design System

### Color Palette
- **Primary**: Blue (#3B82F6) - Main brand color
- **Secondary**: Gray (#64748B) - Text and borders
- **Success**: Green (#22C55E) - Positive actions
- **Warning**: Yellow (#F59E0B) - Caution states
- **Danger**: Red (#EF4444) - Error states

### Typography
- **Font**: Inter (Google Fonts)
- **Weights**: 300, 400, 500, 600, 700
- **Sizes**: 12px, 14px, 16px, 18px, 20px, 24px, 32px

### Components
- **Cards**: Rounded corners, subtle shadows
- **Buttons**: Multiple variants and sizes
- **Forms**: Consistent input styling
- **Tables**: Clean, readable data presentation
- **Modals**: Overlay dialogs with backdrop

## 🔧 Development

### Available Scripts
```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server
npm run lint         # Run ESLint
npm run type-check   # Run TypeScript check
```

### Code Style
- **ESLint**: Code linting and formatting
- **Prettier**: Code formatting
- **TypeScript**: Strict type checking
- **Conventional Commits**: Git commit message format

### Testing
```bash
npm run test         # Run unit tests
npm run test:watch   # Run tests in watch mode
npm run test:coverage # Generate coverage report
```

## 🌐 Deployment

### Production Build
```bash
npm run build
npm run start
```

### Environment Variables
```env
NEXT_PUBLIC_API_URL=https://api.launchmate.com
NEXT_PUBLIC_APP_ENV=production
```

### Deployment Platforms
- **Vercel**: Recommended for Next.js
- **Netlify**: Alternative hosting
- **AWS Amplify**: Enterprise hosting
- **Docker**: Containerized deployment

## 🔒 Security

### Authentication
- JWT token storage in localStorage
- Automatic token refresh
- Protected route guards
- Session timeout handling

### Data Protection
- HTTPS enforcement
- Input validation and sanitization
- XSS protection
- CSRF protection

### API Security
- Request/response interceptors
- Error handling
- Rate limiting
- CORS configuration

## 📱 Mobile Support

### Responsive Design
- **Mobile First**: Designed for mobile devices
- **Breakpoints**: 640px, 768px, 1024px, 1280px
- **Touch Friendly**: Optimized for touch interactions
- **Progressive Web App**: PWA capabilities

### Performance
- **Code Splitting**: Automatic route-based splitting
- **Image Optimization**: Next.js Image component
- **Lazy Loading**: Component and data lazy loading
- **Caching**: Browser and CDN caching

## 🤝 Contributing

### Development Workflow
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

### Code Standards
- Follow TypeScript best practices
- Use functional components with hooks
- Implement proper error handling
- Add JSDoc comments for complex functions
- Maintain consistent naming conventions

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

### Documentation
- [Next.js Documentation](https://nextjs.org/docs)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [TypeScript Documentation](https://www.typescriptlang.org/docs)

### Issues
- Report bugs via GitHub Issues
- Request features via GitHub Discussions
- Get help via GitHub Discussions

---

**LaunchMate DIAMOND Frontend** - Transform your business with AI-powered management tools. 