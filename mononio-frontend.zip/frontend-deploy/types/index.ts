// API Response Types
export interface ApiResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
  error?: string;
  timestamp: string;
}

// User Types
export interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  created_at?: string;
  updated_at?: string;
}

// Business Types
export interface Business {
  id: number;
  name: string;
  industry: string;
  location: string;
  target_audience: string;
  brand_voice: string;
  competitors?: any;
  keywords?: string[];
  created_at: string;
  updated_at: string;
}

export interface BusinessCreate {
  name: string;
  industry: string;
  location: string;
  target_audience: string;
  brand_voice: string;
}

// Campaign Types
export interface Campaign {
  id: number;
  business_id: number;
  name: string;
  campaign_type: 'social_media' | 'email' | 'advertising' | 'content' | 'multi_channel' | 'ab_testing';
  status: 'draft' | 'active' | 'paused' | 'completed' | 'scheduled';
  budget: number;
  start_date: string;
  end_date?: string;
  impressions: number;
  clicks: number;
  conversions: number;
  cost: number;
  revenue: number;
  content_generated?: any;
  created_at: string;
  updated_at: string;
  // Enhanced fields
  description?: string;
  goal?: string;
  target_audience?: string;
  channels?: string[];
  ab_testing_enabled?: boolean;
  ab_test_variants?: ABTestVariant[];
  performance_metrics?: CampaignPerformanceMetrics;
  automation_rules?: AutomationRule[];
  budget_spent?: number;
  budget_remaining?: number;
  roi?: number;
  ctr?: number;
  conversion_rate?: number;
  cpc?: number;
  cpm?: number;
}

export interface CampaignCreate {
  business_id: number;
  name: string;
  campaign_type: 'social_media' | 'email' | 'advertising' | 'content' | 'multi_channel' | 'ab_testing';
  budget: number;
  start_date: string;
  end_date?: string;
  description?: string;
  goal?: string;
  target_audience?: string;
  channels?: string[];
  ab_testing_enabled?: boolean;
}

export interface ABTestVariant {
  id: string;
  name: string;
  description: string;
  traffic_percentage: number;
  performance: {
    impressions: number;
    clicks: number;
    conversions: number;
    ctr: number;
    conversion_rate: number;
  };
  status: 'active' | 'paused' | 'winner' | 'loser';
}

export interface CampaignPerformanceMetrics {
  impressions: number;
  clicks: number;
  conversions: number;
  cost: number;
  revenue: number;
  ctr: number;
  conversion_rate: number;
  cpc: number;
  cpm: number;
  roi: number;
  engagement_rate?: number;
  reach?: number;
  frequency?: number;
  quality_score?: number;
}

export interface AutomationRule {
  id: string;
  name: string;
  condition: string;
  action: string;
  enabled: boolean;
  created_at: string;
}

export interface CampaignAnalytics {
  campaign_id: number;
  overview: CampaignPerformanceMetrics;
  daily_performance: DailyPerformance[];
  channel_breakdown: ChannelPerformance[];
  audience_insights: AudienceInsights;
  conversion_funnel: ConversionFunnel;
  recommendations: string[];
}

export interface DailyPerformance {
  date: string;
  impressions: number;
  clicks: number;
  conversions: number;
  cost: number;
  revenue: number;
}

export interface ChannelPerformance {
  channel: string;
  impressions: number;
  clicks: number;
  conversions: number;
  cost: number;
  revenue: number;
  ctr: number;
  conversion_rate: number;
}

export interface AudienceInsights {
  demographics: {
    age_groups: Record<string, number>;
    genders: Record<string, number>;
    locations: Record<string, number>;
  };
  interests: string[];
  behaviors: string[];
  engagement_patterns: string[];
}

export interface ConversionFunnel {
  stages: {
    awareness: number;
    consideration: number;
    conversion: number;
  };
  drop_off_rates: Record<string, number>;
  optimization_opportunities: string[];
}

// Additional Campaign Types
export interface ABTestVariantCreate {
  name: string;
  description: string;
  traffic_percentage: number;
}

export interface AutomationRuleCreate {
  name: string;
  condition: string;
  action: string;
  enabled?: boolean;
}

// Lead Types
export interface Lead {
  id: number;
  business_id: number;
  name: string;
  email: string;
  phone?: string;
  source: string;
  status: 'new' | 'contacted' | 'qualified' | 'converted' | 'lost';
  lead_score: number;
  converted: boolean;
  conversion_date?: string;
  created_at: string;
  updated_at: string;
}

export interface LeadCreate {
  business_id: number;
  name: string;
  email: string;
  phone?: string;
  source: string;
}

// Content Generation Types
export interface ContentGenerationRequest {
  business_id: string;
  content_type: 'text' | 'image' | 'video';
  business_context: {
    name: string;
    industry: string;
    target_audience: string;
    brand_voice: string;
  };
  campaign_context?: {
    name: string;
    type: string;
    goal: string;
  };
  platform: string;
  requirements: Record<string, any>;
}

export interface ContentGenerationResponse {
  content: string | {
    text_content: string;
    images: any[];
    videos: any[];
  };
  platform: string;
  content_type: string;
  generated_at: string;
  metadata?: {
    content_type: string;
    platform: string;
    generated_at: string;
  };
  status: string;
}

// Market Research Types
export interface MarketResearchRequest {
  research_type: 'competitor_analysis' | 'market_trends' | 'audience_research';
  business_context: BusinessCreate;
  industry: string;
  location: string;
}

export interface MarketResearchResponse {
  analysis: Record<string, any>;
  insights: string[];
  recommendations: string[];
  competitors: any[];
}

// Financial Types
export interface Expense {
  id: number;
  business_id: number;
  amount: number;
  category: string;
  description: string;
  date: string;
  receipt_url?: string;
  created_at: string;
}

export interface ExpenseCreate {
  business_id: number;
  amount: number;
  category: string;
  description: string;
  date: string;
}

// Analytics Types
export interface BusinessAnalytics {
  total_campaigns: number;
  active_campaigns: number;
  total_leads: number;
  conversion_rate: number;
  total_expenses: number;
  campaign_performance: CampaignPerformance[];
}

export interface CampaignPerformance {
  name: string;
  impressions: number;
  clicks: number;
  conversions: number;
  cost: number;
  revenue: number;
}

// Authentication Types
export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  access_token: string;
  token_type: string;
  user: User;
}

// Dashboard Types
export interface DashboardStats {
  total_businesses: number;
  active_campaigns: number;
  total_leads: number;
  total_revenue: number;
  recent_activities: Activity[];
}

export interface Activity {
  id: number;
  type: 'campaign_created' | 'lead_added' | 'expense_added' | 'content_generated';
  description: string;
  timestamp: string;
  business_id: number;
  business_name: string;
} 