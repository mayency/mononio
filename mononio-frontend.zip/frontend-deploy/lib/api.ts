import { 
  ApiResponse, 
  User, 
  Business, 
  BusinessCreate, 
  Campaign, 
  CampaignCreate,
  Lead,
  LeadCreate,
  ContentGenerationRequest,
  ContentGenerationResponse,
  MarketResearchRequest,
  MarketResearchResponse,
  Expense,
  ExpenseCreate,
  BusinessAnalytics,
  LoginRequest,
  LoginResponse,
  DashboardStats,
  CampaignAnalytics,
  ABTestVariant,
  ABTestVariantCreate,
  AutomationRule,
  AutomationRuleCreate
} from '@/types';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

class ApiClient {
  private getAuthToken(): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('auth_token');
    }
    return null;
  }

  private setAuthToken(token: string): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem('auth_token', token);
    }
  }

  private clearAuthToken(): void {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('auth_token');
    }
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const token = this.getAuthToken();
    const headers: Record<string, string> = {
      ...(options.headers as Record<string, string>),
    };

    // Only set Content-Type to application/json if not FormData
    if (!(options.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
    }

    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    console.log('🌐 API Request:', {
      url: `${API_BASE_URL}${endpoint}`,
      method: options.method || 'GET',
      headers,
      body: options.body
    });

    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers,
      });

      console.log('🌐 API Response:', {
        status: response.status,
        statusText: response.statusText,
        url: response.url,
        headers: response.headers ? Object.fromEntries(response.headers.entries()) : {}
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.log('🌐 API Error:', errorData);
        throw new Error(errorData.detail || `HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log('🌐 API Success:', data);
      return data;
    } catch (error) {
      console.log('🌐 API Request failed:', error);
      throw error;
    }
  }

  // Authentication
  async login(credentials: LoginRequest): Promise<LoginResponse> {
    console.log('🔑 API Client: Login attempt with credentials:', credentials);
    const response = await this.request<LoginResponse>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
    
    console.log('🔑 API Client: Login response received:', response);
    this.setAuthToken(response.access_token);
    console.log('🔑 API Client: Token stored in localStorage');
    return response;
  }

  async logout(): Promise<void> {
    try {
      await this.request('/auth/logout', { method: 'POST' });
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      this.clearAuthToken();
    }
  }

  async getCurrentUser(): Promise<User> {
    return this.request<User>('/auth/me');
  }

  // Dashboard
  async getDashboardStats(): Promise<DashboardStats> {
    return this.request<DashboardStats>('/dashboard/stats');
  }

  async getDashboardAnalytics(): Promise<any> {
    return this.request<any>('/dashboard/analytics');
  }

  // Businesses
  async createBusiness(business: BusinessCreate): Promise<Business> {
    return this.request<Business>('/businesses', {
      method: 'POST',
      body: JSON.stringify(business),
    });
  }

  async getBusinesses(): Promise<Business[]> {
    return this.request<Business[]>('/businesses');
  }

  async getBusiness(id: number): Promise<Business> {
    return this.request<Business>(`/businesses/${id}`);
  }

  async updateBusiness(id: number, business: BusinessCreate): Promise<Business> {
    return this.request<Business>(`/businesses/${id}`, {
      method: 'PUT',
      body: JSON.stringify(business),
    });
  }

  async deleteBusiness(id: number): Promise<void> {
    return this.request<void>(`/businesses/${id}`, {
      method: 'DELETE',
    });
  }

  // Campaigns
  async createCampaign(campaign: CampaignCreate): Promise<Campaign> {
    return this.request<Campaign>('/campaigns', {
      method: 'POST',
      body: JSON.stringify(campaign),
    });
  }

  async getCampaigns(): Promise<Campaign[]> {
    return this.request<Campaign[]>('/campaigns');
  }

  async getBusinessCampaigns(businessId: number): Promise<Campaign[]> {
    return this.request<Campaign[]>(`/businesses/${businessId}/campaigns`);
  }

  async getCampaign(id: number): Promise<Campaign> {
    return this.request<Campaign>(`/campaigns/${id}`);
  }

  async updateCampaign(id: number, campaign: CampaignCreate): Promise<Campaign> {
    return this.request<Campaign>(`/campaigns/${id}`, {
      method: 'PUT',
      body: JSON.stringify(campaign),
    });
  }

  async deleteCampaign(id: number): Promise<void> {
    return this.request<void>(`/campaigns/${id}`, {
      method: 'DELETE',
    });
  }

  async getCampaignAnalytics(id: number): Promise<CampaignAnalytics> {
    return this.request<CampaignAnalytics>(`/campaigns/${id}/analytics`);
  }

  async createABTestVariant(campaignId: number, variant: ABTestVariantCreate): Promise<ABTestVariant> {
    return this.request<ABTestVariant>(`/campaigns/${campaignId}/ab-test-variants`, {
      method: 'POST',
      body: JSON.stringify(variant),
    });
  }

  async createAutomationRule(campaignId: number, rule: AutomationRuleCreate): Promise<AutomationRule> {
    return this.request<AutomationRule>(`/campaigns/${campaignId}/automation-rules`, {
      method: 'POST',
      body: JSON.stringify(rule),
    });
  }

  // Leads
  async createLead(lead: LeadCreate): Promise<Lead> {
    return this.request<Lead>('/leads', {
      method: 'POST',
      body: JSON.stringify(lead),
    });
  }

  async getBusinessLeads(businessId: number): Promise<Lead[]> {
    return this.request<Lead[]>(`/businesses/${businessId}/leads`);
  }

  async updateLeadStatus(leadId: number, status: string, notes?: string): Promise<Lead> {
    return this.request<Lead>(`/leads/${leadId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, notes }),
    });
  }

  // Content Generation
  async generateContent(request: ContentGenerationRequest): Promise<ContentGenerationResponse> {
    return this.request<ContentGenerationResponse>('/content/generate', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  async optimizeContent(content: string, platform: string, businessId: number): Promise<ContentGenerationResponse> {
    return this.request<ContentGenerationResponse>('/content/optimize', {
      method: 'POST',
      body: JSON.stringify({ content, platform, business_id: businessId }),
    });
  }

  async analyzeContentPerformance(analyticsRequest: any): Promise<ApiResponse> {
    return this.request<ApiResponse>('/content/analyze', {
      method: 'POST',
      body: JSON.stringify(analyticsRequest),
    });
  }

  // Market Research
  async conductMarketResearch(request: MarketResearchRequest): Promise<MarketResearchResponse> {
    return this.request<MarketResearchResponse>('/research/conduct', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  async answerResearchQuestion(question: string): Promise<ApiResponse> {
    return this.request<ApiResponse>('/research/question', {
      method: 'POST',
      body: JSON.stringify({ question }),
    });
  }

  // Financial Management
  async createExpense(expense: ExpenseCreate): Promise<Expense> {
    return this.request<Expense>('/expenses', {
      method: 'POST',
      body: JSON.stringify(expense),
    });
  }

  async getBusinessExpenses(businessId: number): Promise<Expense[]> {
    return this.request<Expense[]>(`/businesses/${businessId}/expenses`);
  }

  async uploadReceipt(businessId: number, file: File): Promise<Expense> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('business_id', businessId.toString());

    const token = this.getAuthToken();
    const response = await fetch(`${API_BASE_URL}/expenses/upload`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return response.json();
  }

  // Analytics
  async getBusinessAnalytics(businessId: number): Promise<BusinessAnalytics> {
    return this.request<BusinessAnalytics>(`/businesses/${businessId}/analytics`);
  }

  // System Status
  async getSystemStatus(): Promise<ApiResponse> {
    return this.request<ApiResponse>('/health');
  }

  // Connected Services
  async getConnectedServices(): Promise<ApiResponse> {
    return this.request<ApiResponse>('/connected-services');
  }

  async syncConnectedService(serviceId: string): Promise<ApiResponse> {
    return this.request<ApiResponse>(`/connected-services/${serviceId}/sync`, {
      method: 'POST',
    });
  }

  async connectService(serviceId: string): Promise<ApiResponse> {
    return this.request<ApiResponse>(`/connected-services/${serviceId}/connect`, {
      method: 'POST',
    });
  }

  async disconnectService(serviceId: string): Promise<ApiResponse> {
    return this.request<ApiResponse>(`/connected-services/${serviceId}/disconnect`, {
      method: 'POST',
    });
  }

  async connectPlatformService(platform: string, accountName?: string): Promise<ApiResponse> {
    return this.request<ApiResponse>('/connected-services/connect-platform', {
      method: 'POST',
      body: JSON.stringify({ platform, account_name: accountName }),
    });
  }

  // YouTube Integration
  async getYouTubeChannels(): Promise<ApiResponse> {
    return this.request<ApiResponse>('/youtube/channels');
  }

  async connectYouTubeChannel(channelId: string, accountName: string, autoSync: boolean): Promise<ApiResponse> {
    return this.request<ApiResponse>('/youtube/channels/connect', {
      method: 'POST',
      body: JSON.stringify({ channel_id: channelId, account_name: accountName, auto_sync: autoSync }),
    });
  }

  async getYouTubeChannelVideos(channelId: string): Promise<ApiResponse> {
    return this.request<ApiResponse>(`/youtube/channels/${channelId}/videos`);
  }

  // AI Tools
  async accomplishGoal(goal: string, aiProvider?: string): Promise<ApiResponse> {
    return this.request<ApiResponse>('/ai/accomplish', {
      method: 'POST',
      body: JSON.stringify({ goal, ai_provider: aiProvider }),
    });
  }

  async getAvailableTools(): Promise<ApiResponse> {
    return this.request<ApiResponse>('/ai/tools');
  }

  // Video Generation APIs
  async getVideoTemplates(): Promise<{
    success: boolean;
    message: string;
    data: Array<{
      template_id: string;
      name: string;
      description: string;
      category: string;
      duration: number;
      scenes: Array<{
        type: string;
        duration: number;
        text: string;
      }>;
      thumbnail_url: string;
      tags: string[];
    }>;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      data: Array<{
        template_id: string;
        name: string;
        description: string;
        category: string;
        duration: number;
        scenes: Array<{
          type: string;
          duration: number;
          text: string;
        }>;
        thumbnail_url: string;
        tags: string[];
      }>;
    }>('/video/templates');
  }

  async generateVideo(videoData: {
    title: string;
    description: string;
    duration: number;
    style: string;
    format: string;
    resolution: string;
    background_music?: string;
    voice_over?: string;
    scenes: any[];
    branding?: any;
  }): Promise<{
    video_id: string;
    status: string;
    download_url?: string;
    preview_url?: string;
    duration: number;
    file_size?: number;
    created_at: string;
    metadata: any;
  }> {
    return this.request<{
      video_id: string;
      status: string;
      download_url?: string;
      preview_url?: string;
      duration: number;
      file_size?: number;
      created_at: string;
      metadata: any;
    }>('/video/generate', {
      method: 'POST',
      body: JSON.stringify(videoData),
    });
  }

  async getAllVideos(): Promise<{
    success: boolean;
    message: string;
    data: Array<{
      video_id: string;
      status: string;
      download_url?: string;
      preview_url?: string;
      duration: number;
      file_size?: number;
      created_at: string;
      metadata: any;
    }>;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      data: Array<{
        video_id: string;
        status: string;
        download_url?: string;
        preview_url?: string;
        duration: number;
        file_size?: number;
        created_at: string;
        metadata: any;
      }>;
    }>('/videos');
  }

  // Landing Pages
  async createLandingPage(businessInfo: {
    business_name: string;
    business_type: string;
    description: string;
    target_audience: string;
    unique_value_proposition?: string;
    contact_info?: {
      email?: string;
      phone?: string;
      website?: string;
    };
    pricing?: {
      current_price?: string;
      original_price?: string;
      consultation?: string;
    };
  }): Promise<{
    page_id: string;
    title: string;
    html_content: string;
    css_styles: string;
    preview_url: string;
    created_at: string;
    metadata: any;
  }> {
    // Transform the data to match backend expectations
    const landingPageRequest = {
      business_name: businessInfo.business_name,
      industry: businessInfo.business_type,
      target_audience: businessInfo.target_audience,
      brand_voice: "Professional", // Default value
      page_type: "conversion",
      primary_goal: businessInfo.unique_value_proposition || "Lead Generation",
      key_features: [
        businessInfo.description,
        businessInfo.unique_value_proposition || "Professional Service",
        "Quality Guaranteed"
      ],
      call_to_action: "Get Started Today",
      color_scheme: "modern",
      style: "professional"
    };

    return this.request('/generate-landing-page', {
      method: 'POST',
      body: JSON.stringify(landingPageRequest),
    });
  }

  async getLandingPages(): Promise<{
    success: boolean;
    message: string;
    data: Array<{
      page_id: string;
      title: string;
      html_content: string;
      css_styles: string;
      preview_url: string;
      created_at: string;
      metadata: any;
    }>;
  }> {
    return this.request('/landing-pages');
  }

  async getLandingPage(id: string): Promise<{
    success: boolean;
    landing_page: {
      id: string;
      business_name: string;
      business_type: string;
      live_url: string;
      status: 'draft' | 'published' | 'error';
      created_at: string;
      updated_at: string;
      template_used: string;
      views?: number;
      conversions?: number;
      html_content?: string;
      css_styles?: string;
    };
    error?: string;
  }> {
    return this.request(`/landing-pages/${id}`);
  }

  async updateLandingPage(id: string, businessInfo: any): Promise<{
    success: boolean;
    live_url?: string;
    error?: string;
  }> {
    return this.request(`/landing-pages/${id}`, {
      method: 'PUT',
      body: JSON.stringify(businessInfo),
    });
  }

  async deleteLandingPage(id: string): Promise<{
    success: boolean;
    error?: string;
  }> {
    return this.request(`/landing-pages/${id}`, {
      method: 'DELETE',
    });
  }

  // Content Management APIs
  async createContentSchedule(scheduleData: {
    title: string;
    description?: string;
    content_type: string;
    platform: string;
    content_data: any;
    scheduled_date: string;
    timezone?: string;
    recurring?: boolean;
    recurrence_pattern?: string;
    user_id: string;
    business_id: string;
  }): Promise<{
    success: boolean;
    schedule_id: string;
    platform: string;
    status: string;
    error?: string;
  }> {
    return this.request('/content/schedules', {
      method: 'POST',
      body: JSON.stringify(scheduleData),
    });
  }

  async getContentSchedules(): Promise<{
    success: boolean;
    schedules: Array<{
      id: string;
      title: string;
      content_type: string;
      platform: string;
      scheduled_date: string;
      status: string;
      published_at?: string;
      published_url?: string;
    }>;
    error?: string;
  }> {
    return this.request('/content/schedules');
  }

  async getContentAnalyticsSummary(timePeriod: string = '30d'): Promise<{
    success: boolean;
    summary: {
      total_posts: number;
      total_engagement: number;
      average_engagement_rate: number;
      top_performing_content: Array<{
        title: string;
        platform: string;
        engagement_rate: number;
        impressions: number;
      }>;
      platform_breakdown: Array<{
        platform: string;
        posts: number;
        engagement: number;
        engagement_rate: number;
      }>;
    };
    error?: string;
  }> {
    return this.request(`/content/analytics/summary?period=${timePeriod}`);
  }

  async getContentTemplates(): Promise<{
    success: boolean;
    templates: Array<{
      id: string;
      name: string;
      template_type: string;
      platform: string;
      category: string;
      template_structure: any;
      usage_count: number;
      average_performance_score: number;
    }>;
    error?: string;
  }> {
    return this.request('/content/templates');
  }

  async createContentTemplate(templateData: {
    name: string;
    description?: string;
    template_type: string;
    platform: string;
    category: string;
    template_structure: any;
    default_content?: any;
    variables?: string[];
  }): Promise<{
    success: boolean;
    template_id: string;
    error?: string;
  }> {
    return this.request('/content/templates', {
      method: 'POST',
      body: JSON.stringify(templateData),
    });
  }

  async createABTest(testData: {
    name: string;
    description?: string;
    test_type: string;
    hypothesis: string;
    variants_count: number;
    success_metrics: string[];
    minimum_sample_size?: number;
    confidence_level?: number;
  }): Promise<{
    success: boolean;
    test_id: string;
    variants: Array<{
      id: string;
      name: string;
      is_control: boolean;
    }>;
    error?: string;
  }> {
    return this.request('/ab-tests', {
      method: 'POST',
      body: JSON.stringify(testData),
    });
  }

  async getABTests(): Promise<{
    success: boolean;
    tests: Array<{
      id: string;
      name: string;
      test_type: string;
      status: string;
      start_date?: string;
      end_date?: string;
      statistical_significance?: number;
      winner_variant_id?: string;
    }>;
    error?: string;
  }> {
    return this.request('/ab-tests');
  }

  // ============================================================================
  // CAMPAIGN ORCHESTRATOR API METHODS
  // ============================================================================

  async createOrchestratedCampaign(data: {
    business_name: string;
    industry: string;
    target_audience: string;
    budget: number;
    goals: string[];
    platforms?: string[];
    campaign_duration?: number;
    brand_voice?: string;
    location?: string;
    ai_provider?: string;
  }): Promise<{
    success: boolean;
    campaign_id?: string;
    customer_analysis?: any;
    audience_research?: any;
    campaign_strategy?: any;
    content_assets?: any;
    video_content?: any;
    campaign_deployment?: any;
    monitoring_setup?: any;
    execution_time?: number;
    error?: string;
    timestamp: string;
  }> {
    return this.request('/campaign-orchestrator/create', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async getOrchestratorStatus(): Promise<{
    success: boolean;
    orchestrator_status?: any;
    error?: string;
    timestamp: string;
  }> {
    return this.request('/campaign-orchestrator/status');
  }

  async getAllOrchestratorCampaigns(): Promise<{
    success: boolean;
    campaigns?: any[];
    error?: string;
    timestamp: string;
  }> {
    return this.request('/campaign-orchestrator/campaigns');
  }

  async getOrchestratorCampaignStatus(campaignId: string): Promise<{
    success: boolean;
    campaign_status?: any;
    error?: string;
    timestamp: string;
  }> {
    return this.request(`/campaign-orchestrator/campaigns/${campaignId}`);
  }

  async optimizeOrchestratorCampaign(campaignId: string): Promise<{
    success: boolean;
    optimization_result?: any;
    error?: string;
    timestamp: string;
  }> {
    return this.request(`/campaign-orchestrator/campaigns/${campaignId}/optimize`, {
      method: 'POST',
    });
  }

  // ============================================================================
  // PLATFORM ACCOUNT LINKING API METHODS
  // ============================================================================

  async getPlatformOAuthUrl(platform: string, userId: string): Promise<{
    success: boolean;
    oauth_url?: string;
    state?: string;
    platform?: string;
    expires_in?: number;
    error?: string;
    timestamp: string;
  }> {
    return this.request('/platform-linking/oauth-url', {
      method: 'POST',
      body: JSON.stringify({ platform, user_id: userId }),
    });
  }

  async handlePlatformCallback(platform: string, code: string, state: string): Promise<{
    success: boolean;
    account_linked?: any;
    error?: string;
    timestamp: string;
  }> {
    return this.request(`/platform-linking/callback/${platform}?code=${encodeURIComponent(code)}&state=${encodeURIComponent(state)}`);
  }

  async getLinkedAccounts(userId: string): Promise<{
    success: boolean;
    linked_accounts?: any[];
    error?: string;
    timestamp: string;
  }> {
    return this.request(`/platform-linking/accounts/${userId}`);
  }

  async disconnectAccount(accountId: string, userId: string): Promise<{
    success: boolean;
    message?: string;
    error?: string;
    timestamp: string;
  }> {
    return this.request(`/platform-linking/accounts/${accountId}?user_id=${userId}`, {
      method: 'DELETE',
    });
  }

  async getPlatformStatus(platform: string): Promise<{
    success: boolean;
    platform_status?: any;
    error?: string;
    timestamp: string;
  }> {
    return this.request(`/platform-linking/status/${platform}`);
  }

  // ============================================================================
  // AI RECOMMENDATIONS AND ANALYSIS API METHODS
  // ============================================================================

  async getContentRecommendations(businessId: string): Promise<{
    success: boolean;
    recommendations?: any[];
    business_context?: any;
    error?: string;
  }> {
    return this.request(`/ai/recommendations/${businessId}`);
  }

  async getAudienceAnalysis(businessId: string): Promise<{
    success: boolean;
    audience_insights?: any;
    error?: string;
  }> {
    return this.request(`/ai/audience-analysis/${businessId}`);
  }

  async generateImage(request: {
    business_id: string;
    content_type: string;
    platform: string;
    description: string;
    style: string;
    dimensions: string;
    brand_colors?: string[];
    target_audience?: string;
  }): Promise<{
    success: boolean;
    image?: any;
    metadata?: any;
    error?: string;
  }> {
    return this.request('/ai/generate-image', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  async generateAIVideo(request: {
    business_id: string;
    content_type: string;
    platform: string;
    script: string;
    duration: number;
    style: string;
    dimensions: string;
    background_music?: string;
    voice_over?: boolean;
  }): Promise<{
    success: boolean;
    video?: any;
    metadata?: any;
    error?: string;
  }> {
    return this.request('/ai/generate-video', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  async generateComprehensiveContent(
    businessId: string,
    contentType: string,
    platform: string,
    description: string,
    includeImages: boolean = true,
    includeVideos: boolean = false
  ): Promise<{
    success: boolean;
    content?: any;
    metadata?: any;
    error?: string;
  }> {
    const params = new URLSearchParams({
      business_id: businessId,
      content_type: contentType,
      platform,
      description,
      include_images: includeImages.toString(),
      include_videos: includeVideos.toString()
    });
    
    return this.request(`/ai/generate-comprehensive-content?${params.toString()}`, {
      method: 'POST',
    });
  }

  async getPlatformRequirements(platform: string): Promise<{
    success: boolean;
    platform?: string;
    requirements?: any;
    error?: string;
  }> {
    return this.request(`/ai/platform-requirements/${platform}`);
  }

  // Unified AI Content Generation (Google Gemini)
  async generateAIContent(request: {
    prompt: string;
    content_type: 'text' | 'image';
    business_id?: string;
    platform?: string;
    style?: string;
    dimensions?: string;
    brand_colors?: string[];
    target_audience?: string;
    provider?: string;
    model?: string;
    [key: string]: any;
  }): Promise<any> {
    return this.request<any>('/ai/generate-content', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  // Content Analytics Agent
  async getContentAnalytics(businessId: string): Promise<{
    success: boolean;
    analytics?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      analytics?: any;
      error?: string;
    }>(`/agents/content-analytics/${businessId}`);
  }

  // Content Scheduling Agent
  async scheduleContent(scheduleData: {
    title: string;
    content_type: string;
    platform: string;
    scheduled_date: string;
    business_id: string;
    content_data: any;
  }): Promise<{
    success: boolean;
    schedule_id?: string;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      schedule_id?: string;
      error?: string;
    }>('/agents/content-scheduling/schedule', {
      method: 'POST',
      body: JSON.stringify(scheduleData),
    });
  }

  async getContentSchedulesByBusiness(businessId: string): Promise<{
    success: boolean;
    schedules?: any[];
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      schedules?: any[];
      error?: string;
    }>(`/agents/content-scheduling/${businessId}`);
  }

  // SEO Strategy Agent
  async createTopicCluster(clusterData: {
    core_topic: string;
    business_id: string;
    target_keywords: string[];
  }): Promise<{
    success: boolean;
    cluster_id?: string;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      cluster_id?: string;
      error?: string;
    }>('/agents/seo-strategy/topic-cluster', {
      method: 'POST',
      body: JSON.stringify(clusterData),
    });
  }

  async getTopicClusters(businessId: string): Promise<{
    success: boolean;
    clusters?: any[];
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      clusters?: any[];
      error?: string;
    }>(`/agents/seo-strategy/topic-clusters/${businessId}`);
  }

  // Customer Interaction Agent
  async getCustomerInsights(businessId: string): Promise<{
    success: boolean;
    insights?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      insights?: any;
      error?: string;
    }>(`/businesses/${businessId}/customer-insights`);
  }

  async getCustomerInteractions(businessId: string): Promise<{
    success: boolean;
    interactions?: any[];
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      interactions?: any[];
      error?: string;
    }>(`/agents/customer-interaction/${businessId}`);
  }

  // Analyst Agent
  async getBusinessAnalyticsByAgent(businessId: string): Promise<{
    success: boolean;
    analytics?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      analytics?: any;
      error?: string;
    }>(`/agents/analyst/business/${businessId}`);
  }

  async generateBusinessInsights(businessId: string, analysisType: string): Promise<{
    success: boolean;
    insights?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      insights?: any;
      error?: string;
    }>(`/agents/analyst/insights/${businessId}`, {
      method: 'POST',
      body: JSON.stringify({ analysis_type: analysisType }),
    });
  }

  // Optimization Agent
  async createOptimizationTest(testData: {
    name: string;
    test_type: string;
    business_id: string;
    variants: any[];
  }): Promise<{
    success: boolean;
    test_id?: string;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      test_id?: string;
      error?: string;
    }>('/agents/optimization/test', {
      method: 'POST',
      body: JSON.stringify(testData),
    });
  }

  async getOptimizationTests(businessId: string): Promise<{
    success: boolean;
    tests?: any[];
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      tests?: any[];
      error?: string;
    }>(`/agents/optimization/tests/${businessId}`);
  }

  // AI Business Coach Agent
  async getBusinessCoaching(businessId: string): Promise<{
    success: boolean;
    coaching?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      coaching?: any;
      error?: string;
    }>(`/agents/business-coach/${businessId}`);
  }

  async generateBusinessAdvice(businessId: string, topic: string): Promise<{
    success: boolean;
    advice?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      advice?: any;
      error?: string;
    }>(`/agents/business-coach/advice/${businessId}`, {
      method: 'POST',
      body: JSON.stringify({ topic }),
    });
  }

  // Compliance Agent
  async getComplianceStatus(businessId: string): Promise<{
    success: boolean;
    compliance?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      compliance?: any;
      error?: string;
    }>(`/agents/compliance/status/${businessId}`);
  }

  async checkCompliance(businessId: string, complianceType: string): Promise<{
    success: boolean;
    check_result?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      check_result?: any;
      error?: string;
    }>(`/agents/compliance/check/${businessId}`, {
      method: 'POST',
      body: JSON.stringify({ compliance_type: complianceType }),
    });
  }

  // Finance Agent
  async getFinancialAnalysis(businessId: string): Promise<{
    success: boolean;
    analysis?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      analysis?: any;
      error?: string;
    }>(`/agents/finance/analysis/${businessId}`);
  }

  async generateFinancialReport(businessId: string, reportType: string): Promise<{
    success: boolean;
    report?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      report?: any;
      error?: string;
    }>(`/agents/finance/report/${businessId}`, {
      method: 'POST',
      body: JSON.stringify({ report_type: reportType }),
    });
  }

  // Landing Page Agent
  async generateLandingPage(businessId: string, pageData: any): Promise<{
    success: boolean;
    landing_page?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      landing_page?: any;
      error?: string;
    }>(`/agents/landing-page/generate/${businessId}`, {
      method: 'POST',
      body: JSON.stringify(pageData),
    });
  }

  // Marketplace Agent
  async getMarketplaceOpportunities(businessId: string): Promise<{
    success: boolean;
    opportunities?: any[];
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      opportunities?: any[];
      error?: string;
    }>(`/agents/marketplace/opportunities/${businessId}`);
  }

  // Monitoring Agent
  async getMonitoringStatus(businessId: string): Promise<{
    success: boolean;
    status?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      status?: any;
      error?: string;
    }>(`/agents/monitoring/status/${businessId}`);
  }

  // Agent Status and Health
  async getAgentStatus(agentName: string): Promise<{
    success: boolean;
    status?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      status?: any;
      error?: string;
    }>(`/agents/${agentName}/status`);
  }

  async getAllAgentsStatus(): Promise<{
    success: boolean;
    agents?: any[];
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      agents?: any[];
      error?: string;
    }>('/agents/status');
  }

  // API Key Management
  async getAPIKeys(businessId: string): Promise<{
    success: boolean;
    api_keys?: Array<{
      id: string;
      platform: string;
      account_name: string;
      api_key?: string;
      api_secret?: string;
      access_token?: string;
      refresh_token?: string;
      client_id?: string;
      client_secret?: string;
      is_active: boolean;
      created_at: string;
      updated_at: string;
    }>;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      api_keys?: Array<{
        id: string;
        platform: string;
        account_name: string;
        api_key?: string;
        api_secret?: string;
        access_token?: string;
        refresh_token?: string;
        client_id?: string;
        client_secret?: string;
        is_active: boolean;
        created_at: string;
        updated_at: string;
      }>;
      error?: string;
    }>(`/businesses/${businessId}/api-keys`);
  }

  async addAPIKey(apiKeyData: {
    business_id: string;
    platform: string;
    account_name: string;
    api_key?: string;
    api_secret?: string;
    access_token?: string;
    refresh_token?: string;
    client_id?: string;
    client_secret?: string;
  }): Promise<{
    success: boolean;
    api_key_id?: string;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      api_key_id?: string;
      error?: string;
    }>(`/businesses/${apiKeyData.business_id}/api-keys`, {
      method: 'POST',
      body: JSON.stringify(apiKeyData),
    });
  }

  async deleteAPIKey(keyId: string): Promise<{
    success: boolean;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      error?: string;
    }>(`/api-keys/${keyId}`, {
      method: 'DELETE',
    });
  }

  // Target Audience Management
  async getTargetAudiences(businessId: string): Promise<{
    success: boolean;
    audiences?: Array<{
      id: string;
      name: string;
      description: string;
      business_id: string;
      demographics?: {
        age_range?: string;
        gender?: string;
        location?: string;
        income_level?: string;
        education_level?: string;
      };
      interests: string[];
      behaviors: string[];
      platforms: string[];
      estimated_size: number;
      created_by: 'ai' | 'manual';
      is_active: boolean;
      created_at: string;
      updated_at: string;
    }>;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      audiences?: Array<{
        id: string;
        name: string;
        description: string;
        business_id: string;
        demographics?: {
          age_range?: string;
          gender?: string;
          location?: string;
          income_level?: string;
          education_level?: string;
        };
        interests: string[];
        behaviors: string[];
        platforms: string[];
        estimated_size: number;
        created_by: 'ai' | 'manual';
        is_active: boolean;
        created_at: string;
        updated_at: string;
      }>;
      error?: string;
    }>(`/businesses/${businessId}/target-audiences`);
  }

  async createTargetAudience(audienceData: {
    business_id: string;
    name: string;
    description: string;
    demographics?: {
      age_range?: string;
      gender?: string;
      location?: string;
      income_level?: string;
      education_level?: string;
    };
    interests?: string[];
    behaviors?: string[];
    platforms?: string[];
    estimated_size?: number;
    created_by: 'ai' | 'manual';
  }): Promise<{
    success: boolean;
    audience_id?: string;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      audience_id?: string;
      error?: string;
    }>(`/businesses/${audienceData.business_id}/target-audiences`, {
      method: 'POST',
      body: JSON.stringify(audienceData),
    });
  }

  async createAITargetAudience(audienceData: {
    business_id: string;
    business_name: string;
    industry: string;
    target_audience: string;
    brand_voice: string;
    campaign_goal: string;
    budget_range?: string;
    platform_preference?: string;
  }): Promise<{
    success: boolean;
    audience_id?: string;
    audience?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      audience_id?: string;
      audience?: any;
      error?: string;
    }>(`/businesses/${audienceData.business_id}/target-audiences/ai`, {
      method: 'POST',
      body: JSON.stringify(audienceData),
    });
  }

  async deleteTargetAudience(audienceId: string): Promise<{
    success: boolean;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      error?: string;
    }>(`/target-audiences/${audienceId}`, {
      method: 'DELETE',
    });
  }

  // ============================================================================
  // BUSINESS DOCUMENT MANAGEMENT API METHODS
  // ============================================================================

  async uploadBusinessDocument(
    businessId: string,
    file: File,
    category: string = "general",
    description: string = "",
    tags: string = ""
  ): Promise<{
    success: boolean;
    message: string;
    document?: any;
    error?: string;
  }> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('category', category);
    formData.append('description', description);
    formData.append('tags', tags);

    return this.request<{
      success: boolean;
      message: string;
      document?: any;
      error?: string;
    }>(`/businesses/${businessId}/documents/upload`, {
      method: 'POST',
      body: formData,
    });
  }

  async getBusinessDocuments(
    businessId: string,
    category?: string,
    search?: string,
    page: number = 1,
    limit: number = 20
  ): Promise<{
    success: boolean;
    documents?: any[];
    categories?: any;
    pagination?: any;
    stats?: any;
    error?: string;
  }> {
    const params = new URLSearchParams();
    if (category) params.append('category', category);
    if (search) params.append('search', search);
    params.append('page', page.toString());
    params.append('limit', limit.toString());

    return this.request<{
      success: boolean;
      documents?: any[];
      categories?: any;
      pagination?: any;
      stats?: any;
      error?: string;
    }>(`/businesses/${businessId}/documents?${params.toString()}`);
  }

  async getBusinessDocument(
    businessId: string,
    documentId: string
  ): Promise<{
    success: boolean;
    document?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      document?: any;
      error?: string;
    }>(`/businesses/${businessId}/documents/${documentId}`);
  }

  async updateBusinessDocument(
    businessId: string,
    documentId: string,
    updates: {
      category?: string;
      description?: string;
      tags?: string;
      is_public?: boolean;
    }
  ): Promise<{
    success: boolean;
    message: string;
    document?: any;
    error?: string;
  }> {
    const formData = new FormData();
    if (updates.category) formData.append('category', updates.category);
    if (updates.description !== undefined) formData.append('description', updates.description);
    if (updates.tags) formData.append('tags', updates.tags);
    if (updates.is_public !== undefined) formData.append('is_public', updates.is_public.toString());

    return this.request<{
      success: boolean;
      message: string;
      document?: any;
      error?: string;
    }>(`/businesses/${businessId}/documents/${documentId}`, {
      method: 'PUT',
      body: formData,
    });
  }

  async deleteBusinessDocument(
    businessId: string,
    documentId: string
  ): Promise<{
    success: boolean;
    message: string;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      error?: string;
    }>(`/businesses/${businessId}/documents/${documentId}`, {
      method: 'DELETE',
    });
  }

  async getBusinessDocumentCategories(
    businessId: string
  ): Promise<{
    success: boolean;
    categories?: any[];
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      categories?: any[];
      error?: string;
    }>(`/businesses/${businessId}/documents/categories`);
  }

  async downloadBusinessDocument(
    businessId: string,
    documentId: string
  ): Promise<{
    success: boolean;
    message: string;
    download_url?: string;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      download_url?: string;
      error?: string;
    }>(`/businesses/${businessId}/documents/${documentId}/download`, {
      method: 'POST',
    });
  }

  // ============================================================================
  // COMPETITOR MANAGEMENT API METHODS
  // ============================================================================

  async getBusinessCompetitors(
    businessId: string,
    search?: string,
    threatLevel?: string,
    marketPosition?: string,
    page: number = 1,
    limit: number = 20
  ): Promise<{
    success: boolean;
    competitors?: any[];
    pagination?: any;
    stats?: any;
    error?: string;
  }> {
    const params = new URLSearchParams();
    if (search) params.append('search', search);
    if (threatLevel) params.append('threat_level', threatLevel);
    if (marketPosition) params.append('market_position', marketPosition);
    params.append('page', page.toString());
    params.append('limit', limit.toString());

    return this.request<{
      success: boolean;
      competitors?: any[];
      pagination?: any;
      stats?: any;
      error?: string;
    }>(`/businesses/${businessId}/competitors?${params.toString()}`);
  }

  async createBusinessCompetitor(
    businessId: string,
    competitorData: {
      name: string;
      website?: string;
      industry?: string;
      location?: string;
      description?: string;
      market_position?: string;
      competitive_strengths?: string[];
      competitive_weaknesses?: string[];
      unique_selling_proposition?: string;
      pricing_strategy?: string;
      target_audience?: string;
      notes?: string;
      tags?: string[];
    }
  ): Promise<{
    success: boolean;
    message: string;
    competitor?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      competitor?: any;
      error?: string;
    }>(`/businesses/${businessId}/competitors`, {
      method: 'POST',
      body: JSON.stringify(competitorData),
    });
  }

  async getBusinessCompetitor(
    businessId: string,
    competitorId: string
  ): Promise<{
    success: boolean;
    competitor?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      competitor?: any;
      error?: string;
    }>(`/businesses/${businessId}/competitors/${competitorId}`);
  }

  async updateBusinessCompetitor(
    businessId: string,
    competitorId: string,
    competitorData: {
      name?: string;
      website?: string;
      industry?: string;
      location?: string;
      description?: string;
      market_position?: string;
      competitive_strengths?: string[];
      competitive_weaknesses?: string[];
      unique_selling_proposition?: string;
      pricing_strategy?: string;
      target_audience?: string;
      notes?: string;
      tags?: string[];
      is_active?: boolean;
      tracking_enabled?: boolean;
    }
  ): Promise<{
    success: boolean;
    message: string;
    competitor?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      competitor?: any;
      error?: string;
    }>(`/businesses/${businessId}/competitors/${competitorId}`, {
      method: 'PUT',
      body: JSON.stringify(competitorData),
    });
  }

  async deleteBusinessCompetitor(
    businessId: string,
    competitorId: string
  ): Promise<{
    success: boolean;
    message: string;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      error?: string;
    }>(`/businesses/${businessId}/competitors/${competitorId}`, {
      method: 'DELETE',
    });
  }

  async aiDiscoverCompetitors(
    businessId: string,
    industry: string,
    location: string
  ): Promise<{
    success: boolean;
    message: string;
    competitors?: any[];
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      competitors?: any[];
      error?: string;
    }>(`/businesses/${businessId}/competitors/ai-discover`, {
      method: 'POST',
      body: JSON.stringify({ industry, location }),
    });
  }

  async getCompetitorInsights(
    businessId: string,
    competitorId: string
  ): Promise<{
    success: boolean;
    insights?: any[];
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      insights?: any[];
      error?: string;
    }>(`/businesses/${businessId}/competitors/${competitorId}/insights`);
  }

  async createCompetitorInsight(
    businessId: string,
    competitorId: string,
    insightData: {
      insight_type: string;
      title: string;
      description: string;
      insight_data?: any;
      source?: string;
      source_url?: string;
      impact_level?: string;
      impact_description?: string;
      recommended_response?: string;
    }
  ): Promise<{
    success: boolean;
    message: string;
    insight?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      insight?: any;
      error?: string;
    }>(`/businesses/${businessId}/competitors/${competitorId}/insights`, {
      method: 'POST',
      body: JSON.stringify(insightData),
    });
  }

  async getCompetitorAnalytics(
    businessId: string
  ): Promise<{
    success: boolean;
    analytics?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      analytics?: any;
      error?: string;
    }>(`/businesses/${businessId}/competitors/analytics`);
  }

  // =========================
  // BUSINESS PORTFOLIO API
  // =========================

  async createBusinessPortfolioItem(
    businessId: string,
    data: {
      content_type: string;
      content_name: string;
      content_description?: string;
      category?: string;
      subcategory?: string;
      platform?: string;
      content_data: any;
      content_metadata?: any;
      is_draft?: boolean;
      is_published?: boolean;
      status?: string;
      tags?: string[];
      keywords?: string[];
      seo_title?: string;
      seo_description?: string;
      attachments?: any[];
      ai_generated?: boolean;
      ai_prompt?: string;
      ai_model?: string;
      ai_confidence?: number;
    }
  ): Promise<{
    success: boolean;
    message: string;
    portfolio_item?: any;
    content_id?: string;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      portfolio_item?: any;
      content_id?: string;
      error?: string;
    }>(`/businesses/${businessId}/portfolio`, {
      method: 'POST',
      body: JSON.stringify({
        ...data,
        user_id: 'demo_user'
      }),
    });
  }

  async getBusinessPortfolio(
    businessId: string,
    filters?: {
      content_type?: string;
      category?: string;
      status?: string;
      page?: number;
      limit?: number;
    }
  ): Promise<{
    success: boolean;
    portfolio_items?: any[];
    pagination?: any;
    error?: string;
  }> {
    const params = new URLSearchParams();
    if (filters?.content_type) params.append('content_type', filters.content_type);
    if (filters?.category) params.append('category', filters.category);
    if (filters?.status) params.append('status', filters.status);
    if (filters?.page) params.append('page', filters.page.toString());
    if (filters?.limit) params.append('limit', filters.limit.toString());

    return this.request<{
      success: boolean;
      portfolio_items?: any[];
      pagination?: any;
      error?: string;
    }>(`/businesses/${businessId}/portfolio?${params.toString()}`);
  }

  async getBusinessPortfolioItem(
    businessId: string,
    contentId: string
  ): Promise<{
    success: boolean;
    portfolio_item?: any;
    versions?: any[];
    comments?: any[];
    analytics?: any[];
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      portfolio_item?: any;
      versions?: any[];
      comments?: any[];
      analytics?: any[];
      error?: string;
    }>(`/businesses/${businessId}/portfolio/${contentId}`);
  }

  async updateBusinessPortfolioItem(
    businessId: string,
    contentId: string,
    data: {
      content_name?: string;
      content_description?: string;
      category?: string;
      subcategory?: string;
      platform?: string;
      content_data?: any;
      content_metadata?: any;
      is_draft?: boolean;
      is_published?: boolean;
      status?: string;
      tags?: string[];
      keywords?: string[];
      seo_title?: string;
      seo_description?: string;
      attachments?: any[];
      version_name?: string;
      version_description?: string;
      change_summary?: string;
      diff_data?: any;
    }
  ): Promise<{
    success: boolean;
    message: string;
    portfolio_item?: any;
    new_version?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      portfolio_item?: any;
      new_version?: any;
      error?: string;
    }>(`/businesses/${businessId}/portfolio/${contentId}`, {
      method: 'PUT',
      body: JSON.stringify({
        ...data,
        user_id: 'demo_user'
      }),
    });
  }

  async deleteBusinessPortfolioItem(
    businessId: string,
    contentId: string
  ): Promise<{
    success: boolean;
    message: string;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      error?: string;
    }>(`/businesses/${businessId}/portfolio/${contentId}`, {
      method: 'DELETE',
    });
  }

  async createPortfolioVersion(
    businessId: string,
    contentId: string,
    data: {
      version_name?: string;
      version_description?: string;
      content_data?: any;
      content_metadata?: any;
      change_summary?: string;
      diff_data?: any;
    }
  ): Promise<{
    success: boolean;
    message: string;
    version?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      version?: any;
      error?: string;
    }>(`/businesses/${businessId}/portfolio/${contentId}/versions`, {
      method: 'POST',
      body: JSON.stringify({
        ...data,
        user_id: 'demo_user'
      }),
    });
  }

  async addPortfolioComment(
    businessId: string,
    contentId: string,
    data: {
      comment_text: string;
      comment_type?: string;
      parent_comment_id?: number;
      is_private?: boolean;
    }
  ): Promise<{
    success: boolean;
    message: string;
    comment?: any;
    error?: string;
  }> {
    return this.request<{
      success: boolean;
      message: string;
      comment?: any;
      error?: string;
    }>(`/businesses/${businessId}/portfolio/${contentId}/comments`, {
      method: 'POST',
      body: JSON.stringify({
        ...data,
        user_id: 'demo_user'
      }),
    });
  }

  async getPortfolioAnalytics(
    businessId: string,
    filters?: {
      start_date?: string;
      end_date?: string;
      content_type?: string;
    }
  ): Promise<{
    success: boolean;
    analytics?: any;
    error?: string;
  }> {
    const params = new URLSearchParams();
    if (filters?.start_date) params.append('start_date', filters.start_date);
    if (filters?.end_date) params.append('end_date', filters.end_date);
    if (filters?.content_type) params.append('content_type', filters.content_type);

    return this.request<{
      success: boolean;
      analytics?: any;
      error?: string;
    }>(`/businesses/${businessId}/portfolio/analytics?${params.toString()}`);
  }
}

const apiClient = new ApiClient();
export default apiClient; 