/**
 * Utility function to safely extract error messages from any type of error object
 * This prevents [object Object] from being displayed to users
 */
export function getErrorMessage(error: any): string {
  if (!error) return 'Unknown error';
  if (typeof error === 'string') return error;
  if (typeof error.message === 'string') return error.message;
  if (typeof error.detail === 'string') return error.detail;
  if (typeof error.error === 'string') return error.error;
  if (typeof error.reason === 'string') return error.reason;
  if (typeof error.description === 'string') return error.description;
  
  // Try to stringify the object for debugging
  try {
    const stringified = JSON.stringify(error);
    if (stringified !== '{}' && stringified !== '[]') {
      return stringified;
    }
  } catch {
    // If JSON.stringify fails, continue to fallback
  }
  
  // Final fallback
  return 'An unexpected error occurred';
} 