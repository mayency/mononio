import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Utility function for merging class names with clsx and tailwind-merge
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Safely handles Object.entries calls to prevent null/undefined errors
 */
export const safeObjectEntries = (obj: any): [string, any][] => {
  if (!obj || typeof obj !== 'object') {
    return [];
  }
  return Object.entries(obj);
};

/**
 * Safely handles Object.keys calls to prevent null/undefined errors
 */
export const safeObjectKeys = (obj: any): string[] => {
  if (!obj || typeof obj !== 'object') {
    return [];
  }
  return Object.keys(obj);
};

/**
 * Safely handles Object.values calls to prevent null/undefined errors
 */
export const safeObjectValues = (obj: any): any[] => {
  if (!obj || typeof obj !== 'object') {
    return [];
  }
  return Object.values(obj);
}; 