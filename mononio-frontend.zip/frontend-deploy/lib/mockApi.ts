import { 
  ApiResponse, 
  User, 
  Business, 
  BusinessCreate, 
  Campaign, 
  CampaignCreate,
  Lead,
  LeadCreate,
  ContentGenerationRequest,
  ContentGenerationResponse,
  MarketResearchRequest,
  MarketResearchResponse,
  Expense,
  ExpenseCreate,
  BusinessAnalytics,
  LoginRequest,
  LoginResponse,
  DashboardStats
} from '@/types';

// Mock data
const MOCK_USER: User = {
  id: "123",
  email: "demo@launchmate.com",
  name: "Demo User",
  role: "admin",
  created_at: "2024-01-01T00:00:00Z",
  updated_at: "2024-01-01T00:00:00Z"
};

const MOCK_BUSINESSES: Business[] = [
  {
    id: 1,
    name: "TechStart Solutions",
    industry: "technology",
    location: "San Francisco, CA",
    target_audience: "Tech startups and small businesses",
    brand_voice: "Professional and innovative",
    created_at: "2024-01-01T00:00:00Z",
    updated_at: "2024-01-01T00:00:00Z"
  },
  {
    id: 2,
    name: "Creative Marketing Agency",
    industry: "marketing",
    location: "New York, NY",
    target_audience: "Mid-size companies",
    brand_voice: "Creative and bold",
    created_at: "2024-01-05T00:00:00Z",
    updated_at: "2024-01-05T00:00:00Z"
  }
];

const MOCK_CAMPAIGNS: Campaign[] = [
  {
    id: 1,
    business_id: 1,
    name: "Facebook Lead Generation",
    campaign_type: "advertising",
    status: "active",
    budget: 1000,
    start_date: "2024-01-10T00:00:00Z",
    impressions: 5000,
    clicks: 250,
    conversions: 25,
    cost: 450,
    revenue: 2500,
    created_at: "2024-01-10T00:00:00Z",
    updated_at: "2024-01-10T00:00:00Z"
  },
  {
    id: 2,
    business_id: 1,
    name: "Google Ads Brand Awareness",
    campaign_type: "advertising",
    status: "paused",
    budget: 2000,
    start_date: "2024-01-08T00:00:00Z",
    impressions: 8000,
    clicks: 400,
    conversions: 15,
    cost: 1200,
    revenue: 1500,
    created_at: "2024-01-08T00:00:00Z",
    updated_at: "2024-01-08T00:00:00Z"
  }
];

const MOCK_LEADS: Lead[] = [
  {
    id: 1,
    business_id: 1,
    name: "John Smith",
    email: "john@example.com",
    phone: "+1234567890",
    source: "facebook_ads",
    status: "new",
    lead_score: 75,
    converted: false,
    created_at: "2024-01-15T10:30:00Z",
    updated_at: "2024-01-15T10:30:00Z"
  },
  {
    id: 2,
    business_id: 1,
    name: "Jane Doe",
    email: "jane@example.com",
    phone: "+1234567891",
    source: "landing_page",
    status: "contacted",
    lead_score: 85,
    converted: false,
    created_at: "2024-01-15T09:15:00Z",
    updated_at: "2024-01-15T09:15:00Z"
  }
];

const MOCK_DASHBOARD_STATS: DashboardStats = {
  total_businesses: 2,
  active_campaigns: 8,
  total_leads: 342,
  total_revenue: 125000,
  recent_activities: [
    { 
      id: 1,
      type: "campaign_created", 
      description: "New Facebook campaign launched", 
      business_id: 1,
      business_name: "TechStart Solutions",
      timestamp: "2024-01-15T10:30:00Z"
    },
    { 
      id: 2,
      type: "lead_added", 
      description: "New lead from landing page", 
      business_id: 1,
      business_name: "TechStart Solutions",
      timestamp: "2024-01-15T09:15:00Z"
    },
    { 
      id: 3,
      type: "content_generated", 
      description: "Blog post published on LinkedIn", 
      business_id: 1,
      business_name: "TechStart Solutions",
      timestamp: "2024-01-15T08:45:00Z"
    }
  ]
};

class MockApiClient {
  private isAuthenticated = false;

  // Auth token management
  private getAuthToken(): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('auth_token');
    }
    return null;
  }

  private setAuthToken(token: string): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem('auth_token', token);
    }
  }

  private clearAuthToken(): void {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('auth_token');
    }
  }

  // Authentication
  async login(credentials: LoginRequest): Promise<LoginResponse> {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 500));

    if (credentials.email === "demo@launchmate.com" && credentials.password === "demo123") {
      const token = "mock-jwt-token-" + Date.now();
      this.setAuthToken(token);
      this.isAuthenticated = true;
      
      return {
        access_token: token,
        token_type: "bearer",
        user: MOCK_USER
      };
    } else {
      throw new Error("Invalid credentials");
    }
  }

  async logout(): Promise<void> {
    await new Promise(resolve => setTimeout(resolve, 200));
    this.clearAuthToken();
    this.isAuthenticated = false;
  }

  async getCurrentUser(): Promise<User> {
    await new Promise(resolve => setTimeout(resolve, 200));
    
    if (!this.getAuthToken()) {
      throw new Error("Not authenticated");
    }
    
    return MOCK_USER;
  }

  // Business Management
  async createBusiness(business: BusinessCreate): Promise<Business> {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const newBusiness: Business = {
      id: Math.floor(Math.random() * 1000) + 3,
      name: business.name,
      industry: business.industry,
      location: business.location,
      target_audience: business.target_audience,
      brand_voice: business.brand_voice,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    return newBusiness;
  }

  async getBusinesses(): Promise<Business[]> {
    await new Promise(resolve => setTimeout(resolve, 300));
    return MOCK_BUSINESSES;
  }

  async getBusiness(id: number): Promise<Business> {
    await new Promise(resolve => setTimeout(resolve, 200));
    const business = MOCK_BUSINESSES.find(b => b.id === id);
    if (!business) {
      throw new Error("Business not found");
    }
    return business;
  }

  // Campaign Management
  async createCampaign(campaign: CampaignCreate): Promise<Campaign> {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const newCampaign: Campaign = {
      id: Math.floor(Math.random() * 1000) + 3,
      business_id: campaign.business_id,
      name: campaign.name,
      campaign_type: campaign.campaign_type,
      status: "draft",
      budget: campaign.budget,
      start_date: campaign.start_date,
      end_date: campaign.end_date,
      impressions: 0,
      clicks: 0,
      conversions: 0,
      cost: 0,
      revenue: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    return newCampaign;
  }

  async getCampaigns(): Promise<Campaign[]> {
    await new Promise(resolve => setTimeout(resolve, 300));
    return MOCK_CAMPAIGNS;
  }

  async getBusinessCampaigns(businessId: number): Promise<Campaign[]> {
    await new Promise(resolve => setTimeout(resolve, 300));
    return MOCK_CAMPAIGNS.filter(c => c.business_id === businessId);
  }

  async getCampaign(id: number): Promise<Campaign> {
    await new Promise(resolve => setTimeout(resolve, 200));
    const campaign = MOCK_CAMPAIGNS.find(c => c.id === id);
    if (!campaign) {
      throw new Error("Campaign not found");
    }
    return campaign;
  }

  // Lead Management
  async createLead(lead: LeadCreate): Promise<Lead> {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const newLead: Lead = {
      id: Math.floor(Math.random() * 1000) + 3,
      business_id: lead.business_id,
      name: lead.name,
      email: lead.email,
      phone: lead.phone || "",
      source: lead.source,
      status: "new",
      lead_score: Math.floor(Math.random() * 100),
      converted: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    return newLead;
  }

  async getBusinessLeads(businessId: number): Promise<Lead[]> {
    await new Promise(resolve => setTimeout(resolve, 300));
    return MOCK_LEADS.filter(l => l.business_id === businessId);
  }

  async updateLeadStatus(leadId: number, status: string, notes?: string): Promise<Lead> {
    await new Promise(resolve => setTimeout(resolve, 300));
    const lead = MOCK_LEADS.find(l => l.id === leadId);
    if (!lead) {
      throw new Error("Lead not found");
    }
    return { ...lead, status: status as any, updated_at: new Date().toISOString() };
  }

  // Content Generation
  async generateContent(request: ContentGenerationRequest): Promise<ContentGenerationResponse> {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      content: `Generated ${request.content_type} content for ${request.platform} about ${request.business_context.name}`,
      platform: request.platform,
      content_type: request.content_type,
      generated_at: new Date().toISOString(),
      status: "success",
      metadata: {
        content_type: request.content_type,
        platform: request.platform,
        generated_at: new Date().toISOString()
      }
    };
  }

  async optimizeContent(content: string, platform: string, businessId: number): Promise<ContentGenerationResponse> {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    return {
      content: `Optimized content for ${platform}: ${content}`,
      platform: platform,
      content_type: "text",
      generated_at: new Date().toISOString(),
      status: "success",
      metadata: {
        content_type: "text",
        platform: platform,
        generated_at: new Date().toISOString()
      }
    };
  }

  // Market Research
  async conductMarketResearch(request: MarketResearchRequest): Promise<MarketResearchResponse> {
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    return {
      analysis: {
        market_size: "$50B",
        growth_rate: "12%",
        key_players: ["Company A", "Company B", "Company C"]
      },
      insights: [
        "Market is growing rapidly with 12% annual growth",
        "AI integration is the key trend driving innovation",
        "Mobile-first approach is essential for success"
      ],
      recommendations: [
        "Focus on AI-powered solutions",
        "Develop mobile-optimized products",
        "Target emerging markets for growth"
      ],
      competitors: [
        { name: "Competitor A", market_share: "25%" },
        { name: "Competitor B", market_share: "18%" },
        { name: "Competitor C", market_share: "12%" }
      ]
    };
  }

  async answerResearchQuestion(question: string): Promise<ApiResponse> {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    return {
      success: true,
      message: `AI-powered answer to: ${question}`,
      data: {
        answer: `Based on market research, here's what we found about "${question}": The market shows strong potential with growing demand and increasing competition.`,
        sources: ["Market Report 2024", "Industry Analysis", "Consumer Survey"],
        confidence: 0.85
      },
      timestamp: new Date().toISOString()
    };
  }

  // Financial Management
  async createExpense(expense: ExpenseCreate): Promise<Expense> {
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return {
      id: Math.floor(Math.random() * 1000) + 1,
      business_id: expense.business_id,
      amount: expense.amount,
      description: expense.description,
      category: expense.category,
      date: expense.date,
      created_at: new Date().toISOString()
    };
  }

  async getBusinessExpenses(businessId: number): Promise<Expense[]> {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    return [
      {
        id: 1,
        business_id: businessId,
        amount: 150.00,
        description: "Facebook Ads",
        category: "Advertising",
        date: "2024-01-15T00:00:00Z",
        created_at: "2024-01-15T00:00:00Z"
      },
      {
        id: 2,
        business_id: businessId,
        amount: 75.50,
        description: "Office Supplies",
        category: "Operations",
        date: "2024-01-14T00:00:00Z",
        created_at: "2024-01-14T00:00:00Z"
      }
    ];
  }

  async uploadReceipt(businessId: number, file: File): Promise<Expense> {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      id: Math.floor(Math.random() * 1000) + 1,
      business_id: businessId,
      amount: 0,
      description: `Receipt uploaded: ${file.name}`,
      category: "Uploaded",
      date: new Date().toISOString(),
      receipt_url: `https://example.com/receipts/${file.name}`,
      created_at: new Date().toISOString()
    };
  }

  // Analytics
  async getBusinessAnalytics(businessId: number): Promise<BusinessAnalytics> {
    await new Promise(resolve => setTimeout(resolve, 400));
    
    return {
      total_campaigns: 8,
      active_campaigns: 5,
      total_leads: 342,
      conversion_rate: 12.3,
      total_expenses: 2500,
      campaign_performance: [
        { name: "Facebook Ads", impressions: 5000, clicks: 250, conversions: 25, cost: 1200, revenue: 2500 },
        { name: "Google Ads", impressions: 8000, clicks: 400, conversions: 18, cost: 800, revenue: 1800 },
        { name: "LinkedIn", impressions: 3000, clicks: 150, conversions: 12, cost: 600, revenue: 1200 }
      ]
    };
  }

  async getDashboardStats(): Promise<DashboardStats> {
    await new Promise(resolve => setTimeout(resolve, 300));
    return MOCK_DASHBOARD_STATS;
  }

  // System Status
  async getSystemStatus(): Promise<ApiResponse> {
    await new Promise(resolve => setTimeout(resolve, 200));
    
    return {
      success: true,
      message: "System is running in demo mode",
      data: {
        status: "healthy",
        mode: "demo",
        version: "1.0.0",
        uptime: "2 hours"
      },
      timestamp: new Date().toISOString()
    };
  }

  async accomplishGoal(goal: string, aiProvider?: string): Promise<ApiResponse> {
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    return {
      success: true,
      message: `Goal accomplished: ${goal}`,
      data: {
        goal: goal,
        status: "completed",
        ai_provider: aiProvider || "openai",
        steps_taken: [
          "Analyzed goal requirements",
          "Generated action plan",
          "Executed strategy",
          "Monitored results"
        ],
        results: "Goal successfully accomplished with AI assistance"
      },
      timestamp: new Date().toISOString()
    };
  }

  async getAvailableTools(): Promise<ApiResponse> {
    await new Promise(resolve => setTimeout(resolve, 200));
    
    return {
      success: true,
      message: "Available AI tools",
      data: {
        tools: [
          "Content Generation",
          "Market Research",
          "Campaign Optimization",
          "Lead Analysis",
          "Financial Planning",
          "Social Media Management"
        ],
        status: "all_available"
      },
      timestamp: new Date().toISOString()
    };
  }
}

export default new MockApiClient(); 