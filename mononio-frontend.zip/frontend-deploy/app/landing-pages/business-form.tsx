'use client';

import React, { useState } from 'react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import { Label } from '@/components/ui/Label';
import { Badge } from '@/components/ui/Badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/Tabs';
import toast from 'react-hot-toast';
import {
  BuildingOfficeIcon,
  UserGroupIcon,
  GlobeAltIcon,
  PhoneIcon,
  EnvelopeIcon,
  CurrencyDollarIcon,
  DocumentTextIcon,
  SparklesIcon,
  EyeIcon,
  CheckCircleIcon,
} from '@heroicons/react/24/outline';

interface BusinessFormData {
  // Basic Information
  business_name: string;
  industry: string;
  business_type: string;
  description: string;
  target_audience: string;
  unique_value_proposition: string;
  
  // Contact Information
  contact_info: {
    email?: string;
    phone?: string;
    website?: string;
    address?: string;
    city?: string;
    state?: string;
    zip_code?: string;
  };
  
  // Services/Products
  services: Array<{
    name: string;
    description: string;
    price?: string;
    features?: string[];
  }>;
  
  // Pricing
  pricing: {
    current_price?: string;
    original_price?: string;
    consultation?: string;
    payment_plans?: Array<{
      name: string;
      price: string;
      features: string[];
    }>;
  };
  
  // Branding
  brand_voice: string;
  color_preferences: string[];
  style_preferences: string[];
  
  // Goals & Objectives
  primary_goal: string;
  secondary_goals: string[];
  call_to_action: string;
  
  // Additional Information
  testimonials?: Array<{
    name: string;
    role: string;
    company: string;
    content: string;
  }>;
  
  social_proof?: {
    years_in_business?: number;
    clients_served?: number;
    awards?: string[];
    certifications?: string[];
  };
}

const INDUSTRIES = [
  { value: 'technology', label: 'Technology' },
  { value: 'healthcare', label: 'Healthcare' },
  { value: 'finance', label: 'Finance & Banking' },
  { value: 'education', label: 'Education' },
  { value: 'real_estate', label: 'Real Estate' },
  { value: 'retail', label: 'Retail & E-commerce' },
  { value: 'consulting', label: 'Consulting' },
  { value: 'marketing', label: 'Marketing & Advertising' },
  { value: 'legal', label: 'Legal Services' },
  { value: 'manufacturing', label: 'Manufacturing' },
  { value: 'food_beverage', label: 'Food & Beverage' },
  { value: 'fitness', label: 'Fitness & Wellness' },
  { value: 'beauty', label: 'Beauty & Personal Care' },
  { value: 'automotive', label: 'Automotive' },
  { value: 'travel', label: 'Travel & Tourism' },
  { value: 'other', label: 'Other' },
];

const BUSINESS_TYPES = [
  { value: 'service', label: 'Service Business' },
  { value: 'consulting', label: 'Consulting' },
  { value: 'coaching', label: 'Coaching' },
  { value: 'agency', label: 'Agency' },
  { value: 'product', label: 'Product' },
  { value: 'physical_product', label: 'Physical Product' },
  { value: 'digital_product', label: 'Digital Product' },
  { value: 'software', label: 'Software' },
  { value: 'course', label: 'Course' },
  { value: 'ebook', label: 'E-book' },
  { value: 'membership', label: 'Membership' },
  { value: 'subscription', label: 'Subscription' },
];

const BRAND_VOICES = [
  { value: 'professional', label: 'Professional & Formal' },
  { value: 'friendly', label: 'Friendly & Approachable' },
  { value: 'authoritative', label: 'Authoritative & Expert' },
  { value: 'casual', label: 'Casual & Relatable' },
  { value: 'luxury', label: 'Luxury & Premium' },
  { value: 'innovative', label: 'Innovative & Cutting-edge' },
  { value: 'trustworthy', label: 'Trustworthy & Reliable' },
  { value: 'energetic', label: 'Energetic & Dynamic' },
];

const COLOR_SCHEMES = [
  { value: 'modern_blue', label: 'Modern Blue', colors: ['#3B82F6', '#1E40AF', '#DBEAFE'] },
  { value: 'professional_gray', label: 'Professional Gray', colors: ['#374151', '#6B7280', '#F3F4F6'] },
  { value: 'energetic_orange', label: 'Energetic Orange', colors: ['#F59E0B', '#D97706', '#FEF3C7'] },
  { value: 'trustworthy_green', label: 'Trustworthy Green', colors: ['#10B981', '#059669', '#D1FAE5'] },
  { value: 'luxury_purple', label: 'Luxury Purple', colors: ['#8B5CF6', '#7C3AED', '#EDE9FE'] },
  { value: 'bold_red', label: 'Bold Red', colors: ['#EF4444', '#DC2626', '#FEE2E2'] },
  { value: 'calm_teal', label: 'Calm Teal', colors: ['#14B8A6', '#0D9488', '#CCFBF1'] },
];

const STYLE_PREFERENCES = [
  { value: 'minimalist', label: 'Minimalist & Clean' },
  { value: 'modern', label: 'Modern & Sleek' },
  { value: 'classic', label: 'Classic & Traditional' },
  { value: 'bold', label: 'Bold & Dynamic' },
  { value: 'elegant', label: 'Elegant & Sophisticated' },
  { value: 'playful', label: 'Playful & Creative' },
  { value: 'corporate', label: 'Corporate & Professional' },
  { value: 'startup', label: 'Startup & Innovative' },
];

const PRIMARY_GOALS = [
  { value: 'lead_generation', label: 'Lead Generation' },
  { value: 'sales_conversion', label: 'Sales Conversion' },
  { value: 'brand_awareness', label: 'Brand Awareness' },
  { value: 'product_showcase', label: 'Product Showcase' },
  { value: 'service_booking', label: 'Service Booking' },
  { value: 'newsletter_signup', label: 'Newsletter Signup' },
  { value: 'appointment_booking', label: 'Appointment Booking' },
  { value: 'contact_information', label: 'Contact Information' },
];

interface BusinessFormProps {
  onSubmit: (data: BusinessFormData) => void;
  isLoading?: boolean;
}

export default function BusinessForm({ onSubmit, isLoading = false }: BusinessFormProps) {
  const [formData, setFormData] = useState<BusinessFormData>({
    business_name: '',
    industry: '',
    business_type: 'service',
    description: '',
    target_audience: '',
    unique_value_proposition: '',
    contact_info: {},
    services: [{ name: '', description: '', features: [] }],
    pricing: {},
    brand_voice: 'professional',
    color_preferences: [],
    style_preferences: [],
    primary_goal: 'lead_generation',
    secondary_goals: [],
    call_to_action: 'Get Started Today',
  });

  const [activeTab, setActiveTab] = useState('basic');
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});

  const updateFormData = (field: string, value: any) => {
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...(prev[parent as keyof BusinessFormData] as object || {}),
          [child]: value,
        },
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [field]: value,
      }));
    }
  };

  const updateService = (index: number, field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.map((service, i) => 
        i === index ? { ...service, [field]: value } : service
      ),
    }));
  };

  const addService = () => {
    setFormData(prev => ({
      ...prev,
      services: [...prev.services, { name: '', description: '', features: [] }],
    }));
  };

  const removeService = (index: number) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.filter((_, i) => i !== index),
    }));
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!formData.business_name.trim()) {
      errors.business_name = 'Business name is required';
    }

    if (!formData.industry) {
      errors.industry = 'Industry is required';
    }

    if (!formData.description.trim()) {
      errors.description = 'Business description is required';
    }

    if (!formData.target_audience.trim()) {
      errors.target_audience = 'Target audience is required';
    }

    if (!formData.unique_value_proposition.trim()) {
      errors.unique_value_proposition = 'Unique value proposition is required';
    }

    if (formData.services.length === 0 || !formData.services[0].name.trim()) {
      errors.services = 'At least one service is required';
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateForm()) {
      toast.error('Please fill in all required fields');
      return;
    }

    onSubmit(formData);
  };

  const getError = (field: string): string => {
    return validationErrors[field] || '';
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Create Your Professional Landing Page
        </h1>
        <p className="text-gray-600">
          Fill out the form below to generate a stunning, conversion-optimized landing page for your business.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="basic">Basic Info</TabsTrigger>
          <TabsTrigger value="services">Services</TabsTrigger>
          <TabsTrigger value="contact">Contact</TabsTrigger>
          <TabsTrigger value="branding">Branding</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
        </TabsList>

        <TabsContent value="basic" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-xl font-semibold mb-4 flex items-center">
              <BuildingOfficeIcon className="w-5 h-5 mr-2" />
              Basic Business Information
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="business_name">Business Name *</Label>
                <Input
                  id="business_name"
                  value={formData.business_name}
                  onChange={(e) => updateFormData('business_name', e.target.value)}
                  placeholder="Enter your business name"
                  className={getError('business_name') ? 'border-red-500' : ''}
                />
                {getError('business_name') && (
                  <p className="text-red-500 text-sm mt-1">{getError('business_name')}</p>
                )}
              </div>

              <div>
                <Label htmlFor="industry">Industry *</Label>
                <select
                  id="industry"
                  value={formData.industry}
                  onChange={(e) => updateFormData('industry', e.target.value)}
                  className={`w-full px-3 py-2 border rounded-md ${
                    getError('industry') ? 'border-red-500' : 'border-gray-300'
                  }`}
                >
                  <option value="">Select Industry</option>
                  {INDUSTRIES.map((industry) => (
                    <option key={industry.value} value={industry.value}>
                      {industry.label}
                    </option>
                  ))}
                </select>
                {getError('industry') && (
                  <p className="text-red-500 text-sm mt-1">{getError('industry')}</p>
                )}
              </div>

              <div>
                <Label htmlFor="business_type">Business Type</Label>
                <select
                  id="business_type"
                  value={formData.business_type}
                  onChange={(e) => updateFormData('business_type', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                >
                  {BUSINESS_TYPES.map((type) => (
                    <option key={type.value} value={type.value}>
                      {type.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label htmlFor="brand_voice">Brand Voice</Label>
                <select
                  id="brand_voice"
                  value={formData.brand_voice}
                  onChange={(e) => updateFormData('brand_voice', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                >
                  {BRAND_VOICES.map((voice) => (
                    <option key={voice.value} value={voice.value}>
                      {voice.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="description">Business Description *</Label>
                <textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => updateFormData('description', e.target.value)}
                  placeholder="Describe what your business does, your mission, and what makes you unique"
                  rows={4}
                  className={`w-full px-3 py-2 border rounded-md ${
                    getError('description') ? 'border-red-500' : 'border-gray-300'
                  }`}
                />
                {getError('description') && (
                  <p className="text-red-500 text-sm mt-1">{getError('description')}</p>
                )}
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="target_audience">Target Audience *</Label>
                <Input
                  id="target_audience"
                  value={formData.target_audience}
                  onChange={(e) => updateFormData('target_audience', e.target.value)}
                  placeholder="e.g., Small business owners, Tech professionals, Health-conscious individuals"
                  className={getError('target_audience') ? 'border-red-500' : ''}
                />
                {getError('target_audience') && (
                  <p className="text-red-500 text-sm mt-1">{getError('target_audience')}</p>
                )}
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="unique_value_proposition">Unique Value Proposition *</Label>
                <Input
                  id="unique_value_proposition"
                  value={formData.unique_value_proposition}
                  onChange={(e) => updateFormData('unique_value_proposition', e.target.value)}
                  placeholder="What makes your business different? What unique value do you provide?"
                  className={getError('unique_value_proposition') ? 'border-red-500' : ''}
                />
                {getError('unique_value_proposition') && (
                  <p className="text-red-500 text-sm mt-1">{getError('unique_value_proposition')}</p>
                )}
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="services" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-xl font-semibold mb-4 flex items-center">
              <DocumentTextIcon className="w-5 h-5 mr-2" />
              Services & Products
            </h3>
            
            {formData.services.map((service, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4 mb-4">
                <div className="flex justify-between items-center mb-4">
                  <h4 className="font-medium">Service {index + 1}</h4>
                  {formData.services.length > 1 && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeService(index)}
                      className="text-red-600 hover:text-red-700"
                    >
                      Remove
                    </Button>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor={`service_name_${index}`}>Service Name *</Label>
                    <Input
                      id={`service_name_${index}`}
                      value={service.name}
                      onChange={(e) => updateService(index, 'name', e.target.value)}
                      placeholder="e.g., Web Design, Consulting, Product Development"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor={`service_price_${index}`}>Price (Optional)</Label>
                    <Input
                      id={`service_price_${index}`}
                      value={service.price || ''}
                      onChange={(e) => updateService(index, 'price', e.target.value)}
                      placeholder="e.g., $99/month, $500, Free Consultation"
                    />
                  </div>
                  
                  <div className="md:col-span-2">
                    <Label htmlFor={`service_description_${index}`}>Description</Label>
                    <textarea
                      id={`service_description_${index}`}
                      value={service.description}
                      onChange={(e) => updateService(index, 'description', e.target.value)}
                      placeholder="Describe what this service includes and its benefits"
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    />
                  </div>
                </div>
              </div>
            ))}
            
            <Button
              variant="outline"
              onClick={addService}
              className="w-full"
            >
              + Add Another Service
            </Button>
            
            {getError('services') && (
              <p className="text-red-500 text-sm mt-2">{getError('services')}</p>
            )}
          </Card>
        </TabsContent>

        <TabsContent value="contact" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-xl font-semibold mb-4 flex items-center">
              <GlobeAltIcon className="w-5 h-5 mr-2" />
              Contact Information
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.contact_info.email || ''}
                  onChange={(e) => updateFormData('contact_info.email', e.target.value)}
                  placeholder="contact@yourbusiness.com"
                />
              </div>

              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.contact_info.phone || ''}
                  onChange={(e) => updateFormData('contact_info.phone', e.target.value)}
                  placeholder="+1 (555) 123-4567"
                />
              </div>

              <div>
                <Label htmlFor="website">Website</Label>
                <Input
                  id="website"
                  type="url"
                  value={formData.contact_info.website || ''}
                  onChange={(e) => updateFormData('contact_info.website', e.target.value)}
                  placeholder="https://yourbusiness.com"
                />
              </div>

              <div>
                <Label htmlFor="address">Street Address</Label>
                <Input
                  id="address"
                  value={formData.contact_info.address || ''}
                  onChange={(e) => updateFormData('contact_info.address', e.target.value)}
                  placeholder="123 Business St"
                />
              </div>

              <div>
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  value={formData.contact_info.city || ''}
                  onChange={(e) => updateFormData('contact_info.city', e.target.value)}
                  placeholder="New York"
                />
              </div>

              <div>
                <Label htmlFor="state">State</Label>
                <Input
                  id="state"
                  value={formData.contact_info.state || ''}
                  onChange={(e) => updateFormData('contact_info.state', e.target.value)}
                  placeholder="NY"
                />
              </div>

              <div>
                <Label htmlFor="zip_code">ZIP Code</Label>
                <Input
                  id="zip_code"
                  value={formData.contact_info.zip_code || ''}
                  onChange={(e) => updateFormData('contact_info.zip_code', e.target.value)}
                  placeholder="10001"
                />
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="branding" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-xl font-semibold mb-4 flex items-center">
              <SparklesIcon className="w-5 h-5 mr-2" />
              Branding & Design Preferences
            </h3>
            
            <div className="space-y-6">
              <div>
                <Label>Color Scheme</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-2">
                  {COLOR_SCHEMES.map((scheme) => (
                    <div
                      key={scheme.value}
                      className={`border-2 rounded-lg p-3 cursor-pointer transition-all ${
                        formData.color_preferences.includes(scheme.value)
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => {
                        const newColors = formData.color_preferences.includes(scheme.value)
                          ? formData.color_preferences.filter(c => c !== scheme.value)
                          : [...formData.color_preferences, scheme.value];
                        updateFormData('color_preferences', newColors);
                      }}
                    >
                      <div className="flex items-center space-x-2 mb-2">
                        <div className="flex space-x-1">
                          {scheme.colors.map((color, i) => (
                            <div
                              key={i}
                              className="w-4 h-4 rounded-full"
                              style={{ backgroundColor: color }}
                            />
                          ))}
                        </div>
                        <span className="text-sm font-medium">{scheme.label}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label>Style Preferences</Label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-2">
                  {STYLE_PREFERENCES.map((style) => (
                    <div
                      key={style.value}
                      className={`border-2 rounded-lg p-3 cursor-pointer transition-all ${
                        formData.style_preferences.includes(style.value)
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => {
                        const newStyles = formData.style_preferences.includes(style.value)
                          ? formData.style_preferences.filter(s => s !== style.value)
                          : [...formData.style_preferences, style.value];
                        updateFormData('style_preferences', newStyles);
                      }}
                    >
                      <span className="text-sm font-medium">{style.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="goals" className="space-y-6">
          <Card className="p-6">
            <h3 className="text-xl font-semibold mb-4 flex items-center">
              <EyeIcon className="w-5 h-5 mr-2" />
              Goals & Call-to-Action
            </h3>
            
            <div className="space-y-6">
              <div>
                <Label htmlFor="primary_goal">Primary Goal *</Label>
                <select
                  id="primary_goal"
                  value={formData.primary_goal}
                  onChange={(e) => updateFormData('primary_goal', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                >
                  {PRIMARY_GOALS.map((goal) => (
                    <option key={goal.value} value={goal.value}>
                      {goal.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label htmlFor="call_to_action">Call-to-Action Text</Label>
                <Input
                  id="call_to_action"
                  value={formData.call_to_action}
                  onChange={(e) => updateFormData('call_to_action', e.target.value)}
                  placeholder="Get Started Today"
                />
              </div>

              <div>
                <Label>Secondary Goals (Optional)</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-2">
                  {PRIMARY_GOALS.map((goal) => (
                    <div
                      key={goal.value}
                      className={`border-2 rounded-lg p-3 cursor-pointer transition-all ${
                        formData.secondary_goals.includes(goal.value)
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => {
                        const newGoals = formData.secondary_goals.includes(goal.value)
                          ? formData.secondary_goals.filter(g => g !== goal.value)
                          : [...formData.secondary_goals, goal.value];
                        updateFormData('secondary_goals', newGoals);
                      }}
                    >
                      <span className="text-sm font-medium">{goal.label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-8 flex justify-between items-center">
        <div className="text-sm text-gray-600">
          * Required fields
        </div>
        
        <Button
          onClick={handleSubmit}
          disabled={isLoading}
          className="px-8 py-3"
        >
          {isLoading ? (
            <div className="flex items-center">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Generating Landing Page...
            </div>
          ) : (
            <div className="flex items-center">
              <CheckCircleIcon className="w-5 h-5 mr-2" />
              Generate Landing Page
            </div>
          )}
        </Button>
      </div>
    </div>
  );
} 