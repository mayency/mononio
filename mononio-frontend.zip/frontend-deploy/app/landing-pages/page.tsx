'use client';

import { useState, useEffect } from 'react';
import { useAuthStore } from '@/store/auth';
import ClientOnly from '@/components/auth/ClientOnly';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import Sidebar from '@/components/layout/Sidebar';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import { Label } from '@/components/ui/Label';
import { Badge } from '@/components/ui/Badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/Tabs';
import toast from 'react-hot-toast';
import apiClient from '@/lib/api';
import VisualLandingPageBuilder from './visual-builder';
import {
  PlusIcon,
  GlobeAltIcon,
  DocumentTextIcon,
  EyeIcon,
  PencilIcon,
  TrashIcon,
  CheckCircleIcon,
  ClockIcon,
  ExclamationTriangleIcon,
} from '@heroicons/react/24/outline';
import { Business } from '@/types';

interface LandingPage {
  id: string;
  business_name: string;
  business_type: string;
  live_url: string;
  status: 'draft' | 'published' | 'error';
  created_at: string;
  updated_at: string;
  template_used: string;
  views?: number;
  conversions?: number;
}

interface BusinessInfo {
  business_name: string;
  business_type: string;
  description: string;
  target_audience: string;
  unique_value_proposition: string;
  contact_info: {
    email?: string;
    phone?: string;
    website?: string;
  };
  pricing: {
    current_price?: string;
    original_price?: string;
    consultation?: string;
  };
}

export default function LandingPagesPage() {
  const { user } = useAuthStore();
  const [landingPages, setLandingPages] = useState<LandingPage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [activeTab, setActiveTab] = useState('create');
  const [showVisualBuilder, setShowVisualBuilder] = useState(false);
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo>({
    business_name: '',
    business_type: 'service',
    description: '',
    target_audience: '',
    unique_value_proposition: '',
    contact_info: {},
    pricing: {},
  });
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [selectedBusinessId, setSelectedBusinessId] = useState<string | 'other' | ''>('');

  const businessTypes = [
    { value: 'service', label: 'Service Business' },
    { value: 'consulting', label: 'Consulting' },
    { value: 'coaching', label: 'Coaching' },
    { value: 'agency', label: 'Agency' },
    { value: 'product', label: 'Product' },
    { value: 'physical_product', label: 'Physical Product' },
    { value: 'digital_product', label: 'Digital Product' },
    { value: 'software', label: 'Software' },
    { value: 'course', label: 'Course' },
    { value: 'ebook', label: 'E-book' },
  ];

  useEffect(() => {
    fetchLandingPages();
    fetchBusinesses();
  }, []);

  const fetchLandingPages = async () => {
    setIsLoading(true);
    try {
      const response = await apiClient.getLandingPages();
      if (response.success) {
        // Transform the backend data to match frontend interface
        const transformedPages: LandingPage[] = response.data.map(page => ({
          id: page.page_id,
          business_name: page.metadata.business_name,
          business_type: page.metadata.industry,
          live_url: page.preview_url,
          status: 'published' as const,
          created_at: page.created_at,
          updated_at: page.created_at,
          template_used: 'modern_landing_page',
          views: 0,
          conversions: 0,
        }));
        setLandingPages(transformedPages);
      } else {
        toast.error('Failed to fetch landing pages');
      }
    } catch (error) {
      console.error('Error fetching landing pages:', error);
      toast.error('Failed to fetch landing pages');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchBusinesses = async () => {
    try {
      const data = await apiClient.getBusinesses();
      setBusinesses(data || []);
    } catch (error) {
      toast.error('Failed to fetch businesses');
    }
  };

  const handleInputChange = (field: string, value: any) => {
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      setBusinessInfo(prev => ({
        ...prev,
        [parent]: {
          ...(prev[parent as keyof BusinessInfo] as object || {}),
          [child]: value,
        },
      }));
    } else {
      setBusinessInfo(prev => ({
        ...prev,
        [field]: value,
      }));
    }
  };

  const validateForm = (): boolean => {
    if (!businessInfo.business_name.trim()) {
      toast.error('Business name is required');
      return false;
    }
    if (!businessInfo.description.trim()) {
      toast.error('Business description is required');
      return false;
    }
    if (!businessInfo.target_audience.trim()) {
      toast.error('Target audience is required');
      return false;
    }
    return true;
  };

  const createLandingPage = async () => {
    if (!validateForm()) return;

    setIsCreating(true);
    try {
      const response = await apiClient.createLandingPage(businessInfo);
      
      if (response.page_id) {
        // Add the new page to the list
        const newPage: LandingPage = {
          id: response.page_id,
          business_name: businessInfo.business_name,
          business_type: businessInfo.business_type,
          live_url: response.preview_url || '',
          status: 'published',
          created_at: response.created_at,
          updated_at: response.created_at,
          template_used: 'modern_landing_page',
          views: 0,
          conversions: 0,
        };

        setLandingPages(prev => [newPage, ...prev]);
        setBusinessInfo({
          business_name: '',
          business_type: 'service',
          description: '',
          target_audience: '',
          unique_value_proposition: '',
          contact_info: {},
          pricing: {},
        });
        setActiveTab('pages');
        toast.success('Landing page created successfully!');
      } else {
        toast.error('Failed to create landing page');
      }
    } catch (error) {
      console.error('Error creating landing page:', error);
      toast.error('Failed to create landing page');
    } finally {
      setIsCreating(false);
    }
  };

  const handleVisualBuilderSave = (pageData: any) => {
    // Handle saving the visual builder data
    console.log('Visual builder data:', pageData);
    toast.success('Visual landing page saved!');
    setShowVisualBuilder(false);
  };

  const openVisualBuilder = () => {
    if (!validateForm()) return;
    setShowVisualBuilder(true);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'published':
        return <CheckCircleIcon className="h-4 w-4 text-green-500" />;
      case 'draft':
        return <ClockIcon className="h-4 w-4 text-yellow-500" />;
      case 'error':
        return <ExclamationTriangleIcon className="h-4 w-4 text-red-500" />;
      default:
        return <ClockIcon className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'published':
        return <Badge variant="success">Published</Badge>;
      case 'draft':
        return <Badge variant="warning">Draft</Badge>;
      case 'error':
        return <Badge variant="destructive">Error</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="bg-white border-b border-secondary-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-secondary-900">Landing Pages</h1>
                <p className="text-secondary-600">Create and manage high-converting landing pages</p>
              </div>
              <Button
                onClick={() => setActiveTab('create')}
                className="flex items-center space-x-2"
              >
                <PlusIcon className="h-5 w-5" />
                <span>Create Landing Page</span>
              </Button>
            </div>
          </header>

          {/* Main Content */}
          <main className="flex-1 overflow-auto p-6">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="create">Create New Page</TabsTrigger>
                <TabsTrigger value="pages">My Landing Pages</TabsTrigger>
              </TabsList>

              <TabsContent value="create" className="space-y-6">
                <Card className="p-6">
                  <div className="flex items-center space-x-3 mb-6">
                    <GlobeAltIcon className="h-6 w-6 text-primary-600" />
                    <h2 className="text-xl font-semibold text-secondary-900">Create Landing Page</h2>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Basic Information */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium text-secondary-900">Basic Information</h3>
                      
                      <div>
                        <Label htmlFor="business_name">Business Name *</Label>
                        <select
                          id="business_name"
                          value={selectedBusinessId}
                          onChange={e => {
                            const val = e.target.value;
                            setSelectedBusinessId(val);
                            if (val === 'other' || val === '') {
                              setBusinessInfo(prev => ({
                                ...prev,
                                business_name: '',
                                business_type: 'service',
                                description: '',
                                target_audience: '',
                              }));
                            } else {
                              const biz = businesses.find(b => String(b.id) === val);
                              if (biz) {
                                setBusinessInfo(prev => ({
                                  ...prev,
                                  business_name: biz.name,
                                  business_type: biz.industry || 'service',
                                  description: biz.brand_voice || '',
                                  target_audience: biz.target_audience || '',
                                }));
                              }
                            }
                          }}
                          className="w-full px-3 py-2 border border-secondary-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        >
                          <option value="">Select a business</option>
                          {businesses.map(biz => (
                            <option key={biz.id} value={biz.id}>{biz.name}</option>
                          ))}
                          <option value="other">Other (enter manually)</option>
                        </select>
                        {(selectedBusinessId === 'other' || selectedBusinessId === '') && (
                          <Input
                            id="business_name_manual"
                            value={businessInfo.business_name}
                            onChange={e => handleInputChange('business_name', e.target.value)}
                            placeholder="Enter your business name"
                            className="mt-2"
                          />
                        )}
                      </div>

                      <div>
                        <Label htmlFor="business_type">Business Type *</Label>
                        <select
                          id="business_type"
                          value={businessInfo.business_type}
                          onChange={(e) => handleInputChange('business_type', e.target.value)}
                          className="w-full px-3 py-2 border border-secondary-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        >
                          {businessTypes.map(type => (
                            <option key={type.value} value={type.value}>
                              {type.label}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <Label htmlFor="description">Business Description *</Label>
                        <textarea
                          id="description"
                          value={businessInfo.description}
                          onChange={(e) => handleInputChange('description', e.target.value)}
                          placeholder="Describe what your business does"
                          rows={3}
                          className="w-full px-3 py-2 border border-secondary-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        />
                      </div>

                      <div>
                        <Label htmlFor="target_audience">Target Audience *</Label>
                        <Input
                          id="target_audience"
                          value={businessInfo.target_audience}
                          onChange={(e) => handleInputChange('target_audience', e.target.value)}
                          placeholder="e.g., small business owners, tech professionals"
                        />
                      </div>

                      <div>
                        <Label htmlFor="unique_value_proposition">Unique Value Proposition</Label>
                        <Input
                          id="unique_value_proposition"
                          value={businessInfo.unique_value_proposition}
                          onChange={(e) => handleInputChange('unique_value_proposition', e.target.value)}
                          placeholder="What makes you different from competitors?"
                        />
                      </div>
                    </div>

                    {/* Contact & Pricing */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium text-secondary-900">Contact & Pricing</h3>
                      
                      <div>
                        <Label htmlFor="contact_email">Contact Email</Label>
                        <Input
                          id="contact_email"
                          type="email"
                          value={businessInfo.contact_info.email || ''}
                          onChange={(e) => handleInputChange('contact_info.email', e.target.value)}
                          placeholder="your@email.com"
                        />
                      </div>

                      <div>
                        <Label htmlFor="contact_phone">Phone Number</Label>
                        <Input
                          id="contact_phone"
                          value={businessInfo.contact_info.phone || ''}
                          onChange={(e) => handleInputChange('contact_info.phone', e.target.value)}
                          placeholder="+1 (555) 123-4567"
                        />
                      </div>

                      <div>
                        <Label htmlFor="contact_website">Website</Label>
                        <Input
                          id="contact_website"
                          value={businessInfo.contact_info.website || ''}
                          onChange={(e) => handleInputChange('contact_info.website', e.target.value)}
                          placeholder="https://yourwebsite.com"
                        />
                      </div>

                      {businessInfo.business_type.includes('product') ? (
                        <>
                          <div>
                            <Label htmlFor="current_price">Current Price</Label>
                            <Input
                              id="current_price"
                              value={businessInfo.pricing.current_price || ''}
                              onChange={(e) => handleInputChange('pricing.current_price', e.target.value)}
                              placeholder="$99"
                            />
                          </div>
                          <div>
                            <Label htmlFor="original_price">Original Price</Label>
                            <Input
                              id="original_price"
                              value={businessInfo.pricing.original_price || ''}
                              onChange={(e) => handleInputChange('pricing.original_price', e.target.value)}
                              placeholder="$199"
                            />
                          </div>
                        </>
                      ) : (
                        <div>
                          <Label htmlFor="consultation">Consultation Fee</Label>
                          <Input
                            id="consultation"
                            value={businessInfo.pricing.consultation || ''}
                            onChange={(e) => handleInputChange('pricing.consultation', e.target.value)}
                            placeholder="Free initial consultation"
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="mt-8 flex justify-end space-x-4">
                    <Button
                      variant="secondary"
                      onClick={() => setActiveTab('pages')}
                    >
                      Cancel
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={openVisualBuilder}
                      disabled={isCreating}
                      className="flex items-center space-x-2"
                    >
                      <DocumentTextIcon className="h-5 w-5" />
                      <span>Visual Builder</span>
                    </Button>
                    <Button
                      onClick={createLandingPage}
                      disabled={isCreating}
                      className="flex items-center space-x-2"
                    >
                      {isCreating ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                          <span>Creating...</span>
                        </>
                      ) : (
                        <>
                          <GlobeAltIcon className="h-5 w-5" />
                          <span>Create Landing Page</span>
                        </>
                      )}
                    </Button>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="pages" className="space-y-6">
                <Card className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center space-x-3">
                      <DocumentTextIcon className="h-6 w-6 text-primary-600" />
                      <h2 className="text-xl font-semibold text-secondary-900">My Landing Pages</h2>
                    </div>
                    <Button
                      variant="secondary"
                      onClick={fetchLandingPages}
                      disabled={isLoading}
                    >
                      Refresh
                    </Button>
                  </div>

                  {isLoading ? (
                    <div className="text-center py-12">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600 mx-auto"></div>
                      <p className="mt-4 text-secondary-600">Loading landing pages...</p>
                    </div>
                  ) : landingPages.length === 0 ? (
                    <div className="text-center py-12">
                      <GlobeAltIcon className="h-12 w-12 text-secondary-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-secondary-900 mb-2">No landing pages yet</h3>
                      <p className="text-secondary-600 mb-6">Create your first landing page to start capturing leads</p>
                      <Button onClick={() => setActiveTab('create')}>
                        Create Your First Landing Page
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {landingPages.map((page) => (
                        <div
                          key={page.id}
                          className="border border-secondary-200 rounded-lg p-4 hover:bg-secondary-50 transition-colors"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                              {getStatusIcon(page.status)}
                              <div>
                                <h3 className="font-medium text-secondary-900">{page.business_name}</h3>
                                <p className="text-sm text-secondary-600">
                                  {businessTypes.find(t => t.value === page.business_type)?.label}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              {getStatusBadge(page.status)}
                            </div>
                          </div>
                          
                          <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="text-secondary-600">Live URL:</span>
                              <a
                                href={page.live_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="ml-2 text-primary-600 hover:text-primary-700 underline"
                              >
                                {page.live_url.replace('https://', '')}
                              </a>
                            </div>
                            <div>
                              <span className="text-secondary-600">Views:</span>
                              <span className="ml-2 font-medium">{page.views?.toLocaleString() || 0}</span>
                            </div>
                            <div>
                              <span className="text-secondary-600">Conversions:</span>
                              <span className="ml-2 font-medium">{page.conversions || 0}</span>
                            </div>
                          </div>
                          
                          <div className="mt-4 flex items-center justify-between">
                            <div className="text-xs text-secondary-500">
                              Created: {new Date(page.created_at).toLocaleDateString()}
                            </div>
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="secondary"
                                size="sm"
                                onClick={() => window.open(page.live_url, '_blank')}
                              >
                                <EyeIcon className="h-4 w-4 mr-1" />
                                View
                              </Button>
                              <Button
                                variant="secondary"
                                size="sm"
                                onClick={() => {
                                  // Handle edit functionality
                                  toast.success('Edit functionality coming soon');
                                }}
                              >
                                <PencilIcon className="h-4 w-4 mr-1" />
                                Edit
                              </Button>
                              <Button
                                variant="danger"
                                size="sm"
                                onClick={() => {
                                  // Handle delete functionality
                                  toast.success('Delete functionality coming soon');
                                }}
                              >
                                <TrashIcon className="h-4 w-4 mr-1" />
                                Delete
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </Card>
              </TabsContent>
            </Tabs>
          </main>
        </div>
      </div>

      {/* Visual Builder Modal */}
      {showVisualBuilder && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-50">
          <VisualLandingPageBuilder
            businessInfo={businessInfo}
            onSave={handleVisualBuilderSave}
            onClose={() => setShowVisualBuilder(false)}
          />
        </div>
      )}
    </ProtectedRoute>
  );
} 