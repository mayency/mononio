'use client';

import { useEffect, useState } from 'react';
import { useAuthStore } from '@/store/auth';
import { Business } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import ClientOnly from '@/components/auth/ClientOnly';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import {
  SparklesIcon,
  LightBulbIcon,
  CogIcon,
  RocketLaunchIcon,
  ChartBarIcon,
  UserGroupIcon,
  DocumentTextIcon,
  GlobeAltIcon,
  CpuChipIcon,
  CommandLineIcon,
  PlusIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

interface AITool {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
  status: 'available' | 'beta' | 'coming_soon';
  provider: string;
}

const aiTools: AITool[] = [
  {
    id: 'goal_accomplishment',
    name: 'Goal Accomplishment',
    description: 'AI-powered goal setting and achievement tracking',
    icon: RocketLaunchIcon,
    color: 'bg-primary-100 text-primary-600',
    status: 'available',
    provider: 'openai',
  },
  {
    id: 'content_optimization',
    name: 'Content Optimization',
    description: 'Optimize content for different platforms and audiences',
    icon: DocumentTextIcon,
    color: 'bg-success-100 text-success-600',
    status: 'available',
    provider: 'openai',
  },
  {
    id: 'market_analysis',
    name: 'Market Analysis',
    description: 'AI-driven market research and competitive analysis',
    icon: ChartBarIcon,
    color: 'bg-warning-100 text-warning-600',
    status: 'available',
    provider: 'anthropic',
  },
  {
    id: 'customer_insights',
    name: 'Customer Insights',
    description: 'Deep analysis of customer behavior and preferences',
    icon: UserGroupIcon,
    color: 'bg-secondary-100 text-secondary-600',
    status: 'beta',
    provider: 'openai',
  },
  {
    id: 'automation_workflows',
    name: 'Automation Workflows',
    description: 'Create automated business processes and workflows',
    icon: CogIcon,
    color: 'bg-danger-100 text-danger-600',
    status: 'beta',
    provider: 'openai',
  },
  {
    id: 'predictive_analytics',
    name: 'Predictive Analytics',
    description: 'Forecast trends and predict business outcomes',
    icon: CpuChipIcon,
    color: 'bg-purple-100 text-purple-600',
    status: 'coming_soon',
    provider: 'anthropic',
  },
];

interface Workflow {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'paused' | 'draft';
  lastRun: string;
  nextRun: string;
  successRate: number;
}

export default function AIToolsPage() {
  const { isAuthenticated } = useAuthStore();
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null);
  const [goal, setGoal] = useState('');
  const [selectedTool, setSelectedTool] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [aiProvider, setAiProvider] = useState('openai');
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [showWorkflowModal, setShowWorkflowModal] = useState(false);
  const [selectedGoalOption, setSelectedGoalOption] = useState<string>('custom');
  const [showCustomInput, setShowCustomInput] = useState(false);
  const [showToolModal, setShowToolModal] = useState(false);
  const [activeTool, setActiveTool] = useState<AITool | null>(null);
  const [toolInput, setToolInput] = useState('');
  const [toolLoading, setToolLoading] = useState(false);

  // Pre-defined goal options
  const goalOptions = [
    {
      id: 'increase_traffic',
      title: 'Increase Website Traffic',
      description: 'Boost website visitors by 50% in 3 months',
      category: 'Marketing',
      icon: '🚀'
    },
    {
      id: 'improve_conversions',
      title: 'Improve Conversion Rate',
      description: 'Increase sales conversions by 25% through optimization',
      category: 'Sales',
      icon: '📈'
    },
    {
      id: 'reduce_costs',
      title: 'Reduce Operational Costs',
      description: 'Cut business expenses by 20% while maintaining quality',
      category: 'Finance',
      icon: '💰'
    },
    {
      id: 'expand_market',
      title: 'Expand to New Markets',
      description: 'Enter 2 new geographic markets within 6 months',
      category: 'Growth',
      icon: '🌍'
    },
    {
      id: 'improve_customer_satisfaction',
      title: 'Improve Customer Satisfaction',
      description: 'Achieve 95% customer satisfaction score',
      category: 'Customer Service',
      icon: '😊'
    },
    {
      id: 'launch_product',
      title: 'Launch New Product/Service',
      description: 'Successfully launch a new offering within 4 months',
      category: 'Product',
      icon: '🆕'
    },
    {
      id: 'build_team',
      title: 'Build High-Performing Team',
      description: 'Hire and train 5 key team members in 6 months',
      category: 'HR',
      icon: '👥'
    },
    {
      id: 'optimize_processes',
      title: 'Optimize Business Processes',
      description: 'Streamline operations to save 15 hours per week',
      category: 'Operations',
      icon: '⚡'
    },
    {
      id: 'increase_revenue',
      title: 'Increase Revenue',
      description: 'Grow revenue by 40% through strategic initiatives',
      category: 'Finance',
      icon: '💎'
    },
    {
      id: 'build_brand',
      title: 'Build Strong Brand Presence',
      description: 'Establish brand authority in your industry',
      category: 'Marketing',
      icon: '🏆'
    },
    {
      id: 'custom',
      title: 'Custom Goal',
      description: 'Define your own specific business goal',
      category: 'Custom',
      icon: '✏️'
    }
  ];

  useEffect(() => {
    if (isAuthenticated) {
      fetchData();
    }
  }, [isAuthenticated]);

  const fetchData = async () => {
    try {
      const businessesData = await apiClient.getBusinesses();
      setBusinesses(businessesData);
      if (businessesData.length > 0) {
        setSelectedBusiness(businessesData[0]);
      }
      
      // Mock workflows data
      setWorkflows([
        {
          id: '1',
          name: 'Lead Nurturing',
          description: 'Automated email sequences for lead nurturing',
          status: 'active',
          lastRun: '2024-01-15T10:30:00Z',
          nextRun: '2024-01-16T10:30:00Z',
          successRate: 85,
        },
        {
          id: '2',
          name: 'Content Publishing',
          description: 'Automated social media content publishing',
          status: 'active',
          lastRun: '2024-01-15T09:00:00Z',
          nextRun: '2024-01-16T09:00:00Z',
          successRate: 92,
        },
        {
          id: '3',
          name: 'Expense Tracking',
          description: 'Automated expense categorization and reporting',
          status: 'paused',
          lastRun: '2024-01-14T15:00:00Z',
          nextRun: '2024-01-17T15:00:00Z',
          successRate: 78,
        },
      ]);
    } catch (error) {
      console.error('Failed to fetch data:', error);
      toast.error('Failed to load AI tools data');
    }
  };

  const handleAccomplishGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!goal.trim()) {
      toast.error('Please enter a goal');
      return;
    }
    
    setLoading(true);
    
    try {
      const response = await apiClient.accomplishGoal(goal, aiProvider);
      toast.success('Goal accomplished successfully!');
      setGoal('');
      
      // Show result in a more detailed way
      console.log('Goal accomplishment result:', response);
    } catch (error: any) {
      toast.error(error.message || 'Failed to accomplish goal');
    } finally {
      setLoading(false);
    }
  };

  const handleToolSelection = (toolId: string) => {
    setSelectedTool(toolId);
  };

  const handleUseTool = (tool: AITool, e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent triggering the card click
    setActiveTool(tool);
    setShowToolModal(true);
    setToolInput('');
  };

  const handleToolSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTool || !toolInput.trim()) {
      toast.error('Please enter a prompt for the tool');
      return;
    }

    setToolLoading(true);
    try {
      let response;
      
      switch (activeTool.id) {
        case 'content_optimization':
          response = await apiClient.generateContent({
            business_id: selectedBusiness?.id?.toString() || '1',
            content_type: 'text',
            business_context: {
              name: selectedBusiness?.name || 'Your Business',
              industry: selectedBusiness?.industry || 'General',
              target_audience: selectedBusiness?.target_audience || 'General',
              brand_voice: selectedBusiness?.brand_voice || 'Professional'
            },
            platform: 'general',
            requirements: {
              prompt: toolInput,
              tone: 'professional',
              length: 'medium'
            }
          });
          break;
          
        case 'market_analysis':
          response = await apiClient.conductMarketResearch({
            research_type: 'competitor_analysis',
            business_context: {
              name: selectedBusiness?.name || 'Your Business',
              industry: selectedBusiness?.industry || 'General',
              location: selectedBusiness?.location || 'Global',
              target_audience: selectedBusiness?.target_audience || 'General',
              brand_voice: selectedBusiness?.brand_voice || 'Professional'
            },
            industry: selectedBusiness?.industry || 'General',
            location: selectedBusiness?.location || 'Global'
          });
          break;
          
        case 'customer_insights':
          response = await apiClient.getCustomerInsights(selectedBusiness?.id?.toString() || '1');
          break;
          
        case 'automation_workflows':
          response = await apiClient.accomplishGoal(toolInput, aiProvider);
          break;
          
        default:
          response = await apiClient.accomplishGoal(toolInput, aiProvider);
      }

      toast.success(`${activeTool.name} completed successfully!`);
      setShowToolModal(false);
      setToolInput('');
      console.log('Tool result:', response);
    } catch (error: any) {
      toast.error(error.message || `Failed to use ${activeTool.name}`);
    } finally {
      setToolLoading(false);
    }
  };

  const handleGoalOptionSelect = (optionId: string) => {
    setSelectedGoalOption(optionId);
    if (optionId === 'custom') {
      setShowCustomInput(true);
      setGoal('');
    } else {
      setShowCustomInput(false);
      const selectedOption = goalOptions.find(option => option.id === optionId);
      if (selectedOption) {
        setGoal(selectedOption.description);
      }
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      available: { label: 'Available', className: 'badge-success' },
      beta: { label: 'Beta', className: 'badge-warning' },
      coming_soon: { label: 'Coming Soon', className: 'badge-secondary' },
    };
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.available;
    return <span className={`badge ${config.className}`}>{config.label}</span>;
  };

  const getWorkflowStatusBadge = (status: string) => {
    const statusConfig = {
      active: { label: 'Active', className: 'badge-success' },
      paused: { label: 'Paused', className: 'badge-warning' },
      draft: { label: 'Draft', className: 'badge-secondary' },
    };
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.draft;
    return <span className={`badge ${config.className}`}>{config.label}</span>;
  };

  return (
    <ClientOnly fallback={
      <div className="flex h-screen bg-gray-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    }>
      <ProtectedRoute>
        <div className="flex h-screen bg-gray-50">
          <Sidebar />
          <main className="flex-1 overflow-y-auto">
            <div className="container mx-auto px-6 py-8">
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-secondary-900 mb-2">
                  AI Tools
                </h1>
                <p className="text-secondary-600">
                  Leverage AI-powered tools to optimize your business operations
                </p>
              </div>

              {/* AI Goal Accomplishment Section */}
              <div className="card mb-8">
                <div className="card-header">
                  <div className="flex items-center space-x-3">
                    <div className="h-10 w-10 bg-primary-100 rounded-lg flex items-center justify-center">
                      <RocketLaunchIcon className="h-5 w-5 text-primary-600" />
                    </div>
                    <div>
                      <h2 className="card-title">AI Goal Accomplishment</h2>
                      <p className="card-subtitle">Set and achieve business goals with AI assistance</p>
                    </div>
                  </div>
                </div>

                <div className="card-body">
                  <form onSubmit={handleAccomplishGoal} className="space-y-6">
                    {/* Goal Selection */}
                    <div>
                      <label className="block text-sm font-medium text-secondary-700 mb-3">
                        What would you like to accomplish?
                      </label>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        {goalOptions.map((option) => (
                          <button
                            key={option.id}
                            type="button"
                            onClick={() => handleGoalOptionSelect(option.id)}
                            className={`p-4 border rounded-lg text-left transition-all ${
                              selectedGoalOption === option.id
                                ? 'border-primary-500 bg-primary-50'
                                : 'border-secondary-200 hover:border-secondary-300'
                            }`}
                          >
                            <div className="flex items-center space-x-3">
                              <span className="text-2xl">{option.icon}</span>
                              <div className="flex-1">
                                <p className="font-medium text-secondary-900">{option.title}</p>
                                <p className="text-sm text-secondary-600">{option.description}</p>
                                <span className="inline-block px-2 py-1 text-xs bg-secondary-100 text-secondary-700 rounded mt-1">
                                  {option.category}
                                </span>
                              </div>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Custom Goal Input */}
                    {selectedGoalOption === 'custom' && (
                      <div>
                        <label className="block text-sm font-medium text-secondary-700 mb-2">
                          Describe your custom goal
                        </label>
                        <textarea
                          value={goal}
                          onChange={(e) => setGoal(e.target.value)}
                          placeholder="e.g., Increase monthly recurring revenue by 30% through improved customer retention and upselling strategies"
                          className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
                          rows={3}
                          required
                        />
                      </div>
                    )}

                    {/* AI Provider Selection */}
                    <div>
                      <label className="block text-sm font-medium text-secondary-700 mb-2">
                        AI Provider
                      </label>
                      <select
                        value={aiProvider}
                        onChange={(e) => setAiProvider(e.target.value)}
                        className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
                      >
                        <option value="openai">OpenAI GPT-4</option>
                        <option value="anthropic">Anthropic Claude</option>
                        <option value="google">Google Gemini</option>
                      </select>
                    </div>

                    <Button type="submit" loading={loading} className="w-full">
                      Accomplish Goal with AI
                    </Button>
                  </form>
                </div>
              </div>

              {/* Available AI Tools */}
              <div className="card mb-8">
                <div className="card-header">
                  <h2 className="card-title">Available AI Tools</h2>
                  <p className="card-subtitle">Select a tool to get started</p>
                </div>

                <div className="card-body">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {aiTools.map((tool) => (
                      <div
                        key={tool.id}
                        className="border border-secondary-200 rounded-lg p-6 hover:shadow-md transition-shadow"
                      >
                        <div className="flex items-center space-x-3 mb-4">
                          <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${tool.color}`}>
                            <tool.icon className="h-5 w-5" />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-secondary-900">{tool.name}</h3>
                            <p className="text-sm text-secondary-600">{tool.description}</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between mb-4">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            tool.status === 'available' ? 'bg-success-100 text-success-800' :
                            tool.status === 'beta' ? 'bg-warning-100 text-warning-800' :
                            'bg-secondary-100 text-secondary-800'
                          }`}>
                            {tool.status === 'available' ? 'Available' :
                             tool.status === 'beta' ? 'Beta' : 'Coming Soon'}
                          </span>
                          <span className="text-xs text-secondary-500">{tool.provider}</span>
                        </div>

                        {tool.status === 'available' && (
                          <Button
                            onClick={(e) => handleUseTool(tool, e)}
                            className="w-full"
                            size="sm"
                          >
                            Use Tool
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Workflows Section */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="card">
                  <div className="card-header">
                    <div className="flex items-center justify-between">
                      <h3 className="card-title">Active Workflows</h3>
                      <Button
                        onClick={() => setShowWorkflowModal(true)}
                        size="sm"
                        variant="secondary"
                      >
                        <PlusIcon className="h-4 w-4 mr-2" />
                        Create Workflow
                      </Button>
                    </div>
                  </div>

                  <div className="card-body">
                    {workflows.length === 0 ? (
                      <div className="text-center py-8">
                        <CogIcon className="h-12 w-12 text-secondary-400 mx-auto mb-4" />
                        <p className="text-secondary-600">No workflows created yet</p>
                        <Button
                          onClick={() => setShowWorkflowModal(true)}
                          variant="secondary"
                          size="sm"
                          className="mt-4"
                        >
                          Create Your First Workflow
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {workflows.map((workflow) => (
                          <div key={workflow.id} className="border border-secondary-200 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-medium text-secondary-900">{workflow.name}</h4>
                              {getWorkflowStatusBadge(workflow.status)}
                            </div>
                            <p className="text-sm text-secondary-600 mb-3">{workflow.description}</p>
                            <div className="flex items-center justify-between text-xs text-secondary-500">
                              <span>Success Rate: {workflow.successRate}%</span>
                              <span>Next Run: {workflow.nextRun}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">System Alerts</h3>
                      <p className="card-subtitle">Recent system notifications</p>
                    </div>
                    <div className="card-body space-y-4">
                      <div className="p-4 bg-success-50 border border-success-200 rounded-lg">
                        <div className="flex items-start space-x-3">
                          <SparklesIcon className="h-5 w-5 text-success-600 mt-0.5" />
                          <div>
                            <p className="text-sm font-medium text-success-900">AI Optimization Complete</p>
                            <p className="text-sm text-success-700 mt-1">
                              Your content has been optimized for better engagement rates.
                            </p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="p-4 bg-info-50 border border-info-200 rounded-lg">
                        <div className="flex items-start space-x-3">
                          <LightBulbIcon className="h-5 w-5 text-info-600 mt-0.5" />
                          <div>
                            <p className="text-sm font-medium text-info-900">New Feature Available</p>
                            <p className="text-sm text-info-700 mt-1">
                              Advanced analytics dashboard is now available for your account.
                            </p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="p-4 bg-warning-50 border border-warning-200 rounded-lg">
                        <div className="flex items-start space-x-3">
                          <UserGroupIcon className="h-5 w-5 text-warning-600 mt-0.5" />
                          <div>
                            <p className="text-sm font-medium text-warning-900">Customer Retention</p>
                            <p className="text-sm text-warning-700 mt-1">
                              Customer churn rate has increased by 15%. Consider implementing a loyalty program.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">AI Recommendations</h3>
                      <p className="card-subtitle">Actionable recommendations from AI analysis</p>
                    </div>
                    <div className="card-body space-y-3">
                      <div className="flex items-center space-x-3 p-3 border border-secondary-200 rounded-lg">
                        <div className="h-8 w-8 bg-primary-100 rounded-full flex items-center justify-center">
                          <span className="text-xs font-medium text-primary-700">1</span>
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium text-secondary-900">Optimize Landing Pages</p>
                          <p className="text-xs text-secondary-500">Improve conversion rates by 30%</p>
                        </div>
                        <Button size="sm" variant="primary">Implement</Button>
                      </div>
                      
                      <div className="flex items-center space-x-3 p-3 border border-secondary-200 rounded-lg">
                        <div className="h-8 w-8 bg-success-100 rounded-full flex items-center justify-center">
                          <span className="text-xs font-medium text-success-700">2</span>
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium text-secondary-900">Launch Email Campaign</p>
                          <p className="text-xs text-secondary-500">Target existing customers</p>
                        </div>
                        <Button size="sm" variant="success">Launch</Button>
                      </div>
                      
                      <div className="flex items-center space-x-3 p-3 border border-secondary-200 rounded-lg">
                        <div className="h-8 w-8 bg-warning-100 rounded-full flex items-center justify-center">
                          <span className="text-xs font-medium text-warning-700">3</span>
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium text-secondary-900">Review Pricing Strategy</p>
                          <p className="text-xs text-secondary-500">Increase profit margins</p>
                        </div>
                        <Button size="sm" variant="warning">Review</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>

        {/* Create Workflow Modal */}
        {showWorkflowModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
              <div className="p-6">
                <h2 className="text-xl font-semibold text-secondary-900 mb-4">
                  Create New Workflow
                </h2>
                <div className="space-y-4">
                  <Input
                    label="Workflow Name"
                    placeholder="e.g., Lead Nurturing Automation"
                  />
                  <Input
                    label="Description"
                    placeholder="Describe what this workflow does"
                  />
                  <div>
                    <label className="block text-sm font-medium text-secondary-700 mb-1">
                      Trigger
                    </label>
                    <select className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500">
                      <option>New Lead Added</option>
                      <option>Purchase Completed</option>
                      <option>Email Opened</option>
                      <option>Website Visit</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-secondary-700 mb-1">
                      Action
                    </label>
                    <select className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500">
                      <option>Send Email</option>
                      <option>Add to Campaign</option>
                      <option>Update Status</option>
                      <option>Create Task</option>
                    </select>
                  </div>
                  <div className="flex space-x-3 pt-4">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setShowWorkflowModal(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button className="flex-1">
                      Create Workflow
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tool Modal */}
        {showToolModal && activeTool && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${activeTool.color}`}>
                      <activeTool.icon className="h-5 w-5" />
                    </div>
                    <div>
                      <h2 className="text-xl font-semibold text-secondary-900">
                        {activeTool.name}
                      </h2>
                      <p className="text-sm text-secondary-600">{activeTool.description}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowToolModal(false)}
                    className="text-secondary-400 hover:text-secondary-600"
                  >
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>

                <form onSubmit={handleToolSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-secondary-700 mb-2">
                      {activeTool.id === 'content_optimization' && 'What content would you like to optimize?'}
                      {activeTool.id === 'market_analysis' && 'What market aspect would you like to analyze?'}
                      {activeTool.id === 'customer_insights' && 'What customer behavior would you like to understand?'}
                      {activeTool.id === 'automation_workflows' && 'What process would you like to automate?'}
                      {!['content_optimization', 'market_analysis', 'customer_insights', 'automation_workflows'].includes(activeTool.id) && 'What would you like to accomplish?'}
                    </label>
                    <textarea
                      value={toolInput}
                      onChange={(e) => setToolInput(e.target.value)}
                      placeholder={
                        activeTool.id === 'content_optimization' ? 'e.g., Optimize this landing page copy for better conversions...' :
                        activeTool.id === 'market_analysis' ? 'e.g., Analyze competitors in the SaaS industry...' :
                        activeTool.id === 'customer_insights' ? 'e.g., Understand customer churn patterns...' :
                        activeTool.id === 'automation_workflows' ? 'e.g., Automate email follow-up sequence...' :
                        'Describe what you want to accomplish...'
                      }
                      className="block w-full rounded-lg border border-secondary-300 px-3 py-2 text-sm focus:border-primary-500 focus:outline-none focus:ring-1 focus:ring-primary-500"
                      rows={4}
                      required
                    />
                  </div>

                  <div className="flex space-x-3 pt-4">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setShowToolModal(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      loading={toolLoading}
                      className="flex-1"
                    >
                      Use {activeTool.name}
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </ProtectedRoute>
    </ClientOnly>
  );
} 