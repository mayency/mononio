'use client';

import { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import Input from '@/components/ui/Input';
import { 
  MagnifyingGlassIcon, 
  FunnelIcon,
  SparklesIcon,
  CheckCircleIcon,
  XCircleIcon,
  ClockIcon,
  ExclamationTriangleIcon,
  ArrowTopRightOnSquareIcon,
  Cog6ToothIcon
} from '@heroicons/react/24/outline';

interface Service {
  id: string;
  name: string;
  description: string;
  category: 'social_media' | 'advertising' | 'communication' | 'analytics' | 'payments' | 'automation';
  icon: string;
  status: 'connected' | 'disconnected' | 'pending' | 'error';
  features: string[];
  pricing: {
    type: 'free' | 'freemium' | 'paid' | 'enterprise';
    price?: string;
    billing?: string;
  };
  setup_required: boolean;
  api_key_required: boolean;
  oauth_required: boolean;
  documentation_url: string;
  support_url: string;
  connection_date?: string;
  last_sync?: string;
  monthly_requests?: number;
  request_limit?: number;
}

const MOCK_SERVICES: Service[] = [
  {
    id: 'facebook',
    name: 'Facebook Business',
    description: 'Connect your Facebook Business account to create and manage ad campaigns, analyze performance, and engage with your audience.',
    category: 'social_media',
    icon: '📘',
    status: 'connected',
    features: ['Ad Campaign Management', 'Audience Insights', 'Post Scheduling', 'Performance Analytics'],
    pricing: { type: 'free' },
    setup_required: true,
    api_key_required: false,
    oauth_required: true,
    documentation_url: 'https://developers.facebook.com/docs/marketing-api',
    support_url: 'https://business.facebook.com/support',
    connection_date: '2024-01-15',
    last_sync: '2024-01-20T10:30:00Z',
    monthly_requests: 1250,
    request_limit: 5000
  },
  {
    id: 'google_ads',
    name: 'Google Ads',
    description: 'Integrate with Google Ads to create, manage, and optimize your advertising campaigns across Google Search, Display, and YouTube.',
    category: 'advertising',
    icon: '🔍',
    status: 'connected',
    features: ['Campaign Management', 'Keyword Research', 'Performance Tracking', 'Budget Optimization'],
    pricing: { type: 'free' },
    setup_required: true,
    api_key_required: true,
    oauth_required: true,
    documentation_url: 'https://developers.google.com/google-ads/api/docs',
    support_url: 'https://support.google.com/google-ads',
    connection_date: '2024-01-10',
    last_sync: '2024-01-20T09:15:00Z',
    monthly_requests: 890,
    request_limit: 10000
  },
  {
    id: 'instagram',
    name: 'Instagram Business',
    description: 'Manage your Instagram business profile, schedule posts, analyze engagement, and run Instagram ad campaigns.',
    category: 'social_media',
    icon: '📸',
    status: 'pending',
    features: ['Content Publishing', 'Story Management', 'Engagement Analytics', 'Influencer Insights'],
    pricing: { type: 'free' },
    setup_required: true,
    api_key_required: false,
    oauth_required: true,
    documentation_url: 'https://developers.facebook.com/docs/instagram-api',
    support_url: 'https://business.instagram.com/support'
  },
  {
    id: 'twitter',
    name: 'Twitter Ads',
    description: 'Connect Twitter Ads to create promoted tweets, analyze engagement, and reach your target audience on Twitter.',
    category: 'advertising',
    icon: '🐦',
    status: 'error',
    features: ['Promoted Tweets', 'Audience Targeting', 'Tweet Analytics', 'Trend Analysis'],
    pricing: { type: 'free' },
    setup_required: true,
    api_key_required: true,
    oauth_required: true,
    documentation_url: 'https://developer.twitter.com/en/docs/twitter-ads-api',
    support_url: 'https://business.twitter.com/en/support'
  },
  {
    id: 'stripe',
    name: 'Stripe',
    description: 'Process payments, manage subscriptions, and handle billing for your business with Stripe\'s powerful payment infrastructure.',
    category: 'payments',
    icon: '💳',
    status: 'disconnected',
    features: ['Payment Processing', 'Subscription Management', 'Invoice Generation', 'Financial Reports'],
    pricing: { type: 'paid', price: '2.9% + $0.30', billing: 'per transaction' },
    setup_required: true,
    api_key_required: true,
    oauth_required: false,
    documentation_url: 'https://stripe.com/docs/api',
    support_url: 'https://support.stripe.com'
  },
  {
    id: 'mailchimp',
    name: 'Mailchimp',
    description: 'Manage email campaigns, automate marketing workflows, and analyze customer engagement with Mailchimp.',
    category: 'communication',
    icon: '📧',
    status: 'disconnected',
    features: ['Email Campaigns', 'Marketing Automation', 'Audience Segmentation', 'A/B Testing'],
    pricing: { type: 'freemium', price: 'Free up to 2,000 contacts' },
    setup_required: true,
    api_key_required: true,
    oauth_required: true,
    documentation_url: 'https://mailchimp.com/developer/marketing/',
    support_url: 'https://mailchimp.com/support'
  },
  {
    id: 'shopify',
    name: 'Shopify',
    description: 'Connect your Shopify store to sync products, manage inventory, and analyze sales performance.',
    category: 'automation',
    icon: '🛍️',
    status: 'disconnected',
    features: ['Product Sync', 'Inventory Management', 'Order Processing', 'Sales Analytics'],
    pricing: { type: 'paid', price: '$29/month', billing: 'basic plan' },
    setup_required: true,
    api_key_required: true,
    oauth_required: true,
    documentation_url: 'https://shopify.dev/api',
    support_url: 'https://help.shopify.com'
  },
  {
    id: 'zapier',
    name: 'Zapier',
    description: 'Automate workflows between LaunchMate and 5,000+ apps without coding using Zapier\'s integration platform.',
    category: 'automation',
    icon: '⚡',
    status: 'disconnected',
    features: ['Workflow Automation', 'Multi-App Integration', 'Trigger Actions', 'Data Synchronization'],
    pricing: { type: 'freemium', price: 'Free for 100 tasks/month' },
    setup_required: true,
    api_key_required: true,
    oauth_required: true,
    documentation_url: 'https://zapier.com/developer',
    support_url: 'https://zapier.com/help'
  },
  {
    id: 'hubspot',
    name: 'HubSpot',
    description: 'Sync your CRM data, manage customer relationships, and track sales pipeline with HubSpot integration.',
    category: 'analytics',
    icon: '📊',
    status: 'disconnected',
    features: ['CRM Integration', 'Lead Management', 'Sales Pipeline', 'Customer Analytics'],
    pricing: { type: 'freemium', price: 'Free CRM included' },
    setup_required: true,
    api_key_required: true,
    oauth_required: true,
    documentation_url: 'https://developers.hubspot.com/docs/api/overview',
    support_url: 'https://knowledge.hubspot.com'
  },
  {
    id: 'slack',
    name: 'Slack',
    description: 'Get real-time notifications, collaborate with your team, and manage LaunchMate activities directly in Slack.',
    category: 'communication',
    icon: '💬',
    status: 'disconnected',
    features: ['Real-time Notifications', 'Team Collaboration', 'Bot Commands', 'Workflow Integration'],
    pricing: { type: 'freemium', price: 'Free for small teams' },
    setup_required: true,
    api_key_required: false,
    oauth_required: true,
    documentation_url: 'https://api.slack.com/docs',
    support_url: 'https://slack.com/help'
  }
];

const CATEGORY_LABELS = {
  social_media: 'Social Media',
  advertising: 'Advertising',
  communication: 'Communication',
  analytics: 'Analytics',
  payments: 'Payments',
  automation: 'Automation'
};

export default function MarketplacePage() {
  const [services, setServices] = useState<Service[]>(MOCK_SERVICES);
  const [filteredServices, setFilteredServices] = useState<Service[]>(MOCK_SERVICES);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    filterServices();
  }, [searchTerm, selectedCategory, selectedStatus, services]);

  const filterServices = () => {
    let filtered = services;

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(service => 
        service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        service.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        service.features.some(feature => feature.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    // Category filter
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(service => service.category === selectedCategory);
    }

    // Status filter
    if (selectedStatus !== 'all') {
      filtered = filtered.filter(service => service.status === selectedStatus);
    }

    setFilteredServices(filtered);
  };

  const handleConnect = async (serviceId: string) => {
    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setServices(prev => prev.map(service => 
        service.id === serviceId 
          ? { ...service, status: 'pending' as const }
          : service
      ));
      
      // Simulate connection process
      setTimeout(() => {
        setServices(prev => prev.map(service => 
          service.id === serviceId 
            ? { 
                ...service, 
                status: 'connected' as const,
                connection_date: new Date().toISOString().split('T')[0],
                last_sync: new Date().toISOString()
              }
            : service
        ));
      }, 2000);
    } catch (error) {
      console.error('Connection error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDisconnect = async (serviceId: string) => {
    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setServices(prev => prev.map(service => 
        service.id === serviceId 
          ? { 
              ...service, 
              status: 'disconnected' as const,
              connection_date: undefined,
              last_sync: undefined,
              monthly_requests: undefined
            }
          : service
      ));
    } catch (error) {
      console.error('Disconnection error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusBadge = (status: Service['status']) => {
    const statusConfig = {
      connected: { color: 'bg-green-100 text-green-800', icon: CheckCircleIcon, text: 'Connected' },
      disconnected: { color: 'bg-gray-100 text-gray-800', icon: XCircleIcon, text: 'Disconnected' },
      pending: { color: 'bg-yellow-100 text-yellow-800', icon: ClockIcon, text: 'Pending' },
      error: { color: 'bg-red-100 text-red-800', icon: ExclamationTriangleIcon, text: 'Error' }
    };

    const config = statusConfig[status];
    const Icon = config.icon;

    return (
      <Badge className={`${config.color} flex items-center gap-1`}>
        <Icon className="h-3 w-3" />
        {config.text}
      </Badge>
    );
  };

  const getPricingBadge = (pricing: Service['pricing']) => {
    const colors = {
      free: 'bg-green-100 text-green-800',
      freemium: 'bg-blue-100 text-blue-800',
      paid: 'bg-purple-100 text-purple-800',
      enterprise: 'bg-gray-100 text-gray-800'
    };

    return (
      <Badge className={colors[pricing.type]}>
        {pricing.type === 'free' && 'Free'}
        {pricing.type === 'freemium' && 'Freemium'}
        {pricing.type === 'paid' && pricing.price}
        {pricing.type === 'enterprise' && 'Enterprise'}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                <SparklesIcon className="h-7 w-7 text-blue-600" />
                Services Marketplace
              </h1>
              <p className="text-gray-600 mt-1">
                Discover and connect third-party services to enhance your business automation
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-500">
                {filteredServices.filter(s => s.status === 'connected').length} connected
              </span>
              <span className="text-sm text-gray-500">•</span>
              <span className="text-sm text-gray-500">
                {filteredServices.length} total services
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          {/* Search */}
          <div className="flex-1 relative">
            <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search services..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Category Filter */}
          <div className="relative">
            <FunnelIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="pl-10 pr-10 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="all">All Categories</option>
              {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="relative">
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="pl-4 pr-10 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="all">All Status</option>
              <option value="connected">Connected</option>
              <option value="disconnected">Disconnected</option>
              <option value="pending">Pending</option>
              <option value="error">Error</option>
            </select>
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredServices.map((service) => (
            <Card key={service.id} className="p-6 hover:shadow-lg transition-shadow">
              {/* Service Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="text-2xl">{service.icon}</div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{service.name}</h3>
                    <p className="text-sm text-gray-500">{CATEGORY_LABELS[service.category]}</p>
                  </div>
                </div>
                {getStatusBadge(service.status)}
              </div>

              {/* Description */}
              <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                {service.description}
              </p>

              {/* Features */}
              <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Key Features</h4>
                <div className="flex flex-wrap gap-1">
                  {service.features.slice(0, 3).map((feature, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                  {service.features.length > 3 && (
                    <Badge variant="secondary" className="text-xs">
                      +{service.features.length - 3} more
                    </Badge>
                  )}
                </div>
              </div>

              {/* Pricing */}
              <div className="mb-4">
                {getPricingBadge(service.pricing)}
              </div>

              {/* Connection Stats */}
              {service.status === 'connected' && (
                <div className="mb-4 p-3 bg-green-50 rounded-lg">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Monthly Requests</span>
                    <span className="font-medium">{service.monthly_requests}/{service.request_limit}</span>
                  </div>
                  <div className="flex justify-between text-sm mt-1">
                    <span className="text-gray-600">Last Sync</span>
                    <span className="font-medium">
                      {service.last_sync ? new Date(service.last_sync).toLocaleDateString() : 'Never'}
                    </span>
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-2 mt-4">
                {service.status === 'connected' ? (
                  <>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleDisconnect(service.id)}
                      disabled={isLoading}
                      className="flex-1"
                    >
                      Disconnect
                    </Button>
                    <Button 
                      variant="secondary" 
                      size="sm"
                      className="flex items-center gap-1"
                    >
                      <Cog6ToothIcon className="h-4 w-4" />
                      Settings
                    </Button>
                  </>
                ) : (
                  <>
                    <Button 
                      onClick={() => handleConnect(service.id)}
                      disabled={isLoading || service.status === 'pending'}
                      className="flex-1"
                      size="sm"
                    >
                      {service.status === 'pending' ? 'Connecting...' : 'Connect'}
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="flex items-center gap-1"
                    >
                      <ArrowTopRightOnSquareIcon className="h-4 w-4" />
                      Learn More
                    </Button>
                  </>
                )}
              </div>

              {/* Requirements */}
              <div className="mt-4 pt-4 border-t text-xs text-gray-500">
                <div className="flex flex-wrap gap-2">
                  {service.setup_required && (
                    <span className="flex items-center gap-1">
                      <Cog6ToothIcon className="h-3 w-3" />
                      Setup Required
                    </span>
                  )}
                  {service.api_key_required && (
                    <span className="flex items-center gap-1">
                      🔑 API Key
                    </span>
                  )}
                  {service.oauth_required && (
                    <span className="flex items-center gap-1">
                      🔒 OAuth
                    </span>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {filteredServices.length === 0 && (
          <div className="text-center py-12">
            <SparklesIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No services found</h3>
            <p className="text-gray-500">Try adjusting your search or filter criteria</p>
          </div>
        )}
      </div>
    </div>
  );
} 