'use client';

import { useEffect, useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth';
import { Business } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import ClientOnly from '@/components/auth/ClientOnly';
import {
  Cog6ToothIcon,
  KeyIcon,
  EyeIcon,
  EyeSlashIcon,
  ShieldCheckIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  PlusIcon,
  TrashIcon,
  ArrowLeftIcon,
  BuildingOfficeIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { getErrorMessage } from '@/lib/getErrorMessage';

interface APIKey {
  id: string;
  platform: string;
  account_name: string;
  api_key?: string;
  api_secret?: string;
  access_token?: string;
  refresh_token?: string;
  client_id?: string;
  client_secret?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface PlatformConfig {
  name: string;
  icon: string;
  description: string;
  required_fields: string[];
  optional_fields: string[];
  help_url: string;
}

const PLATFORM_CONFIGS: Record<string, PlatformConfig> = {
  facebook: {
    name: 'Facebook Ads',
    icon: '📘',
    description: 'Facebook Ads API for campaign management',
    required_fields: ['access_token'],
    optional_fields: ['client_id', 'client_secret'],
    help_url: 'https://developers.facebook.com/docs/marketing-api/'
  },
  google: {
    name: 'Google Ads',
    icon: '🔍',
    description: 'Google Ads API for campaign management',
    required_fields: ['client_id', 'client_secret', 'refresh_token'],
    optional_fields: ['developer_token'],
    help_url: 'https://developers.google.com/google-ads/api/docs/start'
  },
  tiktok: {
    name: 'TikTok Ads',
    icon: '🎵',
    description: 'TikTok Ads API for campaign management',
    required_fields: ['access_token'],
    optional_fields: ['app_id', 'app_secret'],
    help_url: 'https://ads.tiktok.com/marketing_api/docs'
  },
  linkedin: {
    name: 'LinkedIn Ads',
    icon: '💼',
    description: 'LinkedIn Ads API for campaign management',
    required_fields: ['access_token'],
    optional_fields: ['client_id', 'client_secret'],
    help_url: 'https://developer.linkedin.com/docs/ads-api'
  },
  twitter: {
    name: 'Twitter Ads',
    icon: '🐦',
    description: 'Twitter Ads API for campaign management',
    required_fields: ['api_key', 'api_secret', 'access_token', 'access_token_secret'],
    optional_fields: ['bearer_token'],
    help_url: 'https://developer.twitter.com/en/docs/ads-api'
  },
  youtube: {
    name: 'YouTube Ads',
    icon: '📺',
    description: 'YouTube Ads API for campaign management',
    required_fields: ['client_id', 'client_secret', 'refresh_token'],
    optional_fields: ['channel_id'],
    help_url: 'https://developers.google.com/youtube/partner/guides'
  }
};

export default function SettingsPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { isAuthenticated, isLoading } = useAuthStore();
  const [business, setBusiness] = useState<Business | null>(null);
  const [apiKeys, setApiKeys] = useState<APIKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});
  const [selectedPlatform, setSelectedPlatform] = useState<string>('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState<Partial<APIKey>>({});

  const businessId = searchParams.get('businessId');

  useEffect(() => {
    if (isAuthenticated && !isLoading && businessId) {
      fetchData();
    }
  }, [isAuthenticated, isLoading, businessId]);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch business details
      const businessData = await apiClient.getBusiness(parseInt(businessId!));
      setBusiness(businessData);

      // Fetch API keys
      await fetchAPIKeys();

    } catch (error) {
      console.error('Failed to fetch settings data:', error);
      toast.error('Failed to load settings');
    } finally {
      setLoading(false);
    }
  };

  const fetchAPIKeys = async () => {
    try {
      // This would be implemented in the backend
      const response = await apiClient.getAPIKeys(businessId!);
      setApiKeys(response.api_keys || []);
    } catch (error) {
      console.error('Failed to fetch API keys:', error);
    }
  };

  const handleAddAPIKey = async () => {
    if (!selectedPlatform || !formData.account_name) {
      toast.error('Please fill in all required fields');
      return;
    }

    setSaving(true);
    try {
             const response = await apiClient.addAPIKey({
         business_id: businessId!,
         platform: selectedPlatform,
         account_name: formData.account_name || '',
         api_key: formData.api_key,
         api_secret: formData.api_secret,
         access_token: formData.access_token,
         refresh_token: formData.refresh_token,
         client_id: formData.client_id,
         client_secret: formData.client_secret,
       });

      if (response.success) {
        toast.success('API key added successfully');
        setShowAddForm(false);
        setFormData({});
        setSelectedPlatform('');
        await fetchAPIKeys();
      } else {
        toast.error(getErrorMessage(response.error) || 'Failed to add API key');
      }
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to add API key');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteAPIKey = async (keyId: string) => {
    if (!confirm('Are you sure you want to delete this API key? This action cannot be undone.')) {
      return;
    }

    try {
      const response = await apiClient.deleteAPIKey(keyId);
      if (response.success) {
        toast.success('API key deleted successfully');
        await fetchAPIKeys();
      } else {
        toast.error(getErrorMessage(response.error) || 'Failed to delete API key');
      }
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to delete API key');
    }
  };

  const togglePasswordVisibility = (keyId: string) => {
    setShowPasswords(prev => ({
      ...prev,
      [keyId]: !prev[keyId]
    }));
  };

  const maskSensitiveData = (data: string, show: boolean) => {
    if (!data) return '';
    if (show) return data;
    return '*'.repeat(Math.min(data.length, 8));
  };

  if (isLoading) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-secondary-900 mb-2">Authentication Required</h2>
            <p className="text-secondary-600">Please log in to access settings.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ClientOnly>
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="bg-white border-b border-secondary-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  variant="ghost"
                  onClick={() => router.back()}
                  leftIcon={<ArrowLeftIcon className="h-4 w-4" />}
                >
                  Back
                </Button>
                <div>
                  <h1 className="text-2xl font-bold text-secondary-900">
                    Settings & API Keys
                  </h1>
                  <p className="text-secondary-600">
                    Manage your business settings and advertising platform credentials
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <ShieldCheckIcon className="h-6 w-6 text-green-600" />
                <span className="text-sm font-medium text-green-600">Secure</span>
              </div>
            </div>
          </header>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto p-6">
            <div className="max-w-4xl mx-auto space-y-6">
              {/* Business Info */}
              {business && (
                <div className="bg-white rounded-lg border border-secondary-200 p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <BuildingOfficeIcon className="h-6 w-6 text-primary-600" />
                    <h2 className="text-lg font-semibold text-secondary-900">{business.name}</h2>
                  </div>
                  <p className="text-secondary-600">Manage API credentials for advertising platforms</p>
                </div>
              )}

              {/* Security Notice */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <ShieldCheckIcon className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <h3 className="font-medium text-blue-900">Secure API Key Management</h3>
                    <p className="text-sm text-blue-700 mt-1">
                      All API keys are encrypted and stored securely. Keys are only decrypted when needed for API calls.
                    </p>
                  </div>
                </div>
              </div>

              {/* API Keys Section */}
              <div className="bg-white rounded-lg border border-secondary-200 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-lg font-semibold text-secondary-900">API Keys</h2>
                    <p className="text-secondary-600">Manage credentials for advertising platforms</p>
                  </div>
                  <Button
                    onClick={() => setShowAddForm(true)}
                    leftIcon={<PlusIcon className="h-4 w-4" />}
                  >
                    Add API Key
                  </Button>
                </div>

                {/* API Keys List */}
                <div className="space-y-4">
                  {apiKeys.length === 0 ? (
                    <div className="text-center py-8">
                      <KeyIcon className="h-12 w-12 text-secondary-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-secondary-900 mb-2">No API Keys Added</h3>
                      <p className="text-secondary-600 mb-4">
                        Add API keys to enable direct advertising on platforms
                      </p>
                      <Button
                        onClick={() => setShowAddForm(true)}
                        leftIcon={<PlusIcon className="h-4 w-4" />}
                      >
                        Add Your First API Key
                      </Button>
                    </div>
                  ) : (
                    apiKeys.map((apiKey) => {
                      const platform = PLATFORM_CONFIGS[apiKey.platform];
                      return (
                        <div key={apiKey.id} className="border border-secondary-200 rounded-lg p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <span className="text-2xl">{platform?.icon || '🔗'}</span>
                              <div>
                                <h3 className="font-medium text-secondary-900">
                                  {platform?.name || apiKey.platform}
                                </h3>
                                <p className="text-sm text-secondary-600">{apiKey.account_name}</p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                apiKey.is_active 
                                  ? 'bg-green-100 text-green-800' 
                                  : 'bg-red-100 text-red-800'
                              }`}>
                                {apiKey.is_active ? 'Active' : 'Inactive'}
                              </span>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => togglePasswordVisibility(apiKey.id)}
                              >
                                {showPasswords[apiKey.id] ? (
                                  <EyeSlashIcon className="h-4 w-4" />
                                ) : (
                                  <EyeIcon className="h-4 w-4" />
                                )}
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteAPIKey(apiKey.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <TrashIcon className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                          
                          {/* API Key Details */}
                          <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                            {apiKey.access_token && (
                              <div>
                                <span className="text-secondary-600">Access Token:</span>
                                <span className="ml-2 font-mono">
                                  {maskSensitiveData(apiKey.access_token, showPasswords[apiKey.id])}
                                </span>
                              </div>
                            )}
                            {apiKey.api_key && (
                              <div>
                                <span className="text-secondary-600">API Key:</span>
                                <span className="ml-2 font-mono">
                                  {maskSensitiveData(apiKey.api_key, showPasswords[apiKey.id])}
                                </span>
                              </div>
                            )}
                            {apiKey.client_id && (
                              <div>
                                <span className="text-secondary-600">Client ID:</span>
                                <span className="ml-2 font-mono">
                                  {maskSensitiveData(apiKey.client_id, showPasswords[apiKey.id])}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Add API Key Form */}
              {showAddForm && (
                <div className="bg-white rounded-lg border border-secondary-200 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-secondary-900">Add API Key</h3>
                    <Button
                      variant="ghost"
                      onClick={() => {
                        setShowAddForm(false);
                        setFormData({});
                        setSelectedPlatform('');
                      }}
                    >
                      Cancel
                    </Button>
                  </div>

                  <div className="space-y-4">
                    {/* Platform Selection */}
                    <div>
                      <label className="block text-sm font-medium text-secondary-700 mb-2">
                        Platform *
                      </label>
                      <select
                        value={selectedPlatform}
                        onChange={(e) => setSelectedPlatform(e.target.value)}
                        className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      >
                        <option value="">Select a platform</option>
                        {Object.entries(PLATFORM_CONFIGS).map(([key, config]) => (
                          <option key={key} value={key}>
                            {config.icon} {config.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Account Name */}
                    <div>
                      <label className="block text-sm font-medium text-secondary-700 mb-2">
                        Account Name *
                      </label>
                      <Input
                        type="text"
                        value={formData.account_name || ''}
                        onChange={(e) => setFormData(prev => ({ ...prev, account_name: e.target.value }))}
                        placeholder="Enter account name"
                      />
                    </div>

                    {/* Dynamic Fields Based on Platform */}
                    {selectedPlatform && PLATFORM_CONFIGS[selectedPlatform] && (
                      <div className="space-y-4">
                        <div className="border-t border-secondary-200 pt-4">
                          <h4 className="font-medium text-secondary-900 mb-3">
                            Required Fields for {PLATFORM_CONFIGS[selectedPlatform].name}
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {PLATFORM_CONFIGS[selectedPlatform].required_fields.map((field) => (
                              <div key={field}>
                                <label className="block text-sm font-medium text-secondary-700 mb-2">
                                  {field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())} *
                                </label>
                                                                 <Input
                                   type="password"
                                   value={(formData[field as keyof APIKey] as string) || ''}
                                   onChange={(e) => setFormData(prev => ({ ...prev, [field]: e.target.value }))}
                                   placeholder={`Enter ${field.replace(/_/g, ' ')}`}
                                 />
                              </div>
                            ))}
                          </div>
                        </div>

                        {PLATFORM_CONFIGS[selectedPlatform].optional_fields.length > 0 && (
                          <div className="border-t border-secondary-200 pt-4">
                            <h4 className="font-medium text-secondary-900 mb-3">Optional Fields</h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              {PLATFORM_CONFIGS[selectedPlatform].optional_fields.map((field) => (
                                <div key={field}>
                                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                                    {field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                  </label>
                                  <Input
                                    type="password"
                                    value={String(formData[field as keyof APIKey] || '')}
                                    onChange={(e) => setFormData(prev => ({ ...prev, [field]: e.target.value }))}
                                    placeholder={`Enter ${field.replace(/_/g, ' ')} (optional)`}
                                  />
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Help Link */}
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <p className="text-sm text-blue-700">
                            Need help getting your API credentials?{' '}
                            <a
                              href={PLATFORM_CONFIGS[selectedPlatform].help_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:text-blue-700 underline"
                            >
                              View documentation
                            </a>
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Submit Button */}
                    <div className="flex justify-end space-x-3 pt-4 border-t border-secondary-200">
                      <Button
                        variant="secondary"
                        onClick={() => {
                          setShowAddForm(false);
                          setFormData({});
                          setSelectedPlatform('');
                        }}
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={handleAddAPIKey}
                        disabled={saving || !selectedPlatform || !formData.account_name}
                      >
                        {saving ? 'Adding...' : 'Add API Key'}
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </main>
        </div>
      </div>
    </ClientOnly>
  );
} 