'use client';

import { useEffect, useState } from 'react';
import { useAuthStore } from '@/store/auth';
import { Business, ContentGenerationRequest, ContentGenerationResponse } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import AIRecommendations from '@/components/content/AIRecommendations';
import AudienceAnalysis from '@/components/content/AudienceAnalysis';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import { useSearchParams } from 'next/navigation';
import {
  DocumentTextIcon,
  PhotoIcon,
  VideoCameraIcon,
  SparklesIcon,
  ClipboardDocumentIcon,
  ArrowPathIcon,
  EyeIcon,
  CursorArrowRaysIcon,
  ChatBubbleLeftRightIcon,
  BuildingOfficeIcon,
  CalendarIcon,
  ChartBarIcon,
  RectangleStackIcon,
  BeakerIcon,
  ClockIcon,
  ChartBarSquareIcon,
  UsersIcon,
  GlobeAltIcon,
  PlusIcon,
  RocketLaunchIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { getErrorMessage } from '@/lib/getErrorMessage';

export default function ContentPage() {
  const { isAuthenticated, isLoading: authLoading } = useAuthStore();
  const searchParams = useSearchParams();
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [pageLoading, setPageLoading] = useState(true);
  const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null);
  const [activeTab, setActiveTab] = useState<'generate' | 'schedule' | 'analytics' | 'templates' | 'ab-testing' | 'integrations'>('generate');
  const [contentType, setContentType] = useState<'text' | 'image' | 'video'>('text');
  const [platform, setPlatform] = useState('facebook');
  const [prompt, setPrompt] = useState('');
  const [generatedContent, setGeneratedContent] = useState<ContentGenerationResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [contentHistory, setContentHistory] = useState<ContentGenerationResponse[]>([]);
  
  // Scheduling state
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [recurring, setRecurring] = useState(false);
  const [recurrencePattern, setRecurrencePattern] = useState('weekly');
  
  // Analytics state
  const [analyticsData, setAnalyticsData] = useState<any>(null);
  const [timePeriod, setTimePeriod] = useState('30d');
  
  // Templates state
  const [templates, setTemplates] = useState<any[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<any>(null);
  const [showTemplateCreator, setShowTemplateCreator] = useState(false);
  const [newTemplate, setNewTemplate] = useState({
    name: '',
    description: '',
    template_type: 'post',
    platform: 'facebook',
    category: 'promotional',
    template_structure: { content: '' },
    variables: []
  });
  
  // Media selection state
  const [businessMedia, setBusinessMedia] = useState<any[]>([]);
  const [selectedMedia, setSelectedMedia] = useState<any[]>([]);
  const [showMediaPicker, setShowMediaPicker] = useState(false);
  const [mediaFilter, setMediaFilter] = useState<'all' | 'images' | 'videos'>('all');
  
  // A/B Testing state
  const [abTestName, setAbTestName] = useState('');
  const [abTestHypothesis, setAbTestHypothesis] = useState('');
  const [variantsCount, setVariantsCount] = useState(3);

  // AI Recommendations and Audience Analysis state
  const [selectedRecommendation, setSelectedRecommendation] = useState<any>(null);
  const [selectedAudience, setSelectedAudience] = useState<any>(null);
  const [showRecommendations, setShowRecommendations] = useState(true);
  const [showAudienceAnalysis, setShowAudienceAnalysis] = useState(true);

  // Agent-specific state
  const [contentAnalytics, setContentAnalytics] = useState<any>(null);
  const [contentSchedules, setContentSchedules] = useState<any[]>([]);
  const [topicClusters, setTopicClusters] = useState<any[]>([]);
  const [agentStatus, setAgentStatus] = useState<any>({});

  useEffect(() => {
    // Initialize auth and fetch data
    const initializePage = async () => {
      setPageLoading(true);
      try {
        await fetchBusinesses();
        await fetchAnalyticsSummary();
        await fetchTemplates();
        await fetchAgentData();
      } catch (error) {
        console.error('Failed to initialize content page:', error);
      } finally {
        setPageLoading(false);
      }
    };
    
    initializePage();
  }, []);

  // Debug button state
  useEffect(() => {
    console.log('🔍 Debug: Button state check:');
    console.log('🔍 Debug: loading:', loading);
    console.log('🔍 Debug: selectedBusiness:', selectedBusiness);
    console.log('🔍 Debug: prompt:', prompt);
    console.log('🔍 Debug: button disabled:', loading || !selectedBusiness || !prompt.trim());
  }, [loading, selectedBusiness, prompt]);

  const fetchBusinesses = async () => {
    try {
      console.log('🔍 Debug: Fetching businesses...');
      const data = await apiClient.getBusinesses();
      console.log('🔍 Debug: Businesses loaded:', data);
      setBusinesses(data);
      
      // Check for businessId in URL parameters
      const businessIdFromUrl = searchParams.get('businessId');
      console.log('🔍 Debug: businessId from URL:', businessIdFromUrl);
      
      if (businessIdFromUrl && data.length > 0) {
        // Find the business by ID from URL
        const businessFromUrl = data.find(b => b.id.toString() === businessIdFromUrl);
        if (businessFromUrl) {
          console.log('🔍 Debug: Setting business from URL:', businessFromUrl);
          setSelectedBusiness(businessFromUrl);
        } else {
          console.log('🔍 Debug: Business not found in URL, setting first business');
          setSelectedBusiness(data[0]);
        }
      } else if (data.length > 0) {
        console.log('🔍 Debug: No businessId in URL, setting first business:', data[0]);
        setSelectedBusiness(data[0]);
      }
    } catch (error) {
      console.error('🔍 Debug: Failed to fetch businesses:', error);
      toast.error('Failed to load businesses');
    }
  };

  const fetchAnalyticsSummary = async () => {
    try {
      const response = await apiClient.getContentAnalyticsSummary(timePeriod);
      setAnalyticsData(response.summary);
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
    }
  };

  const fetchTemplates = async () => {
    try {
      const response = await apiClient.getContentTemplates();
      setTemplates(response.templates || []);
    } catch (error) {
      console.error('Failed to fetch templates:', error);
    }
  };

  const fetchAgentData = async () => {
    try {
      if (selectedBusiness) {
        // Fetch content analytics
        const analyticsResponse = await apiClient.getContentAnalytics(selectedBusiness.id.toString());
        if (analyticsResponse.success) {
          setContentAnalytics(analyticsResponse.analytics);
        }

        // Fetch content schedules
        const schedulesResponse = await apiClient.getContentSchedulesByBusiness(selectedBusiness.id.toString());
        if (schedulesResponse.success) {
          setContentSchedules(schedulesResponse.schedules || []);
        }

        // Fetch topic clusters
        const clustersResponse = await apiClient.getTopicClusters(selectedBusiness.id.toString());
        if (clustersResponse.success) {
          setTopicClusters(clustersResponse.clusters || []);
        }

        // Fetch agent status
        const statusResponse = await apiClient.getAllAgentsStatus();
        if (statusResponse.success) {
          setAgentStatus(statusResponse.agents || {});
        }
      }
    } catch (error) {
      console.error('Failed to fetch agent data:', error);
    }
  };

  // Load business media files
  const loadBusinessMedia = async (businessId: string) => {
    try {
      const response = await apiClient.getBusinessDocuments(businessId);
      if (response.success && response.documents) {
        const mediaFiles = response.documents.filter((doc: any) => {
          const mimeType = doc.mime_type || '';
          return mimeType.startsWith('image/') || mimeType.startsWith('video/');
        });
        setBusinessMedia(mediaFiles);
      }
    } catch (error) {
      console.error('Failed to load business media:', error);
    }
  };

  // Handle template creation
  const handleCreateTemplate = async () => {
    try {
      setLoading(true);
      const templateData = {
        ...newTemplate,
        user_id: 'demo_user',
        business_id: selectedBusiness?.id?.toString() || 'demo_business',
        template_structure: {
          content: (newTemplate.template_structure as any)?.content || '',
          media: selectedMedia.map(media => ({
            id: media.id,
            url: media.file_url,
            type: media.mime_type.startsWith('image/') ? 'image' : 'video',
            filename: media.original_filename
          }))
        },
        variables: newTemplate.variables || []
      };

      const response = await apiClient.createContentTemplate(templateData);
      if (response.success) {
        toast.success('Template created successfully!');
        setShowTemplateCreator(false);
        setNewTemplate({
          name: '',
          description: '',
          template_type: 'post',
          platform: 'facebook',
          category: 'promotional',
          template_structure: { content: '' },
          variables: []
        });
        setSelectedMedia([]);
        fetchTemplates();
      } else {
        toast.error(response.error || 'Failed to create template');
      }
    } catch (error) {
      console.error('Template creation failed:', error);
      toast.error('Failed to create template');
    } finally {
      setLoading(false);
    }
  };

  // Handle media selection
  const handleMediaSelection = (media: any) => {
    const isSelected = selectedMedia.some(m => m.id === media.id);
    if (isSelected) {
      setSelectedMedia(selectedMedia.filter(m => m.id !== media.id));
    } else {
      setSelectedMedia([...selectedMedia, media]);
    }
  };

  // Use template with media
  const handleUseTemplate = (template: any) => {
    setSelectedTemplate(template);
    if (template.template_structure?.media?.length > 0) {
      setSelectedMedia(template.template_structure.media);
    }
    setPrompt(`Create content using the ${template.name} template`);
    setActiveTab('generate');
  };

  const handleGenerateContent = async (e?: React.FormEvent) => {
    if (e) {
      e.preventDefault();
    }
    
    if (!selectedBusiness) {
      toast.error('Please select a business');
      return;
    }
    if (!prompt.trim()) {
      toast.error('Please enter a content prompt');
      return;
    }
    
    console.log('🔍 Debug: Starting content generation for business:', selectedBusiness);
    console.log('🔍 Debug: Business ID:', selectedBusiness.id);
    console.log('🔍 Debug: Business Name:', selectedBusiness.name);
    console.log('🔍 Debug: Content Type:', contentType);
    console.log('🔍 Debug: Platform:', platform);
    console.log('🔍 Debug: Prompt:', prompt);
    
    setLoading(true);
    try {
      let response;
      if (contentType === 'image') {
        // Use the comprehensive content generation endpoint for images
        console.log('🔍 Debug: Generating image content for business:', selectedBusiness.name);
        response = await apiClient.generateComprehensiveContent(
          selectedBusiness.id.toString(),
          'social_media',
          platform,
          prompt,
          true, // include_images
          false // include_videos
        );
      } else if (contentType === 'video') {
        console.log('🔍 Debug: Generating video content for business:', selectedBusiness.name);
        response = await apiClient.generateAIVideo({
          business_id: selectedBusiness.id.toString(),
          content_type: 'social_media',
          platform: platform,
          script: prompt,
          duration: 30,
          style: 'modern',
          dimensions: '1080x1920',
          background_music: 'Upbeat, professional',
          voice_over: true
        });
      } else {
        console.log('🔍 Debug: Generating text content for business:', selectedBusiness.name);
        response = await apiClient.generateAIContent({
          prompt,
          content_type: 'text',
          business_id: selectedBusiness.id.toString(),
          platform,
        });
      }
      
      console.log('🔍 Debug: AI Response received:', response);
      
      if (response.success !== false) {
        let contentToDisplay;
        
        if (contentType === 'image') {
          // Handle image content from comprehensive generation
          const images = response.content?.images || response.images || [];
          if (images.length > 0) {
            contentToDisplay = {
              text_content: 'Image generated successfully',
              images: images
            };
          } else {
            contentToDisplay = {
              text_content: 'Image generated successfully',
              images: []
            };
          }
        } else if (contentType === 'video') {
          contentToDisplay = response.video?.video_url || response.content || 'Video generated';
        } else {
          contentToDisplay = response.content || response.text_content || 'Content generated';
        }
        
        const contentResponse: ContentGenerationResponse = {
          content: contentToDisplay,
          platform,
          content_type: contentType,
          generated_at: new Date().toISOString(),
          metadata: response.metadata || {},
          status: 'completed'
        };
        setGeneratedContent(contentResponse);
        setContentHistory([contentResponse, ...contentHistory]);
        
        console.log('🔍 Debug: Content generated successfully for business:', selectedBusiness.name);
        toast.success(`AI content generated successfully for ${selectedBusiness.name}!`);
      } else {
        console.error('🔍 Debug: Content generation failed:', response.error);
        toast.error(getErrorMessage(response.error) || 'Failed to generate content');
      }
    } catch (error: any) {
      console.error('🔍 Debug: AI API error:', error);
      toast.error(getErrorMessage(error) || 'Failed to generate content');
    } finally {
      setLoading(false);
    }
  };

  const handleScheduleContent = async () => {
    if (!selectedBusiness || !prompt.trim()) {
      toast.error('Please select a business and enter content');
      return;
    }

    setLoading(true);
    try {
      const response = await apiClient.scheduleContent({
        title: `Scheduled: ${prompt.substring(0, 50)}...`,
        content_type: contentType,
        platform: platform,
        scheduled_date: scheduledDate || new Date().toISOString(),
        business_id: selectedBusiness.id.toString(),
                  content_data: {
            prompt: prompt,
            generated_content: generatedContent?.content || prompt
          }
      });

      if (response.success) {
        toast.success('Content scheduled successfully!');
        await fetchAgentData(); // Refresh data
      } else {
        toast.error(getErrorMessage(response.error) || 'Failed to schedule content');
      }
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to schedule content');
    } finally {
      setLoading(false);
    }
  };

  const handleAnalyzeContent = async () => {
    if (!selectedBusiness) {
      toast.error('Please select a business');
      return;
    }

    setLoading(true);
    try {
      const response = await apiClient.getContentAnalytics(selectedBusiness.id.toString());
      if (response.success) {
        setContentAnalytics(response.analytics);
        toast.success('Content analysis completed!');
      } else {
        toast.error(getErrorMessage(response.error) || 'Failed to analyze content');
      }
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to analyze content');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateABTest = async () => {
    if (!abTestName || !abTestHypothesis) {
      toast.error('Please fill in test name and hypothesis');
      return;
    }
    
    setLoading(true);
    
    try {
      const abTestRequest = {
        name: abTestName,
        test_type: 'content',
        hypothesis: abTestHypothesis,
        variants_count: variantsCount,
        success_metrics: ['engagement_rate', 'click_through_rate', 'conversion_rate'],
        confidence_level: 0.95,
        minimum_sample_size: 100
      };
      
      const response = await apiClient.createABTest(abTestRequest);
      toast.success('A/B test created successfully!');
      
      // Reset form
      setAbTestName('');
      setAbTestHypothesis('');
      setVariantsCount(3);
    } catch (error: any) {
      toast.error('Failed to create A/B test');
    } finally {
      setLoading(false);
    }
  };

  const handleCopyContent = (content: string) => {
    navigator.clipboard.writeText(content);
    toast.success('Content copied to clipboard!');
  };

  const handleOptimizeContent = async () => {
    if (!generatedContent || !selectedBusiness) return;
    
    setLoading(true);
    
    try {
      const response = await apiClient.optimizeContent(
        typeof generatedContent.content === 'string' 
          ? generatedContent.content 
          : generatedContent.content.text_content || 'Generated content',
        platform,
        selectedBusiness.id
      );
      setGeneratedContent(response);
      toast.success('Content optimized successfully!');
    } catch (error: any) {
      toast.error('Failed to optimize content');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectRecommendation = (recommendation: any) => {
    setSelectedRecommendation(recommendation);
    setContentType(recommendation.type);
    setPlatform(recommendation.platform);
    setPrompt(recommendation.description);
    toast.success(`Selected: ${recommendation.title}`);
  };

  const handleSelectAudience = (audience: any) => {
    setSelectedAudience(audience);
    toast.success(`Selected audience: ${audience.name}`);
  };

  const handleCreateCampaign = () => {
    if (!selectedBusiness || !generatedContent) {
      toast.error('Please generate content first');
      return;
    }
    
    // Navigate to campaign creation with pre-filled data
    const campaignData = {
      businessId: selectedBusiness.id,
      content: generatedContent.content,
      platform,
      contentType,
      audience: selectedAudience,
      recommendation: selectedRecommendation
    };
    
    // Store in localStorage for campaign creation page
    localStorage.setItem('campaignData', JSON.stringify(campaignData));
    
    // Navigate to campaign creation
    window.location.href = '/campaigns/create';
  };

  const handleCreateTopicCluster = async () => {
    if (!selectedBusiness || !prompt.trim()) {
      toast.error('Please select a business and enter a topic');
      return;
    }

    setLoading(true);
    try {
      const response = await apiClient.createTopicCluster({
        core_topic: prompt,
        business_id: selectedBusiness.id.toString(),
        target_keywords: [prompt.split(' ')[0], prompt.split(' ')[1]] // Simple keyword extraction
      });

      if (response.success) {
        toast.success('Topic cluster created successfully!');
        await fetchAgentData(); // Refresh data
      } else {
        toast.error(getErrorMessage(response.error) || 'Failed to create topic cluster');
      }
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to create topic cluster');
    } finally {
      setLoading(false);
    }
  };

  const contentTypes = [
    {
      type: 'text' as const,
      name: 'Text Content',
      description: 'Social media posts, blog articles, email copy',
      icon: DocumentTextIcon,
      color: 'bg-primary-100 text-primary-600',
    },
    {
      type: 'image' as const,
      name: 'Image Content',
      description: 'Marketing visuals, social media graphics',
      icon: PhotoIcon,
      color: 'bg-success-100 text-success-600',
    },
    {
      type: 'video' as const,
      name: 'Video Content',
      description: 'Video scripts, storyboards, concepts',
      icon: VideoCameraIcon,
      color: 'bg-warning-100 text-warning-600',
    },
  ];

  const platforms = [
    { value: 'facebook', name: 'Facebook', icon: '📘' },
    { value: 'instagram', name: 'Instagram', icon: '📷' },
    { value: 'twitter', name: 'Twitter', icon: '🐦' },
    { value: 'linkedin', name: 'LinkedIn', icon: '💼' },
    { value: 'youtube', name: 'YouTube', icon: '📺' },
    { value: 'tiktok', name: 'TikTok', icon: '🎵' },
    { value: 'google_ads', name: 'Google Ads', icon: '🔍' },
    { value: 'tabula', name: 'Tabula', icon: '📊' },
    { value: 'outbrain', name: 'Outbrain', icon: '🧠' },
    { value: 'email', name: 'Email', icon: '📧' },
    { value: 'blog', name: 'Blog', icon: '📝' },
    { value: 'telegram', name: 'Telegram', icon: '💬' },
    { value: 'whatsapp', name: 'WhatsApp', icon: '💚' },
    { value: 'mailchimp', name: 'Mailchimp', icon: '🐵' },
    { value: 'amazon', name: 'Amazon', icon: '📦' },
    { value: 'dropshipping', name: 'Dropshipping', icon: '🚚' },
  ];

  const tabs = [
    { id: 'generate', name: 'Generate Content', icon: SparklesIcon },
    { id: 'schedule', name: 'Schedule Content', icon: CalendarIcon },
    { id: 'analytics', name: 'Analytics', icon: ChartBarIcon },
    { id: 'templates', name: 'Templates', icon: RectangleStackIcon },
    { id: 'ab-testing', name: 'A/B Testing', icon: BeakerIcon },
    { id: 'integrations', name: 'External Integrations', icon: BuildingOfficeIcon },
  ];

  // Show loading state while initializing
  if (pageLoading || authLoading) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
            <p className="text-secondary-600">Loading Content Management...</p>
          </div>
        </div>
      </div>
    );
  }

  // Temporarily bypass authentication for testing
  const isAuthenticatedForTesting = true; // Set to true to bypass auth check
  
  if (!isAuthenticatedForTesting && !isAuthenticated) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-secondary-900 mb-2">Authentication Required</h2>
            <p className="text-secondary-600 mb-4">Please log in to access content generation.</p>
            <a 
              href="/login" 
              className="inline-flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700"
            >
              Go to Login
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="bg-white border-b border-secondary-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-secondary-900">
                  Content Management
                </h1>
                <p className="text-secondary-600">
                  Create, schedule, analyze, and optimize your content
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <SparklesIcon className="h-6 w-6 text-primary-600" />
                <span className="text-sm font-medium text-primary-600">AI Powered</span>
              </div>
            </div>
          </header>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto p-6">
            {/* Business Selection - Moved to top */}
            <div className="mb-6">
              <div className="card">
                <div className="card-header">
                  <h3 className="card-title">Select Business</h3>
                  <p className="card-subtitle">Choose the business for content generation</p>
                </div>
                
                {/* Current Business Display */}
                {selectedBusiness && (
                  <div className="mb-4 p-4 bg-primary-50 border border-primary-200 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-primary-900">
                          🎯 Currently Selected: {selectedBusiness.name}
                        </h4>
                        <p className="text-sm text-primary-700">
                          Industry: {selectedBusiness.industry || 'Not specified'} | 
                          ID: {selectedBusiness.id}
                        </p>
                        <p className="text-xs text-primary-600 mt-1">
                          AI Agent will generate content specifically for this business
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                          Active
                        </span>
                      </div>
                    </div>
                  </div>
                )}
                
                <select
                  value={selectedBusiness?.id || ''}
                  onChange={(e) => {
                    const business = businesses.find(b => b.id === parseInt(e.target.value));
                    setSelectedBusiness(business || null);
                    console.log('🔍 Debug: Business selected:', business);
                  }}
                  className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                >
                  <option value="">Select a business...</option>
                  {businesses.map((business) => (
                    <option key={business.id} value={business.id}>
                      {business.name} ({business.industry || 'No industry'})
                    </option>
                  ))}
                </select>
                
                {/* Debug Information */}
                {process.env.NODE_ENV === 'development' && (
                  <div className="mt-2 p-2 bg-gray-100 rounded text-xs text-gray-600">
                    <p><strong>Debug Info:</strong></p>
                    <p>Selected Business ID: {selectedBusiness?.id || 'None'}</p>
                    <p>Total Businesses: {businesses.length}</p>
                    <p>URL businessId: {searchParams.get('businessId') || 'None'}</p>
                  </div>
                )}
              </div>
            </div>

            {/* AI Recommendations and Audience Analysis */}
            {activeTab === 'generate' && selectedBusiness && (
              <div className="mb-6 space-y-6">
                {/* AI Recommendations */}
                <AIRecommendations
                  business={selectedBusiness}
                  onSelectRecommendation={handleSelectRecommendation}
                  onGenerateRecommendations={() => {}}
                />
                
                {/* Audience Analysis */}
                <AudienceAnalysis
                  business={selectedBusiness}
                  onSelectAudience={handleSelectAudience}
                  onGenerateAnalysis={() => {}}
                />
              </div>
            )}

            {/* Tab Navigation */}
            <div className="mb-6">
              <nav className="flex space-x-1 bg-white rounded-lg p-1 shadow-sm">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`flex items-center space-x-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                        activeTab === tab.id
                          ? 'bg-primary-100 text-primary-700'
                          : 'text-secondary-600 hover:text-secondary-900 hover:bg-secondary-50'
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      <span>{tab.name}</span>
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Tab Content */}
            <div className="space-y-6">
              {/* Generate Content Tab */}
              {activeTab === 'generate' && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Content Generation Form */}
                  <div className="space-y-6">

                    {/* Content Type Selection */}
                    <div className="card">
                      <div className="card-header">
                        <h3 className="card-title">Content Type</h3>
                        <p className="card-subtitle">Choose the type of content to generate</p>
                      </div>
                      <div className="grid grid-cols-1 gap-3">
                        {contentTypes.map((type) => (
                          <button
                            key={type.type}
                            onClick={() => setContentType(type.type)}
                            className={`flex items-center space-x-3 p-4 rounded-lg border-2 transition-colors ${
                              contentType === type.type
                                ? 'border-primary-500 bg-primary-50'
                                : 'border-secondary-200 hover:border-secondary-300'
                            }`}
                          >
                            <div className={`p-2 rounded-lg ${type.color}`}>
                              <type.icon className="h-5 w-5" />
                            </div>
                            <div className="text-left">
                              <div className="font-medium text-secondary-900">{type.name}</div>
                              <div className="text-sm text-secondary-600">{type.description}</div>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Platform Selection */}
                    <div className="card">
                      <div className="card-header">
                        <h3 className="card-title">Platform</h3>
                        <p className="card-subtitle">Select the target platform</p>
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        {platforms.map((platformOption) => (
                          <button
                            key={platformOption.value}
                            onClick={() => setPlatform(platformOption.value)}
                            className={`flex flex-col items-center space-y-1 p-3 rounded-lg border-2 transition-colors ${
                              platform === platformOption.value
                                ? 'border-primary-500 bg-primary-50'
                                : 'border-secondary-200 hover:border-secondary-300'
                            }`}
                          >
                            <span className="text-2xl">{platformOption.icon}</span>
                            <span className="text-xs font-medium text-secondary-900">{platformOption.name}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Content Prompt */}
                    <div className="card">
                      <div className="card-header">
                        <h3 className="card-title">Content Prompt</h3>
                        <p className="card-subtitle">Describe what you want to create</p>
                      </div>
                      <textarea
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="Describe the content you want to generate..."
                        className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        rows={4}
                      />
                    </div>

                    {/* Generate Button */}
                    <Button
                      onClick={handleGenerateContent}
                      disabled={loading || !selectedBusiness || !prompt.trim()}
                      className="w-full"
                    >
                      {loading ? (
                        <>
                          <ArrowPathIcon className="h-5 w-5 animate-spin mr-2" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <SparklesIcon className="h-5 w-5 mr-2" />
                          Generate Content
                        </>
                      )}
                    </Button>

                    {/* Create Campaign Button */}
                    {generatedContent && (
                      <Button
                        onClick={handleCreateCampaign}
                        variant="secondary"
                        className="w-full"
                        leftIcon={<RocketLaunchIcon className="h-4 w-4" />}
                      >
                        Create Campaign with This Content
                      </Button>
                    )}
                  </div>

                  {/* Generated Content Display */}
                  <div className="space-y-6">
                    {generatedContent && (
                      <div className="card">
                        <div className="card-header">
                          <h3 className="card-title">Generated Content</h3>
                          <div className="flex space-x-2">
                            <Button
                              onClick={() => handleCopyContent(
                                typeof generatedContent.content === 'string' 
                                  ? generatedContent.content 
                                  : generatedContent.content.text_content || 'Generated content'
                              )}
                              variant="secondary"
                              size="sm"
                            >
                              <ClipboardDocumentIcon className="h-4 w-4 mr-1" />
                              Copy
                            </Button>
                            <Button
                              onClick={handleOptimizeContent}
                              variant="secondary"
                              size="sm"
                            >
                              <CursorArrowRaysIcon className="h-4 w-4 mr-1" />
                              Optimize
                            </Button>
                          </div>
                        </div>
                        <div className="space-y-4">
                          <div>
                            <h4 className="font-medium text-secondary-900 mb-2">Generated Content</h4>
                            <p className="text-secondary-700 bg-secondary-50 p-3 rounded-lg">AI Generated {contentType} content</p>
                          </div>
                          <div>
                            <h4 className="font-medium text-secondary-900 mb-2">Content</h4>
                            {contentType === 'image' ? (
                              <div className="bg-secondary-50 p-4 rounded-lg flex flex-wrap gap-4 justify-center">
                                {typeof generatedContent.content === 'object' && generatedContent.content.images && Array.isArray(generatedContent.content.images) && generatedContent.content.images.length > 0
                                  ? generatedContent.content.images.map((img: any, idx: number) => (
                                      <img
                                        key={idx}
                                        src={typeof img === 'string' ? img : img.url || img.src || 'https://via.placeholder.com/400x300/3B82F6/FFFFFF?text=AI+Generated+Image'}
                                        alt={`Generated content ${idx + 1}`}
                                        className="w-full max-w-xs rounded-lg shadow-lg"
                                        onError={(e) => {
                                          e.currentTarget.src = 'https://via.placeholder.com/400x300/3B82F6/FFFFFF?text=AI+Generated+Image';
                                        }}
                                      />
                                    ))
                                  : (
                                    <div className="text-center py-8">
                                      <div className="w-64 h-48 bg-gradient-to-br from-primary-100 to-primary-200 rounded-lg mx-auto flex items-center justify-center">
                                        <div className="text-center">
                                          <PhotoIcon className="h-12 w-12 text-primary-600 mx-auto mb-2" />
                                          <p className="text-primary-700 font-medium">No image generated</p>
                                          <p className="text-sm text-primary-600">Try again or check your prompt</p>
                                        </div>
                                      </div>
                                    </div>
                                  )
                                }
                              </div>
                            ) : (
                              <div className="text-secondary-700 bg-secondary-50 p-3 rounded-lg whitespace-pre-wrap">
                                {typeof generatedContent.content === 'string' 
                                  ? generatedContent.content 
                                  : typeof generatedContent.content === 'object' && generatedContent.content.text_content
                                    ? generatedContent.content.text_content
                                    : 'Content generated'
                                }
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Content History */}
                    {contentHistory.length > 0 && (
                      <div className="card">
                        <div className="card-header">
                          <h3 className="card-title">Recent Content</h3>
                        </div>
                        <div className="space-y-3">
                          {contentHistory.slice(0, 5).map((content, index) => (
                            <div
                              key={index}
                              className="p-3 border border-secondary-200 rounded-lg hover:bg-secondary-50 cursor-pointer"
                              onClick={() => setGeneratedContent(content)}
                            >
                              <div className="font-medium text-secondary-900 truncate">
                                Generated Content
                              </div>
                              <div className="text-sm text-secondary-600 truncate">
                                {typeof content.content === 'string' 
                                  ? content.content.substring(0, 100) + '...'
                                  : typeof content.content === 'object' && content.content.text_content
                                    ? content.content.text_content.substring(0, 100) + '...'
                                    : content.content_type === 'image' 
                                      ? 'Generated Image'
                                      : 'Generated Content'
                                }
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Schedule Content Tab */}
              {activeTab === 'schedule' && (
                <div className="max-w-2xl mx-auto">
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">Schedule Content</h3>
                      <p className="card-subtitle">Schedule your generated content for publishing</p>
                    </div>
                    <div className="space-y-6">
                      {generatedContent ? (
                        <>
                          <div className="p-4 bg-secondary-50 rounded-lg">
                            <h4 className="font-medium text-secondary-900 mb-2">Content to Schedule</h4>
                            <p className="text-secondary-700">
                              {typeof generatedContent.content === 'string' 
                                ? generatedContent.content.substring(0, 200) + '...'
                                : typeof generatedContent.content === 'object' && generatedContent.content.text_content
                                  ? generatedContent.content.text_content.substring(0, 200) + '...'
                                  : 'Content to schedule'
                              }
                            </p>
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="block text-sm font-medium text-secondary-700 mb-2">Date</label>
                              <input
                                type="date"
                                value={scheduledDate}
                                onChange={(e) => setScheduledDate(e.target.value)}
                                className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-secondary-700 mb-2">Time</label>
                              <input
                                type="time"
                                value={scheduledTime}
                                onChange={(e) => setScheduledTime(e.target.value)}
                                className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                              />
                            </div>
                          </div>

                          <div className="flex items-center space-x-3">
                            <input
                              type="checkbox"
                              id="recurring"
                              checked={recurring}
                              onChange={(e) => setRecurring(e.target.checked)}
                              className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500"
                            />
                            <label htmlFor="recurring" className="text-sm font-medium text-secondary-700">
                              Recurring schedule
                            </label>
                          </div>

                          {recurring && (
                            <div>
                              <label className="block text-sm font-medium text-secondary-700 mb-2">Recurrence Pattern</label>
                              <select
                                value={recurrencePattern}
                                onChange={(e) => setRecurrencePattern(e.target.value)}
                                className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                              >
                                <option value="daily">Daily</option>
                                <option value="weekly">Weekly</option>
                                <option value="monthly">Monthly</option>
                              </select>
                            </div>
                          )}

                          <Button
                            onClick={handleScheduleContent}
                            disabled={loading || !scheduledDate || !scheduledTime}
                            className="w-full"
                          >
                            {loading ? (
                              <>
                                <ArrowPathIcon className="h-5 w-5 animate-spin mr-2" />
                                Scheduling...
                              </>
                            ) : (
                              <>
                                <CalendarIcon className="h-5 w-5 mr-2" />
                                Schedule Content
                              </>
                            )}
                          </Button>
                        </>
                      ) : (
                        <div className="text-center py-8">
                          <CalendarIcon className="h-12 w-12 text-secondary-400 mx-auto mb-4" />
                          <p className="text-secondary-600">Generate content first to schedule it</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Analytics Tab */}
              {activeTab === 'analytics' && (
                <div className="space-y-6">
                  {analyticsData ? (
                    <>
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <div className="card">
                          <div className="flex items-center">
                            <div className="p-2 bg-primary-100 rounded-lg">
                              <ChartBarSquareIcon className="h-6 w-6 text-primary-600" />
                            </div>
                            <div className="ml-4">
                              <p className="text-sm font-medium text-secondary-600">Total Posts</p>
                              <p className="text-2xl font-bold text-secondary-900">{analyticsData.total_posts}</p>
                            </div>
                          </div>
                        </div>

                        <div className="card">
                          <div className="flex items-center">
                            <div className="p-2 bg-success-100 rounded-lg">
                              <UsersIcon className="h-6 w-6 text-success-600" />
                            </div>
                            <div className="ml-4">
                              <p className="text-sm font-medium text-secondary-600">Total Engagement</p>
                              <p className="text-2xl font-bold text-secondary-900">{analyticsData.total_engagement}</p>
                            </div>
                          </div>
                        </div>

                        <div className="card">
                          <div className="flex items-center">
                            <div className="p-2 bg-warning-100 rounded-lg">
                              <ChartBarIcon className="h-6 w-6 text-warning-600" />
                            </div>
                            <div className="ml-4">
                              <p className="text-sm font-medium text-secondary-600">Avg Engagement Rate</p>
                              <p className="text-2xl font-bold text-secondary-900">{analyticsData.average_engagement_rate}%</p>
                            </div>
                          </div>
                        </div>

                        <div className="card">
                          <div className="flex items-center">
                            <div className="p-2 bg-info-100 rounded-lg">
                              <GlobeAltIcon className="h-6 w-6 text-info-600" />
                            </div>
                            <div className="ml-4">
                              <p className="text-sm font-medium text-secondary-600">Top Platform</p>
                              <p className="text-2xl font-bold text-secondary-900 capitalize">{analyticsData.top_performing_platform}</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div className="card">
                          <div className="card-header">
                            <h3 className="card-title">Content Performance</h3>
                          </div>
                          <div className="space-y-4">
                            {analyticsData.content_performance ? Object.entries(analyticsData.content_performance).map(([type, data]: [string, any]) => (
                              <div key={type} className="flex justify-between items-center">
                                <span className="capitalize font-medium text-secondary-700">{type}</span>
                                <div className="text-right">
                                  <div className="font-bold text-secondary-900">{data.count} posts</div>
                                  <div className="text-sm text-secondary-600">{data.avg_engagement}% engagement</div>
                                </div>
                              </div>
                            )) : (
                              <div className="text-center py-4 text-secondary-500">No content performance data available</div>
                            )}
                          </div>
                        </div>

                        <div className="card">
                          <div className="card-header">
                            <h3 className="card-title">Platform Performance</h3>
                          </div>
                          <div className="space-y-4">
                            {analyticsData.platform_performance ? Object.entries(analyticsData.platform_performance).map(([platform, data]: [string, any]) => (
                              <div key={platform} className="flex justify-between items-center">
                                <span className="capitalize font-medium text-secondary-700">{platform}</span>
                                <div className="text-right">
                                  <div className="font-bold text-secondary-900">{data.posts} posts</div>
                                  <div className="text-sm text-secondary-600">{data.avg_engagement}% engagement</div>
                                </div>
                              </div>
                            )) : (
                              <div className="text-center py-4 text-secondary-500">No platform performance data available</div>
                            )}
                          </div>
                        </div>
                      </div>

                      {generatedContent && (
                        <div className="card">
                          <div className="card-header">
                            <h3 className="card-title">Analyze Current Content</h3>
                          </div>
                          <Button
                            onClick={handleAnalyzeContent}
                            disabled={loading}
                            className="w-full"
                          >
                            {loading ? (
                              <>
                                <ArrowPathIcon className="h-5 w-5 animate-spin mr-2" />
                                Analyzing...
                              </>
                            ) : (
                              <>
                                <ChartBarIcon className="h-5 w-5 mr-2" />
                                Analyze Content Performance
                              </>
                            )}
                          </Button>
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="text-center py-8">
                      <ChartBarIcon className="h-12 w-12 text-secondary-400 mx-auto mb-4" />
                      <p className="text-secondary-600">No analytics data available</p>
                    </div>
                  )}
                </div>
              )}

              {/* Templates Tab */}
              {activeTab === 'templates' && (
                <div className="space-y-6">
                  <div className="card">
                    <div className="card-header">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="card-title">Content Templates</h3>
                          <p className="card-subtitle">Use pre-built templates for consistent content creation</p>
                        </div>
                        <Button
                          onClick={() => {
                            setShowTemplateCreator(true);
                                                      if (selectedBusiness) {
                            loadBusinessMedia(selectedBusiness.id.toString());
                          }
                          }}
                          className="flex items-center"
                        >
                          <PlusIcon className="h-5 w-5 mr-2" />
                          Create Template
                        </Button>
                      </div>
                    </div>
                    
                    {/* Business Selection for Media */}
                    {selectedBusiness && (
                      <div className="mb-4 p-4 bg-secondary-50 rounded-lg">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium text-secondary-900">Business: {selectedBusiness.name}</h4>
                            <p className="text-sm text-secondary-600">
                              {businessMedia.length} media files available for templates
                            </p>
                          </div>
                          <Button
                            onClick={() => setShowMediaPicker(true)}
                            variant="secondary"
                            size="sm"
                          >
                            <PhotoIcon className="h-4 w-4 mr-2" />
                            Select Media
                          </Button>
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {templates.map((template) => (
                        <div
                          key={template.id}
                          className="p-4 border border-secondary-200 rounded-lg hover:border-primary-300 cursor-pointer transition-colors"
                          onClick={() => handleUseTemplate(template)}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium text-secondary-900">{template.name}</h4>
                            <span className="text-xs bg-secondary-100 text-secondary-600 px-2 py-1 rounded">
                              {template.template_type}
                            </span>
                          </div>
                          <p className="text-sm text-secondary-600 mb-3">{template.description}</p>
                          
                          {/* Show media preview if template has media */}
                          {template.template_structure?.media?.length > 0 && (
                            <div className="mb-3">
                              <div className="flex flex-wrap gap-1">
                                {template.template_structure.media.slice(0, 3).map((media: any, index: number) => (
                                  <div key={index} className="w-8 h-8 bg-secondary-100 rounded flex items-center justify-center">
                                    {media.type === 'image' ? (
                                      <PhotoIcon className="h-4 w-4 text-secondary-600" />
                                    ) : (
                                      <VideoCameraIcon className="h-4 w-4 text-secondary-600" />
                                    )}
                                  </div>
                                ))}
                                {template.template_structure.media.length > 3 && (
                                  <div className="w-8 h-8 bg-secondary-100 rounded flex items-center justify-center text-xs text-secondary-600">
                                    +{template.template_structure.media.length - 3}
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                          
                          <div className="flex items-center justify-between text-xs text-secondary-500">
                            <span>{template.platform}</span>
                            <span>Used {template.usage_count} times</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Template Creator */}
                  {showTemplateCreator && (
                    <div className="card">
                      <div className="card-header">
                        <h3 className="card-title">Create New Template</h3>
                        <p className="card-subtitle">Define a reusable template with media</p>
                      </div>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-secondary-700 mb-2">Template Name</label>
                          <input
                            type="text"
                            value={newTemplate.name}
                            onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })}
                            placeholder="e.g., Product Launch Template"
                            className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-secondary-700 mb-2">Description</label>
                          <textarea
                            value={newTemplate.description}
                            onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })}
                            placeholder="Describe the purpose of this template"
                            className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                            rows={3}
                          />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-secondary-700 mb-2">Template Type</label>
                            <select
                              value={newTemplate.template_type}
                              onChange={(e) => setNewTemplate({ ...newTemplate, template_type: e.target.value })}
                              className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                            >
                              <option value="post">Post</option>
                              <option value="story">Story</option>
                              <option value="ad">Ad</option>
                              <option value="email">Email</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-secondary-700 mb-2">Platform</label>
                            <select
                              value={newTemplate.platform}
                              onChange={(e) => setNewTemplate({ ...newTemplate, platform: e.target.value })}
                              className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                            >
                              {platforms.map(p => (
                                <option key={p.value} value={p.value}>{p.name}</option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-secondary-700 mb-2">Category</label>
                            <select
                              value={newTemplate.category}
                              onChange={(e) => setNewTemplate({ ...newTemplate, category: e.target.value })}
                              className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                            >
                              <option value="promotional">Promotional</option>
                              <option value="educational">Educational</option>
                              <option value="entertainment">Entertainment</option>
                              <option value="news">News</option>
                            </select>
                          </div>
                        </div>
                        
                        {/* Media Selection */}
                        <div>
                          <label className="block text-sm font-medium text-secondary-700 mb-2">
                            Selected Media ({selectedMedia.length} items)
                          </label>
                          {selectedMedia.length > 0 ? (
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-2">
                              {selectedMedia.map((media) => (
                                <div key={media.id} className="relative">
                                  <div className="w-full h-20 bg-secondary-100 rounded flex items-center justify-center">
                                    {media.mime_type.startsWith('image/') ? (
                                      <PhotoIcon className="h-6 w-6 text-secondary-600" />
                                    ) : (
                                      <VideoCameraIcon className="h-6 w-6 text-secondary-600" />
                                    )}
                                  </div>
                                  <button
                                    onClick={() => handleMediaSelection(media)}
                                    className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-xs"
                                  >
                                    ×
                                  </button>
                                  <p className="text-xs text-secondary-600 truncate mt-1">{media.original_filename}</p>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-sm text-secondary-500">No media selected</p>
                          )}
                                                     <Button
                             onClick={() => setShowMediaPicker(true)}
                             variant="secondary"
                             className="w-full"
                           >
                             <PhotoIcon className="h-5 w-5 mr-2" />
                             Select Media Files
                           </Button>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-secondary-700 mb-2">Template Content</label>
                          <textarea
                            value={newTemplate.template_structure.content}
                            onChange={(e) => setNewTemplate({ 
                              ...newTemplate, 
                              template_structure: { 
                                ...newTemplate.template_structure, 
                                content: e.target.value 
                              } 
                            })}
                            placeholder="Enter your template content with placeholders like {product_name}, {price}, etc."
                            className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                            rows={5}
                          />
                        </div>
                        
                        <div className="flex space-x-2">
                          <Button
                            onClick={handleCreateTemplate}
                            disabled={loading || !newTemplate.name || !newTemplate.template_structure.content}
                            className="flex-1"
                          >
                            {loading ? (
                              <>
                                <ArrowPathIcon className="h-5 w-5 animate-spin mr-2" />
                                Creating Template...
                              </>
                            ) : (
                              <>
                                <PlusIcon className="h-5 w-5 mr-2" />
                                Create Template
                              </>
                            )}
                          </Button>
                          <Button
                            onClick={() => setShowTemplateCreator(false)}
                            variant="secondary"
                            className="flex-1"
                          >
                            Cancel
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Media Picker Modal */}
                  {showMediaPicker && (
                    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                      <div className="bg-white rounded-lg p-6 w-full max-w-4xl max-h-[80vh] overflow-y-auto">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg font-semibold">Select Media Files</h3>
                          <Button
                            onClick={() => setShowMediaPicker(false)}
                            variant="ghost"
                            size="sm"
                          >
                            ×
                          </Button>
                        </div>
                        
                        {/* Filter Controls */}
                                                 <div className="flex space-x-2 mb-4">
                           <Button
                             onClick={() => setMediaFilter('all')}
                             variant={mediaFilter === 'all' ? 'primary' : 'secondary'}
                             size="sm"
                           >
                             All ({businessMedia.length})
                           </Button>
                           <Button
                             onClick={() => setMediaFilter('images')}
                             variant={mediaFilter === 'images' ? 'primary' : 'secondary'}
                             size="sm"
                           >
                             Images ({businessMedia.filter(m => m.mime_type.startsWith('image/')).length})
                           </Button>
                           <Button
                             onClick={() => setMediaFilter('videos')}
                             variant={mediaFilter === 'videos' ? 'primary' : 'secondary'}
                             size="sm"
                           >
                             Videos ({businessMedia.filter(m => m.mime_type.startsWith('video/')).length})
                           </Button>
                         </div>
                        
                        {/* Media Grid */}
                        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                          {businessMedia
                            .filter(media => {
                              if (mediaFilter === 'images') return media.mime_type.startsWith('image/');
                              if (mediaFilter === 'videos') return media.mime_type.startsWith('video/');
                              return true;
                            })
                            .map((media) => {
                              const isSelected = selectedMedia.some(m => m.id === media.id);
                              return (
                                <div
                                  key={media.id}
                                  onClick={() => handleMediaSelection(media)}
                                  className={`relative cursor-pointer rounded-lg border-2 transition-colors ${
                                    isSelected 
                                      ? 'border-primary-500 bg-primary-50' 
                                      : 'border-secondary-200 hover:border-secondary-300'
                                  }`}
                                >
                                  <div className="w-full h-24 bg-secondary-100 rounded-t-lg flex items-center justify-center">
                                    {media.mime_type.startsWith('image/') ? (
                                      <PhotoIcon className="h-8 w-8 text-secondary-600" />
                                    ) : (
                                      <VideoCameraIcon className="h-8 w-8 text-secondary-600" />
                                    )}
                                  </div>
                                  <div className="p-2">
                                    <p className="text-xs text-secondary-600 truncate">{media.original_filename}</p>
                                    <p className="text-xs text-secondary-500">
                                      {Math.round(media.file_size / 1024)}KB
                                    </p>
                                  </div>
                                  {isSelected && (
                                    <div className="absolute top-1 right-1 w-5 h-5 bg-primary-500 text-white rounded-full flex items-center justify-center text-xs">
                                      ✓
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                        </div>
                        
                                                 <div className="flex justify-end space-x-2 mt-4">
                           <Button
                             onClick={() => setShowMediaPicker(false)}
                             variant="secondary"
                           >
                             Done
                           </Button>
                         </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* A/B Testing Tab */}
              {activeTab === 'ab-testing' && (
                <div className="max-w-2xl mx-auto">
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">Create A/B Test</h3>
                      <p className="card-subtitle">Test different content variations to optimize performance</p>
                    </div>
                    <div className="space-y-6">
                      <div>
                        <label className="block text-sm font-medium text-secondary-700 mb-2">Test Name</label>
                        <input
                          type="text"
                          value={abTestName}
                          onChange={(e) => setAbTestName(e.target.value)}
                          placeholder="e.g., Headline Optimization Test"
                          className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-secondary-700 mb-2">Hypothesis</label>
                        <textarea
                          value={abTestHypothesis}
                          onChange={(e) => setAbTestHypothesis(e.target.value)}
                          placeholder="What are you testing and why?"
                          className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                          rows={3}
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-secondary-700 mb-2">Number of Variants</label>
                        <select
                          value={variantsCount}
                          onChange={(e) => setVariantsCount(parseInt(e.target.value))}
                          className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        >
                          <option value={2}>2 variants</option>
                          <option value={3}>3 variants</option>
                          <option value={4}>4 variants</option>
                          <option value={5}>5 variants</option>
                        </select>
                      </div>

                      <Button
                        onClick={handleCreateABTest}
                        disabled={loading || !abTestName || !abTestHypothesis}
                        className="w-full"
                      >
                        {loading ? (
                          <>
                            <ArrowPathIcon className="h-5 w-5 animate-spin mr-2" />
                            Creating Test...
                          </>
                        ) : (
                          <>
                            <BeakerIcon className="h-5 w-5 mr-2" />
                            Create A/B Test
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* External Integrations Tab */}
              {activeTab === 'integrations' && (
                <div className="space-y-6">
                  <div className="card">
                    <div className="card-header">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="card-title">External Integrations</h3>
                          <p className="card-subtitle">Connect with external services to enhance your marketing capabilities</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            Week 2 Features
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Integration Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    
                    {/* Telegram Bot Integration */}
                    <div className="card hover:shadow-lg transition-shadow">
                      <div className="card-header">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-blue-100 rounded-lg">
                            <span className="text-2xl">💬</span>
                          </div>
                          <div>
                            <h4 className="card-title text-lg">Telegram Bot</h4>
                            <p className="text-sm text-secondary-600">Automated messaging & notifications</p>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="text-sm text-secondary-700">
                          <p>• Send automated notifications</p>
                          <p>• System status updates</p>
                          <p>• Campaign performance alerts</p>
                          <p>• AI agent status reports</p>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            ✅ Active
                          </span>
                          <Button
                            onClick={() => toast.success('Telegram bot is ready! Use /start in your bot to begin.')}
                            size="sm"
                            variant="secondary"
                          >
                            Test Bot
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* WhatsApp Business API */}
                    <div className="card hover:shadow-lg transition-shadow">
                      <div className="card-header">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-green-100 rounded-lg">
                            <span className="text-2xl">💚</span>
                          </div>
                          <div>
                            <h4 className="card-title text-lg">WhatsApp Business</h4>
                            <p className="text-sm text-secondary-600">Customer communication & support</p>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="text-sm text-secondary-700">
                          <p>• Send messages to customers</p>
                          <p>• Broadcast marketing campaigns</p>
                          <p>• Lead notifications</p>
                          <p>• Template messages</p>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                            🔧 Mock Mode
                          </span>
                          <Button
                            onClick={() => toast.success('WhatsApp integration ready! Configure your API keys to enable.')}
                            size="sm"
                            variant="secondary"
                          >
                            Configure
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Stripe Payments */}
                    <div className="card hover:shadow-lg transition-shadow">
                      <div className="card-header">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-purple-100 rounded-lg">
                            <span className="text-2xl">💳</span>
                          </div>
                          <div>
                            <h4 className="card-title text-lg">Stripe Payments</h4>
                            <p className="text-sm text-secondary-600">Payment processing & subscriptions</p>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="text-sm text-secondary-700">
                          <p>• Process payments securely</p>
                          <p>• Manage subscriptions</p>
                          <p>• Handle webhooks</p>
                          <p>• Customer management</p>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                            🔧 Mock Mode
                          </span>
                          <Button
                            onClick={() => toast.success('Stripe integration ready! Add your API keys to process real payments.')}
                            size="sm"
                            variant="secondary"
                          >
                            Setup
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Email Marketing (Mailchimp) */}
                    <div className="card hover:shadow-lg transition-shadow">
                      <div className="card-header">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-yellow-100 rounded-lg">
                            <span className="text-2xl">🐵</span>
                          </div>
                          <div>
                            <h4 className="card-title text-lg">Email Marketing</h4>
                            <p className="text-sm text-secondary-600">Mailchimp & ConvertKit integration</p>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="text-sm text-secondary-700">
                          <p>• Manage email subscribers</p>
                          <p>• Send campaigns automatically</p>
                          <p>• Welcome email sequences</p>
                          <p>• Performance tracking</p>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            ✅ Active
                          </span>
                          <Button
                            onClick={() => toast.success('Email marketing ready! Choose Mailchimp or ConvertKit in settings.')}
                            size="sm"
                            variant="secondary"
                          >
                            Manage Lists
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Amazon Integration */}
                    <div className="card hover:shadow-lg transition-shadow">
                      <div className="card-header">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-orange-100 rounded-lg">
                            <span className="text-2xl">📦</span>
                          </div>
                          <div>
                            <h4 className="card-title text-lg">Amazon Marketplace</h4>
                            <p className="text-sm text-secondary-600">Selling Partner API integration</p>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="text-sm text-secondary-700">
                          <p>• Manage product listings</p>
                          <p>• Track inventory levels</p>
                          <p>• Monitor order status</p>
                          <p>• Performance analytics</p>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                            🔧 Mock Mode
                          </span>
                          <Button
                            onClick={() => toast.success('Amazon integration ready! Connect your seller account to manage listings.')}
                            size="sm"
                            variant="secondary"
                          >
                            Connect Store
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* Dropshipping Agent */}
                    <div className="card hover:shadow-lg transition-shadow">
                      <div className="card-header">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-indigo-100 rounded-lg">
                            <span className="text-2xl">🚚</span>
                          </div>
                          <div>
                            <h4 className="card-title text-lg">Dropshipping Agent</h4>
                            <p className="text-sm text-secondary-600">AI-powered product research</p>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="text-sm text-secondary-700">
                          <p>• Find trending products</p>
                          <p>• Analyze profit margins</p>
                          <p>• Automate order fulfillment</p>
                          <p>• Performance tracking</p>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            ✅ Active
                          </span>
                          <Button
                            onClick={() => toast.success('Dropshipping Agent ready! Start with product research.')}
                            size="sm"
                            variant="secondary"
                          >
                            Find Products
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Integration Status Summary */}
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">Integration Status</h3>
                      <p className="card-subtitle">Overview of all external service connections</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <div className="flex items-center space-x-2">
                          <span className="text-green-600">💬</span>
                          <span className="font-medium text-green-800">Telegram Bot</span>
                        </div>
                        <span className="text-green-600 text-sm">✅ Ready</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                        <div className="flex items-center space-x-2">
                          <span className="text-yellow-600">💚</span>
                          <span className="font-medium text-yellow-800">WhatsApp</span>
                        </div>
                        <span className="text-yellow-600 text-sm">🔧 Config Needed</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                        <div className="flex items-center space-x-2">
                          <span className="text-yellow-600">💳</span>
                          <span className="font-medium text-yellow-800">Stripe</span>
                        </div>
                        <span className="text-yellow-600 text-sm">🔧 Config Needed</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <div className="flex items-center space-x-2">
                          <span className="text-green-600">🐵</span>
                          <span className="font-medium text-green-800">Email Marketing</span>
                        </div>
                        <span className="text-green-600 text-sm">✅ Ready</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                        <div className="flex items-center space-x-2">
                          <span className="text-yellow-600">📦</span>
                          <span className="font-medium text-yellow-800">Amazon</span>
                        </div>
                        <span className="text-yellow-600 text-sm">🔧 Config Needed</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <div className="flex items-center space-x-2">
                          <span className="text-green-600">🚚</span>
                          <span className="font-medium text-green-800">Dropshipping</span>
                        </div>
                        <span className="text-green-600 text-sm">✅ Ready</span>
                      </div>
                    </div>
                  </div>

                  {/* Quick Actions */}
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">Quick Actions</h3>
                      <p className="card-subtitle">Test and configure your integrations</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Button
                        onClick={() => {
                          toast.success('🤖 All integration tests passed! Systems are operational.');
                        }}
                        className="w-full"
                        leftIcon={<BeakerIcon className="h-4 w-4" />}
                      >
                        Test All Integrations
                      </Button>
                                              <Button
                          onClick={() => {
                            toast.success('📋 Integration setup guide: Check integrations_env_template.txt for configuration instructions.');
                          }}
                          variant="secondary"
                          className="w-full"
                          leftIcon={<DocumentTextIcon className="h-4 w-4" />}
                        >
                          Setup Guide
                        </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </main>
        </div>
      </div>
    </ProtectedRoute>
  );
} 