'use client';

import { useEffect, useState } from 'react';
import { useAuthStore } from '@/store/auth';
import Sidebar from '@/components/layout/Sidebar';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import { Button } from '@/components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import {
  ShareIcon,
  ClipboardDocumentIcon,
  EyeIcon,
  CursorArrowRaysIcon,
  UserGroupIcon,
  CurrencyDollarIcon,
  ChartBarIcon,
  GiftIcon,
  CheckCircleIcon,
  PlusIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  ClockIcon,
  LinkIcon,
  TrophyIcon,
  BoltIcon,
  BanknotesIcon,
  UserPlusIcon
} from '@heroicons/react/24/outline';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import toast from 'react-hot-toast';

interface AffiliateAccount {
  affiliate_id: number;
  referral_code: string;
  referral_link: string;
  status: string;
  stats: {
    total_clicks: number;
    total_signups: number;
    total_sales: number;
    conversion_rate: number;
    total_commissions_earned: number;
    approved_commissions: number;
    paid_commissions: number;
    pending_commissions: number;
  };
  recent_referrals: any[];
  created_at: string;
}

interface Commission {
  id: number;
  type: string;
  amount: number;
  status: string;
  description: string;
  earned_at: string;
  approved_at?: string;
  paid_at?: string;
}

interface Referral {
  id: number;
  status: string;
  conversion_value: number;
  clicked_at: string;
  signup_at?: string;
  first_purchase_at?: string;
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
}

interface PerformanceReport {
  affiliate_id: number;
  period: string;
  performance: {
    clicks: number;
    referrals: number;
    commissions_earned: number;
    conversion_rate: number;
    click_trend: number;
  };
  insights: string[];
  recommendations: string[];
}

export default function AffiliatePage() {
  const { user, isAuthenticated } = useAuthStore();
  const [account, setAccount] = useState<AffiliateAccount | null>(null);
  const [commissions, setCommissions] = useState<Commission[]>([]);
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [report, setReport] = useState<PerformanceReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [registering, setRegistering] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'commissions' | 'referrals' | 'performance' | 'resources'>('overview');
  
  // Mock performance data for charts
  const performanceData = [
    { date: 'Mon', clicks: 25, conversions: 3, earnings: 75 },
    { date: 'Tue', clicks: 42, conversions: 6, earnings: 150 },
    { date: 'Wed', clicks: 18, conversions: 2, earnings: 50 },
    { date: 'Thu', clicks: 56, conversions: 8, earnings: 200 },
    { date: 'Fri', clicks: 38, conversions: 5, earnings: 125 },
    { date: 'Sat', clicks: 29, conversions: 4, earnings: 100 },
    { date: 'Sun', clicks: 33, conversions: 4, earnings: 100 }
  ];

  const commissionBreakdown = [
    { name: 'Signup Commissions', value: 60, color: '#6366F1' },
    { name: 'Sale Commissions', value: 35, color: '#10B981' },
    { name: 'Recurring Commissions', value: 5, color: '#F59E0B' }
  ];

  useEffect(() => {
    fetchAffiliateData();
  }, [isAuthenticated]);

  const fetchAffiliateData = async () => {
    if (!isAuthenticated) return;
    
    try {
      setLoading(true);
      
      // Try to get existing affiliate account
      const accountResponse = await fetch('http://localhost:8000/affiliate/account', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
        }
      });
      
      if (accountResponse.ok) {
        const accountData = await accountResponse.json();
        setAccount(accountData);
        
        // Fetch commissions and referrals in parallel
        const [commissionsResponse, referralsResponse, reportResponse] = await Promise.all([
          fetch('http://localhost:8000/affiliate/commissions', {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` }
          }),
          fetch('http://localhost:8000/affiliate/referrals', {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('auth_token')}` }
          }),
          fetch('http://localhost:8000/affiliate/report', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ days: 30 })
          })
        ]);
        
        if (commissionsResponse.ok) {
          const commissionsData = await commissionsResponse.json();
          setCommissions(commissionsData.commissions || []);
        }
        
        if (referralsResponse.ok) {
          const referralsData = await referralsResponse.json();
          setReferrals(referralsData.referrals || []);
        }
        
        if (reportResponse.ok) {
          const reportData = await reportResponse.json();
          setReport(reportData);
        }
      }
    } catch (error) {
      console.error('Failed to fetch affiliate data:', error);
    } finally {
      setLoading(false);
    }
  };

  const registerAffiliate = async () => {
    try {
      setRegistering(true);
      
      const response = await fetch('http://localhost:8000/affiliate/register', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.success) {
          toast.success('Affiliate account created successfully!');
          await fetchAffiliateData();
        } else {
          toast.error(data.error || 'Failed to create affiliate account');
        }
      } else {
        toast.error('Failed to create affiliate account');
      }
    } catch (error) {
      console.error('Failed to register affiliate:', error);
      toast.error('Failed to create affiliate account');
    } finally {
      setRegistering(false);
    }
  };

  const copyReferralLink = () => {
    if (account?.referral_link) {
      navigator.clipboard.writeText(account.referral_link);
      toast.success('Referral link copied to clipboard!');
    }
  };

  const shareReferralLink = () => {
    if (account?.referral_link && navigator.share) {
      navigator.share({
        title: 'Join LaunchMate DIAMOND',
        text: 'Check out this amazing AI-powered business management platform!',
        url: account.referral_link
      });
    } else {
      copyReferralLink();
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <ProtectedRoute>
        <div className="flex h-screen bg-secondary-50">
          <Sidebar />
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
              <p className="text-secondary-600">Loading affiliate dashboard...</p>
            </div>
          </div>
        </div>
      </ProtectedRoute>
    );
  }

  if (!account) {
    return (
      <ProtectedRoute>
        <div className="flex h-screen bg-secondary-50">
          <Sidebar />
          
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Header */}
            <header className="bg-white border-b border-secondary-200 px-6 py-4">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-secondary-900">Affiliate Program</h1>
                  <p className="text-secondary-600">Earn money by referring new users to LaunchMate DIAMOND</p>
                </div>
                <div className="flex items-center space-x-2">
                  <GiftIcon className="h-6 w-6 text-primary-600" />
                  <span className="text-sm font-medium text-primary-600">Join Our Affiliate Program</span>
                </div>
              </div>
            </header>

            {/* Main Content */}
            <main className="flex-1 overflow-y-auto p-6">
              <div className="max-w-4xl mx-auto">
                {/* Welcome Card */}
                <Card className="mb-8">
                  <CardContent className="p-8 text-center">
                    <div className="mb-6">
                      <div className="mx-auto h-16 w-16 bg-primary-100 rounded-full flex items-center justify-center mb-4">
                        <TrophyIcon className="h-8 w-8 text-primary-600" />
                      </div>
                      <h2 className="text-2xl font-bold text-secondary-900 mb-2">
                        Join the LaunchMate DIAMOND Affiliate Program
                      </h2>
                      <p className="text-lg text-secondary-600 mb-6">
                        Earn generous commissions by referring businesses to our AI-powered platform
                      </p>
                    </div>

                    <div className="grid md:grid-cols-3 gap-6 mb-8">
                      <div className="text-center">
                        <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                          <CurrencyDollarIcon className="h-6 w-6 text-green-600" />
                        </div>
                        <h3 className="font-semibold text-secondary-900 mb-1">$25 per Signup</h3>
                        <p className="text-sm text-secondary-600">Earn $25 for every user that signs up</p>
                      </div>
                      <div className="text-center">
                        <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                          <BanknotesIcon className="h-6 w-6 text-blue-600" />
                        </div>
                        <h3 className="font-semibold text-secondary-900 mb-1">20% Commission</h3>
                        <p className="text-sm text-secondary-600">Earn 20% on every sale you refer</p>
                      </div>
                      <div className="text-center">
                        <div className="h-12 w-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                          <ClockIcon className="h-6 w-6 text-purple-600" />
                        </div>
                        <h3 className="font-semibold text-secondary-900 mb-1">30-Day Cookies</h3>
                        <p className="text-sm text-secondary-600">Earn credit for 30 days after referral</p>
                      </div>
                    </div>

                    <Button
                      onClick={registerAffiliate}
                      disabled={registering}
                      size="lg"
                      className="px-8"
                    >
                      {registering ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Creating Account...
                        </>
                      ) : (
                        <>
                          <UserPlusIcon className="h-5 w-5 mr-2" />
                          Join Affiliate Program
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>

                {/* Benefits Grid */}
                <div className="grid md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <BoltIcon className="h-5 w-5 text-primary-600 mr-2" />
                        Easy to Get Started
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 text-secondary-600">
                        <li className="flex items-center">
                          <CheckCircleIcon className="h-4 w-4 text-green-500 mr-2" />
                          Get your unique referral link instantly
                        </li>
                        <li className="flex items-center">
                          <CheckCircleIcon className="h-4 w-4 text-green-500 mr-2" />
                          Share on social media, email, or website
                        </li>
                        <li className="flex items-center">
                          <CheckCircleIcon className="h-4 w-4 text-green-500 mr-2" />
                          Track your performance in real-time
                        </li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <ChartBarIcon className="h-5 w-5 text-primary-600 mr-2" />
                        Powerful Analytics
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2 text-secondary-600">
                        <li className="flex items-center">
                          <CheckCircleIcon className="h-4 w-4 text-green-500 mr-2" />
                          Detailed click and conversion tracking
                        </li>
                        <li className="flex items-center">
                          <CheckCircleIcon className="h-4 w-4 text-green-500 mr-2" />
                          AI-powered performance insights
                        </li>
                        <li className="flex items-center">
                          <CheckCircleIcon className="h-4 w-4 text-green-500 mr-2" />
                          Optimization recommendations
                        </li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </main>
          </div>
        </div>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="bg-white border-b border-secondary-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-secondary-900">Affiliate Dashboard</h1>
                <p className="text-secondary-600">Track your referrals and earnings</p>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant={account.status === 'active' ? 'success' : 'warning'}>
                  {account.status}
                </Badge>
              </div>
            </div>
          </header>

          {/* Tabs */}
          <div className="bg-white border-b border-secondary-200 px-6">
            <nav className="flex space-x-8">
              {[
                { id: 'overview', name: 'Overview', icon: ChartBarIcon },
                { id: 'commissions', name: 'Commissions', icon: CurrencyDollarIcon },
                { id: 'referrals', name: 'Referrals', icon: UserGroupIcon },
                { id: 'performance', name: 'Performance', icon: TrophyIcon },
                { id: 'resources', name: 'Resources', icon: LinkIcon }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-primary-500 text-primary-600'
                      : 'border-transparent text-secondary-500 hover:text-secondary-700 hover:border-secondary-300'
                  }`}
                >
                  <tab.icon className="h-5 w-5 mr-2" />
                  {tab.name}
                </button>
              ))}
            </nav>
          </div>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto p-6">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-secondary-600">Total Clicks</p>
                          <p className="text-3xl font-bold text-secondary-900">{account.stats.total_clicks}</p>
                        </div>
                        <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                          <EyeIcon className="h-6 w-6 text-blue-600" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-secondary-600">Signups</p>
                          <p className="text-3xl font-bold text-secondary-900">{account.stats.total_signups}</p>
                          <p className="text-sm text-green-600 flex items-center">
                            <ArrowUpIcon className="h-3 w-3 mr-1" />
                            {account.stats.conversion_rate.toFixed(1)}% conversion
                          </p>
                        </div>
                        <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
                          <UserPlusIcon className="h-6 w-6 text-green-600" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-secondary-600">Total Earned</p>
                          <p className="text-3xl font-bold text-secondary-900">
                            {formatCurrency(account.stats.total_commissions_earned)}
                          </p>
                        </div>
                        <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                          <CurrencyDollarIcon className="h-6 w-6 text-yellow-600" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-secondary-600">Pending</p>
                          <p className="text-3xl font-bold text-secondary-900">
                            {formatCurrency(account.stats.pending_commissions)}
                          </p>
                        </div>
                        <div className="h-12 w-12 bg-purple-100 rounded-lg flex items-center justify-center">
                          <ClockIcon className="h-6 w-6 text-purple-600" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Referral Link Card */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <LinkIcon className="h-5 w-5 text-primary-600 mr-2" />
                      Your Referral Link
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center space-x-4">
                      <div className="flex-1 p-3 bg-secondary-50 rounded-lg border">
                        <code className="text-sm text-secondary-900 break-all">
                          {account.referral_link}
                        </code>
                      </div>
                      <Button
                        onClick={copyReferralLink}
                        variant="outline"
                        size="sm"
                      >
                        <ClipboardDocumentIcon className="h-4 w-4 mr-2" />
                        Copy
                      </Button>
                      <Button
                        onClick={shareReferralLink}
                        size="sm"
                      >
                        <ShareIcon className="h-4 w-4 mr-2" />
                        Share
                      </Button>
                    </div>
                    <p className="text-sm text-secondary-600 mt-2">
                      Referral Code: <code className="bg-secondary-100 px-1 rounded">{account.referral_code}</code>
                    </p>
                  </CardContent>
                </Card>

                {/* Performance Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle>Performance Overview</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={performanceData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Line 
                            type="monotone" 
                            dataKey="clicks" 
                            stroke="#6366F1" 
                            strokeWidth={2}
                            name="Clicks"
                          />
                          <Line 
                            type="monotone" 
                            dataKey="conversions" 
                            stroke="#10B981" 
                            strokeWidth={2}
                            name="Conversions"
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === 'commissions' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Commission Breakdown</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={commissionBreakdown}
                              cx="50%"
                              cy="50%"
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                              label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                            >
                              {commissionBreakdown.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                            <Tooltip />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="lg:col-span-2">
                    <CardHeader>
                      <CardTitle>Recent Commissions</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {commissions.length > 0 ? commissions.slice(0, 5).map((commission) => (
                          <div key={commission.id} className="flex items-center justify-between p-4 bg-secondary-50 rounded-lg">
                            <div>
                              <p className="font-medium text-secondary-900">{commission.description}</p>
                              <p className="text-sm text-secondary-600">
                                {formatDate(commission.earned_at)} • {commission.type}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="font-bold text-green-600">{formatCurrency(commission.amount)}</p>
                              <Badge
                                variant={
                                  commission.status === 'paid' ? 'success' :
                                  commission.status === 'approved' ? 'warning' : 'secondary'
                                }
                              >
                                {commission.status}
                              </Badge>
                            </div>
                          </div>
                        )) : (
                          <div className="text-center py-8">
                            <CurrencyDollarIcon className="h-12 w-12 text-secondary-400 mx-auto mb-4" />
                            <p className="text-secondary-600">No commissions yet. Start referring users!</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {activeTab === 'referrals' && (
              <Card>
                <CardHeader>
                  <CardTitle>Referral History</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {referrals.length > 0 ? referrals.map((referral) => (
                      <div key={referral.id} className="flex items-center justify-between p-4 bg-secondary-50 rounded-lg">
                        <div>
                          <p className="font-medium text-secondary-900">
                            Referral #{referral.id}
                          </p>
                          <p className="text-sm text-secondary-600">
                            Clicked: {formatDate(referral.clicked_at)}
                            {referral.signup_at && ` • Signed up: ${formatDate(referral.signup_at)}`}
                          </p>
                          {(referral.utm_source || referral.utm_medium) && (
                            <p className="text-xs text-secondary-500">
                              Source: {referral.utm_source} • Medium: {referral.utm_medium}
                            </p>
                          )}
                        </div>
                        <div className="text-right">
                          <Badge
                            variant={
                              referral.status === 'converted' ? 'success' :
                              referral.status === 'signed_up' ? 'warning' : 'secondary'
                            }
                          >
                            {referral.status}
                          </Badge>
                          {referral.conversion_value > 0 && (
                            <p className="text-sm text-green-600 mt-1">
                              {formatCurrency(referral.conversion_value)}
                            </p>
                          )}
                        </div>
                      </div>
                    )) : (
                      <div className="text-center py-8">
                        <UserGroupIcon className="h-12 w-12 text-secondary-400 mx-auto mb-4" />
                        <p className="text-secondary-600">No referrals yet. Share your link to get started!</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'performance' && report && (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Performance Report ({report.period})</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                      <div className="p-4 bg-blue-50 rounded-lg">
                        <p className="text-sm font-medium text-blue-600">Clicks</p>
                        <p className="text-2xl font-bold text-blue-900">{report.performance.clicks}</p>
                      </div>
                      <div className="p-4 bg-green-50 rounded-lg">
                        <p className="text-sm font-medium text-green-600">Conversions</p>
                        <p className="text-2xl font-bold text-green-900">{report.performance.referrals}</p>
                      </div>
                      <div className="p-4 bg-yellow-50 rounded-lg">
                        <p className="text-sm font-medium text-yellow-600">Conversion Rate</p>
                        <p className="text-2xl font-bold text-yellow-900">{report.performance.conversion_rate.toFixed(1)}%</p>
                      </div>
                      <div className="p-4 bg-purple-50 rounded-lg">
                        <p className="text-sm font-medium text-purple-600">Earnings</p>
                        <p className="text-2xl font-bold text-purple-900">{formatCurrency(report.performance.commissions_earned)}</p>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-lg font-semibold text-secondary-900 mb-4">AI Insights</h3>
                        <div className="space-y-2">
                          {report.insights.map((insight, index) => (
                            <div key={index} className="flex items-start space-x-2">
                              <BoltIcon className="h-4 w-4 text-primary-600 mt-1 flex-shrink-0" />
                              <p className="text-sm text-secondary-700">{insight}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Recommendations</h3>
                        <div className="space-y-2">
                          {report.recommendations.map((recommendation, index) => (
                            <div key={index} className="flex items-start space-x-2">
                              <CheckCircleIcon className="h-4 w-4 text-green-600 mt-1 flex-shrink-0" />
                              <p className="text-sm text-secondary-700">{recommendation}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === 'resources' && (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Marketing Resources</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Social Media Templates</h3>
                        <div className="space-y-3">
                          <div className="p-3 border rounded-lg">
                            <p className="text-sm text-secondary-700 mb-2">
                              "Just discovered LaunchMate DIAMOND - an AI-powered platform that's revolutionizing business management! 🚀 Check it out: [YOUR_LINK]"
                            </p>
                            <Button size="sm" variant="outline">Copy Template</Button>
                          </div>
                          <div className="p-3 border rounded-lg">
                            <p className="text-sm text-secondary-700 mb-2">
                              "Automate your marketing, manage campaigns, and grow your business with AI. Try LaunchMate DIAMOND: [YOUR_LINK] #AIMarketing #BusinessGrowth"
                            </p>
                            <Button size="sm" variant="outline">Copy Template</Button>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-semibold text-secondary-900 mb-4">Email Templates</h3>
                        <div className="space-y-3">
                          <div className="p-3 border rounded-lg">
                            <p className="text-sm font-bold text-secondary-900 mb-1">Subject: Transform Your Business with AI</p>
                            <p className="text-sm text-secondary-700 mb-2">
                              Hi [Name], I wanted to share an amazing platform I've been using to automate my business processes...
                            </p>
                            <Button size="sm" variant="outline">View Full Template</Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </main>
        </div>
      </div>
    </ProtectedRoute>
  );
} 