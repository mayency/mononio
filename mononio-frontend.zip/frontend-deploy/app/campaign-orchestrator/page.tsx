'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import { Label } from '@/components/ui/Label';
import { Badge } from '@/components/ui/Badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/Tabs';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import Sidebar from '@/components/layout/Sidebar';
import { 
  Play, 
  Settings, 
  BarChart3, 
  CheckCircle, 
  AlertCircle, 
  Brain, 
  Target, 
  TrendingUp,
  Calendar,
  DollarSign,
  Users,
  Globe,
  Zap,
  FileText,
  Image,
  Video,
  Share2,
  Eye,
  MousePointer,
  Heart
} from 'lucide-react';
import apiClient from '@/lib/api';

interface CampaignTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: string;
  defaultData: any;
}

interface PerformanceMetrics {
  impressions: number;
  clicks: number;
  conversions: number;
  spend: number;
  ctr: number;
  cpc: number;
  cpm: number;
  roas: number;
}

export default function CampaignOrchestratorPage() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('create');
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [orchestratorStatus, setOrchestratorStatus] = useState<any>(null);
  const [campaigns, setCampaigns] = useState<any[]>([]);
  const [performanceData, setPerformanceData] = useState<PerformanceMetrics | null>(null);
  
  const [formData, setFormData] = useState({
    business_name: '',
    industry: '',
    target_audience: '',
    budget: 1000,
    goals: ['lead_generation'],
    platforms: ['facebook', 'google'],
    campaign_duration: 30,
    brand_voice: 'professional',
    location: 'United States',
    ai_provider: 'openai',
    // Enhanced fields
    business_description: '',
    unique_value_proposition: '',
    competitor_analysis: '',
    target_demographics: {
      age_range: '25-45',
      gender: 'all',
      income_level: 'middle',
      interests: []
    },
    content_preferences: {
      video_content: true,
      image_content: true,
      text_content: true,
      interactive_content: false
    },
    campaign_objectives: {
      awareness: false,
      consideration: false,
      conversion: false,
      retention: false
    },
    budget_allocation: {
      facebook: 0.4,
      google: 0.3,
      tiktok: 0.2,
      linkedin: 0.1
    },
    creative_requirements: {
      brand_colors: '',
      logo_url: '',
      style_preferences: '',
      tone_of_voice: ''
    }
  });

  const campaignTemplates: CampaignTemplate[] = [
    {
      id: 'ecommerce-launch',
      name: 'E-commerce Product Launch',
      description: 'Perfect for launching new products with conversion-focused campaigns',
      category: 'E-commerce',
      icon: '🛍️',
      defaultData: {
        industry: 'ecommerce',
        goals: ['conversions', 'sales'],
        platforms: ['facebook', 'google', 'instagram'],
        campaign_duration: 45,
        content_preferences: {
          video_content: true,
          image_content: true,
          text_content: true,
          interactive_content: true
        },
        campaign_objectives: {
          awareness: true,
          consideration: true,
          conversion: true,
          retention: false
        }
      }
    },
    {
      id: 'b2b-lead-generation',
      name: 'B2B Lead Generation',
      description: 'Target business decision makers with professional content',
      category: 'B2B',
      icon: '💼',
      defaultData: {
        industry: 'consulting',
        goals: ['lead_generation', 'brand_awareness'],
        platforms: ['linkedin', 'google'],
        campaign_duration: 60,
        content_preferences: {
          video_content: true,
          image_content: true,
          text_content: true,
          interactive_content: false
        },
        campaign_objectives: {
          awareness: true,
          consideration: true,
          conversion: true,
          retention: false
        }
      }
    },
    {
      id: 'startup-growth',
      name: 'Startup Growth Campaign',
      description: 'Rapid user acquisition for innovative products',
      category: 'Startup',
      icon: '🚀',
      defaultData: {
        industry: 'technology',
        goals: ['user_acquisition', 'brand_awareness'],
        platforms: ['facebook', 'google', 'tiktok'],
        campaign_duration: 30,
        content_preferences: {
          video_content: true,
          image_content: true,
          text_content: true,
          interactive_content: true
        },
        campaign_objectives: {
          awareness: true,
          consideration: true,
          conversion: true,
          retention: true
        }
      }
    },
    {
      id: 'local-business',
      name: 'Local Business Promotion',
      description: 'Drive foot traffic and local engagement',
      category: 'Local',
      icon: '🏪',
      defaultData: {
        industry: 'retail',
        goals: ['local_awareness', 'foot_traffic'],
        platforms: ['facebook', 'google', 'instagram'],
        campaign_duration: 30,
        content_preferences: {
          video_content: false,
          image_content: true,
          text_content: true,
          interactive_content: false
        },
        campaign_objectives: {
          awareness: true,
          consideration: true,
          conversion: true,
          retention: false
        }
      }
    }
  ];

  useEffect(() => {
    loadOrchestratorStatus();
    loadCampaigns();
  }, []);

  const loadOrchestratorStatus = async () => {
    try {
      const status = await apiClient.getOrchestratorStatus();
      setOrchestratorStatus(status.orchestrator_status);
    } catch (error) {
      console.error('Error loading orchestrator status:', error);
    }
  };

  const loadCampaigns = async () => {
    try {
      const response = await apiClient.getAllOrchestratorCampaigns();
      if (response.success) {
        setCampaigns(response.campaigns || []);
      }
    } catch (error) {
      console.error('Error loading campaigns:', error);
    }
  };

  const selectTemplate = (template: CampaignTemplate) => {
    setSelectedTemplate(template.id);
    setFormData(prev => ({
      ...prev,
      ...template.defaultData
    }));
  };

  const createCampaign = async () => {
    try {
      setLoading(true);
      const response = await apiClient.createOrchestratedCampaign(formData);
      setResult(response);
      
      if (response.success) {
        alert('Campaign created successfully!');
        loadCampaigns(); // Refresh campaigns list
      } else {
        alert('Failed to create campaign: ' + response.error);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Error creating campaign');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: keyof typeof formData, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleNestedInputChange = (parent: keyof typeof formData, field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [parent]: {
        ...(prev[parent] as any),
        [field]: value
      }
    }));
  };

  const getPerformanceMetrics = async (campaignId: string) => {
    try {
      // This would call a real analytics API
      const mockMetrics: PerformanceMetrics = {
        impressions: 15420,
        clicks: 1234,
        conversions: 89,
        spend: 2340.50,
        ctr: 8.0,
        cpc: 1.90,
        cpm: 15.20,
        roas: 3.2
      };
      setPerformanceData(mockMetrics);
    } catch (error) {
      console.error('Error loading performance metrics:', error);
    }
  };

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-gray-50">
        <Sidebar />
        <div className="flex-1 overflow-auto">
          <div className="p-6">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-gray-900">Campaign Orchestrator</h1>
              <p className="text-gray-600 mt-2">
                AI-powered marketing campaign creation with advanced analytics
              </p>
            </div>

            {/* AI Agent Status */}
            {orchestratorStatus && (
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="w-5 h-5" />
                    AI Agent Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {orchestratorStatus?.capabilities ? Object.entries(orchestratorStatus.capabilities).map(([agent, available]) => (
                      <div key={agent} className="flex items-center gap-2">
                        {available ? (
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-red-500" />
                        )}
                        <span className="text-sm capitalize">{agent.replace('_', ' ')}</span>
                      </div>
                    )) : (
                      <div className="text-gray-500">No agent status available</div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="create">Create Campaign</TabsTrigger>
                <TabsTrigger value="templates">Templates</TabsTrigger>
                <TabsTrigger value="campaigns">My Campaigns</TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
              </TabsList>

              <TabsContent value="create" className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Play className="w-5 h-5" />
                        Campaign Details
                      </CardTitle>
                      <CardDescription>
                        Fill in your business details to create an AI-powered campaign
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label htmlFor="business_name">Business Name *</Label>
                        <Input
                          id="business_name"
                          value={formData.business_name}
                          onChange={(e) => handleInputChange('business_name', e.target.value)}
                          placeholder="Enter your business name"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="business_description">Business Description</Label>
                        <textarea
                          id="business_description"
                          value={formData.business_description}
                          onChange={(e) => handleInputChange('business_description', e.target.value)}
                          placeholder="Describe your business, products, and services"
                          className="w-full p-2 border border-gray-300 rounded-md"
                          rows={3}
                        />
                      </div>

                      <div>
                        <Label htmlFor="industry">Industry *</Label>
                        <select
                          id="industry"
                          value={formData.industry}
                          onChange={(e) => handleInputChange('industry', e.target.value)}
                          className="w-full p-2 border border-gray-300 rounded-md"
                        >
                          <option value="">Select Industry</option>
                          <option value="ecommerce">E-commerce</option>
                          <option value="technology">Technology</option>
                          <option value="consulting">Consulting</option>
                          <option value="healthcare">Healthcare</option>
                          <option value="education">Education</option>
                          <option value="finance">Finance</option>
                          <option value="retail">Retail</option>
                          <option value="real_estate">Real Estate</option>
                          <option value="food_beverage">Food & Beverage</option>
                          <option value="fitness">Fitness</option>
                        </select>
                      </div>

                      <div>
                        <Label htmlFor="target_audience">Target Audience *</Label>
                        <Input
                          id="target_audience"
                          value={formData.target_audience}
                          onChange={(e) => handleInputChange('target_audience', e.target.value)}
                          placeholder="e.g., small business owners, tech professionals"
                        />
                      </div>

                      <div>
                        <Label htmlFor="unique_value_proposition">Unique Value Proposition</Label>
                        <Input
                          id="unique_value_proposition"
                          value={formData.unique_value_proposition}
                          onChange={(e) => handleInputChange('unique_value_proposition', e.target.value)}
                          placeholder="What makes your business unique?"
                        />
                      </div>

                      <div>
                        <Label htmlFor="budget">Budget ($) *</Label>
                        <Input
                          id="budget"
                          type="number"
                          value={formData.budget}
                          onChange={(e) => handleInputChange('budget', parseFloat(e.target.value))}
                          min="100"
                          step="100"
                        />
                      </div>

                      <div>
                        <Label htmlFor="campaign_duration">Campaign Duration (days)</Label>
                        <Input
                          id="campaign_duration"
                          type="number"
                          value={formData.campaign_duration}
                          onChange={(e) => handleInputChange('campaign_duration', parseInt(e.target.value))}
                          min="7"
                          max="365"
                        />
                      </div>

                      <div>
                        <Label htmlFor="brand_voice">Brand Voice</Label>
                        <select
                          id="brand_voice"
                          value={formData.brand_voice}
                          onChange={(e) => handleInputChange('brand_voice', e.target.value)}
                          className="w-full p-2 border border-gray-300 rounded-md"
                        >
                          <option value="professional">Professional</option>
                          <option value="casual">Casual</option>
                          <option value="friendly">Friendly</option>
                          <option value="authoritative">Authoritative</option>
                          <option value="humorous">Humorous</option>
                          <option value="inspirational">Inspirational</option>
                        </select>
                      </div>

                      <div>
                        <Label htmlFor="ai_provider">AI Provider</Label>
                        <select
                          id="ai_provider"
                          value={formData.ai_provider}
                          onChange={(e) => handleInputChange('ai_provider', e.target.value)}
                          className="w-full p-2 border border-gray-300 rounded-md"
                        >
                          <option value="openai">OpenAI GPT-4</option>
                          <option value="anthropic">Anthropic Claude</option>
                          <option value="google">Google Gemini</option>
                        </select>
                      </div>

                      <Button 
                        onClick={createCampaign} 
                        disabled={loading || !formData.business_name || !formData.industry || !formData.target_audience}
                        className="w-full"
                      >
                        {loading ? 'Creating Campaign...' : 'Create AI-Powered Campaign'}
                      </Button>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <BarChart3 className="w-5 h-5" />
                        Campaign Result
                      </CardTitle>
                      <CardDescription>
                        View the results of your campaign creation
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {result ? (
                        <div className="space-y-4">
                          <div className="flex items-center gap-2">
                            {result.success ? (
                              <CheckCircle className="w-5 h-5 text-green-500" />
                            ) : (
                              <AlertCircle className="w-5 h-5 text-red-500" />
                            )}
                            <span className="font-medium">
                              {result.success ? 'Success' : 'Failed'}
                            </span>
                          </div>
                          
                          {result.success && (
                            <div className="space-y-3">
                              <div>
                                <span className="font-medium">Campaign ID:</span>
                                <p className="text-sm text-gray-600 font-mono">{result.campaign_id}</p>
                              </div>
                              <div>
                                <span className="font-medium">Execution Time:</span>
                                <p className="text-sm text-gray-600">{result.execution_time?.toFixed(3)}s</p>
                              </div>
                              <div>
                                <span className="font-medium">Platforms Deployed:</span>
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {result.campaign_deployment?.platforms_deployed?.map((platform: string) => (
                                    <Badge key={platform} variant="secondary">{platform}</Badge>
                                  ))}
                                </div>
                              </div>
                              <div>
                                <span className="font-medium">AI Agents Used:</span>
                                <div className="text-sm text-gray-600 mt-1">
                                  {result.customer_analysis && <Badge variant="outline">Analysis</Badge>}
                                  {result.audience_research && <Badge variant="outline">Research</Badge>}
                                  {result.campaign_strategy && <Badge variant="outline">Strategy</Badge>}
                                  {result.content_assets && <Badge variant="outline">Content</Badge>}
                                  {result.video_content && <Badge variant="outline">Video</Badge>}
                                </div>
                              </div>
                            </div>
                          )}
                          
                          {!result.success && (
                            <div className="text-red-600">
                              <p><strong>Error:</strong> {result.error}</p>
                            </div>
                          )}
                        </div>
                      ) : (
                        <p className="text-gray-500">No campaign created yet</p>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="templates" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="w-5 h-5" />
                      Campaign Templates
                    </CardTitle>
                    <CardDescription>
                      Choose from pre-built campaign templates to get started quickly
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {campaignTemplates.map((template) => (
                        <Card 
                          key={template.id}
                          className={`cursor-pointer transition-all ${
                            selectedTemplate === template.id 
                              ? 'ring-2 ring-blue-500 bg-blue-50' 
                              : 'hover:shadow-md'
                          }`}
                          onClick={() => selectTemplate(template)}
                        >
                          <CardContent className="p-4">
                            <div className="flex items-center gap-3">
                              <span className="text-2xl">{template.icon}</span>
                              <div className="flex-1">
                                <h3 className="font-semibold">{template.name}</h3>
                                <p className="text-sm text-gray-600">{template.description}</p>
                                <Badge variant="secondary" className="mt-2">{template.category}</Badge>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="campaigns" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Target className="w-5 h-5" />
                      My Campaigns
                    </CardTitle>
                    <CardDescription>
                      View and manage your created campaigns
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {campaigns.length > 0 ? (
                      <div className="space-y-4">
                        {campaigns.map((campaign) => (
                          <Card key={campaign.campaign_id}>
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <h3 className="font-semibold">{campaign.campaign_id}</h3>
                                  <p className="text-sm text-gray-600">
                                    Created: {new Date(campaign.created_at).toLocaleDateString()}
                                  </p>
                                  <div className="flex gap-2 mt-2">
                                    <Badge variant={campaign.success ? "default" : "destructive"}>
                                      {campaign.success ? "Success" : "Failed"}
                                    </Badge>
                                    {campaign.campaign_deployment?.platforms_deployed?.map((platform: string) => (
                                      <Badge key={platform} variant="outline">{platform}</Badge>
                                    ))}
                                  </div>
                                </div>
                                <Button
                                  size="sm"
                                  onClick={() => getPerformanceMetrics(campaign.campaign_id)}
                                >
                                  View Analytics
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500">No campaigns created yet</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="analytics" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5" />
                      Performance Analytics
                    </CardTitle>
                    <CardDescription>
                      Monitor your campaign performance and ROI
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {performanceData ? (
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="text-center p-4 bg-blue-50 rounded-lg">
                          <Eye className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                          <div className="text-2xl font-bold">{performanceData.impressions.toLocaleString()}</div>
                          <div className="text-sm text-gray-600">Impressions</div>
                        </div>
                        <div className="text-center p-4 bg-green-50 rounded-lg">
                          <MousePointer className="w-6 h-6 mx-auto mb-2 text-green-600" />
                          <div className="text-2xl font-bold">{performanceData.clicks.toLocaleString()}</div>
                          <div className="text-sm text-gray-600">Clicks</div>
                        </div>
                        <div className="text-center p-4 bg-purple-50 rounded-lg">
                          <CheckCircle className="w-6 h-6 mx-auto mb-2 text-purple-600" />
                          <div className="text-2xl font-bold">{performanceData.conversions}</div>
                          <div className="text-sm text-gray-600">Conversions</div>
                        </div>
                        <div className="text-center p-4 bg-orange-50 rounded-lg">
                          <DollarSign className="w-6 h-6 mx-auto mb-2 text-orange-600" />
                          <div className="text-2xl font-bold">${performanceData.spend.toFixed(2)}</div>
                          <div className="text-sm text-gray-600">Spend</div>
                        </div>
                      </div>
                    ) : (
                      <p className="text-gray-500">Select a campaign to view performance metrics</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </ProtectedRoute>
  );
} 