"use client";

import { useState } from "react";

export default function PlaybookWorkflowPage() {
  const [form, setForm] = useState({
    business_goal: "",
    target_audience: "",
    timeline: "",
    budget: "",
    priority: "medium",
    user_id: "demo-user-1",
    business_id: "demo-business-1",
    auto_execute: false,
    ai_provider: "openai",
  });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === "checkbox") {
      const checked = (e.target as HTMLInputElement).checked;
      setForm((prev) => ({
        ...prev,
        [name]: checked,
      }));
    } else {
      setForm((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const res = await fetch("http://localhost:8000/api/v1/playbook/workflow", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error || data.message);
      setResult(data);
    } catch (err: any) {
      setError(err.message || "Unknown error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-8">
      <h1 className="text-2xl font-bold mb-6">🚀 Playbook Workflow Automation</h1>
      <form onSubmit={handleSubmit} className="space-y-4 bg-white p-6 rounded shadow">
        <div>
          <label className="block font-semibold mb-1">Business Goal</label>
          <input name="business_goal" value={form.business_goal} onChange={handleChange} required className="w-full border p-2 rounded" />
        </div>
        <div>
          <label className="block font-semibold mb-1">Target Audience</label>
          <input name="target_audience" value={form.target_audience} onChange={handleChange} className="w-full border p-2 rounded" />
        </div>
        <div>
          <label className="block font-semibold mb-1">Timeline</label>
          <input name="timeline" value={form.timeline} onChange={handleChange} className="w-full border p-2 rounded" />
        </div>
        <div>
          <label className="block font-semibold mb-1">Budget</label>
          <input name="budget" value={form.budget} onChange={handleChange} className="w-full border p-2 rounded" />
        </div>
        <div>
          <label className="block font-semibold mb-1">Priority</label>
          <select name="priority" value={form.priority} onChange={handleChange} className="w-full border p-2 rounded">
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </div>
        <div>
          <label className="block font-semibold mb-1">AI Provider</label>
          <select name="ai_provider" value={form.ai_provider} onChange={handleChange} className="w-full border p-2 rounded">
            <option value="openai">OpenAI</option>
            <option value="anthropic">Anthropic</option>
            <option value="google">Google</option>
          </select>
        </div>
        <div className="flex items-center">
          <input type="checkbox" name="auto_execute" checked={form.auto_execute} onChange={handleChange} className="mr-2" />
          <label className="font-semibold">Auto Execute Tasks</label>
        </div>
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700" disabled={loading}>
          {loading ? "Processing..." : "Trigger Workflow"}
        </button>
      </form>

      {error && <div className="mt-4 text-red-600">❌ {error}</div>}
      {result && (
        <div className="mt-8 bg-gray-50 p-6 rounded shadow">
          <h2 className="text-lg font-bold mb-2">Workflow Created</h2>
          <div className="mb-2"><b>Workflow ID:</b> {result.workflow_id}</div>
          <div className="mb-2"><b>Tasks Created:</b> {result.tasks_created}</div>
          <div className="mb-2"><b>Business Goal:</b> {result.workflow_plan?.business_goal}</div>
          <div className="mb-2"><b>Modules:</b></div>
          <ul className="list-disc ml-6">
            {result.workflow_plan?.modules?.map((mod: any, idx: number) => (
              <li key={mod.module_id} className="mb-1">
                <b>{mod.module_name}</b> <span className="text-xs text-gray-500">(Agent: {mod.primary_agent}, Est. {mod.estimated_duration}h)</span>
                <div className="text-sm text-gray-700">{mod.action_item}</div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
} 