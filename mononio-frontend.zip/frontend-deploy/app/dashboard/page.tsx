'use client';

import { useEffect, useState } from 'react';
import { useAuthStore } from '@/store/auth';
import { DashboardStats, Campaign } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import {
  BuildingOfficeIcon,
  MegaphoneIcon,
  UserGroupIcon,
  CurrencyDollarIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  ChartBarIcon,
  EyeIcon,
  CursorArrowRaysIcon,
  FireIcon,
  ClockIcon,
  GlobeAltIcon,
  SparklesIcon,
  BoltIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  XCircleIcon,
  CogIcon,
} from '@heroicons/react/24/outline';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

interface AdvertisingMetrics {
  google_ads: {
    impressions: number;
    clicks: number;
    conversions: number;
    cost: number;
    ctr: number;
    cpc: number;
    roas: number;
    status: 'active' | 'paused' | 'error';
  };
  facebook_ads: {
    impressions: number;
    clicks: number;
    conversions: number;
    cost: number;
    ctr: number;
    cpc: number;
    roas: number;
    status: 'active' | 'paused' | 'error';
  };
  tiktok_ads: {
    impressions: number;
    clicks: number;
    conversions: number;
    cost: number;
    ctr: number;
    cpc: number;
    roas: number;
    status: 'active' | 'paused' | 'error';
  };
  total_spend: number;
  total_revenue: number;
  overall_roas: number;
  last_updated: string;
}

interface ABTestTrigger {
  test_id: string;
  test_name: string;
  trigger_type: 'ui' | 'telegram' | 'automated';
  trigger_time: string;
  status: 'running' | 'completed' | 'paused';
  variants_count: number;
  confidence_level: number;
  current_winner?: string;
}

interface DashboardData {
  advertising_metrics: AdvertisingMetrics;
  ab_test_triggers: ABTestTrigger[];
  webhook_events: Array<{
    source: string;
    event_type: string;
    timestamp: string;
    processed: boolean;
  }>;
}

export default function DashboardPage() {
  const { user, isAuthenticated } = useAuthStore();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('7d');
  const [refreshInterval, setRefreshInterval] = useState<NodeJS.Timeout | null>(null);
  const [data, setData] = useState<DashboardData | null>(null);

  // Agent-specific state
  const [optimizationTests, setOptimizationTests] = useState<any[]>([]);
  const [businessCoaching, setBusinessCoaching] = useState<any>(null);
  const [complianceStatus, setComplianceStatus] = useState<any>(null);
  const [financialAnalysis, setFinancialAnalysis] = useState<any>(null);
  const [monitoringStatus, setMonitoringStatus] = useState<any>(null);
  const [agentStatus, setAgentStatus] = useState<any>({});

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [statsData, campaignsData, analyticsData] = await Promise.all([
          apiClient.getDashboardStats(),
          apiClient.getCampaigns(),
          apiClient.getDashboardAnalytics(),
        ]);
        setStats(statsData);
        setCampaigns(campaignsData);
        setAnalytics(analyticsData);
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    const fetchAgentData = async () => {
      try {
        if (campaigns.length > 0 && campaigns[0].business_id) {
          const businessId = campaigns[0].business_id.toString();
          
          // Fetch optimization tests
          const optimizationResponse = await apiClient.getOptimizationTests(businessId);
          if (optimizationResponse.success) {
            setOptimizationTests(optimizationResponse.tests || []);
          }

          // Fetch business coaching
          const coachingResponse = await apiClient.getBusinessCoaching(businessId);
          if (coachingResponse.success) {
            setBusinessCoaching(coachingResponse.coaching);
          }

          // Fetch compliance status
          const complianceResponse = await apiClient.getComplianceStatus(businessId);
          if (complianceResponse.success) {
            setComplianceStatus(complianceResponse.compliance);
          }

          // Fetch financial analysis
          const financeResponse = await apiClient.getFinancialAnalysis(businessId);
          if (financeResponse.success) {
            setFinancialAnalysis(financeResponse.analysis);
          }

          // Fetch monitoring status
          const monitoringResponse = await apiClient.getMonitoringStatus(businessId);
          if (monitoringResponse.success) {
            setMonitoringStatus(monitoringResponse.status);
          }

          // Fetch agent status
          const statusResponse = await apiClient.getAllAgentsStatus();
          if (statusResponse.success) {
            setAgentStatus(statusResponse.agents || {});
          }
        }
      } catch (error) {
        console.error('Failed to fetch agent data:', error);
      }
    };

    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        const response = await fetch('http://localhost:8000/dashboard/analytics-enhanced', {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
          }
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch dashboard data');
        }
        
        const result = await response.json();
        setData(result);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    if (isAuthenticated) {
      fetchData();
      fetchAgentData();
      fetchDashboardData();
      
      // Set up real-time refresh every 30 seconds
      const interval = setInterval(() => {
        fetchData();
        fetchAgentData();
        fetchDashboardData();
      }, 30000);
      setRefreshInterval(interval);
    }

    return () => {
      if (refreshInterval) {
        clearInterval(refreshInterval);
      }
    };
  }, [isAuthenticated]);

  // Mock data for charts
  const performanceData = [
    { date: 'Mon', impressions: 1200, clicks: 180, conversions: 12, cost: 45 },
    { date: 'Tue', impressions: 1350, clicks: 210, conversions: 18, cost: 52 },
    { date: 'Wed', impressions: 1100, clicks: 165, conversions: 15, cost: 48 },
    { date: 'Thu', impressions: 1400, clicks: 225, conversions: 20, cost: 55 },
    { date: 'Fri', impressions: 1250, clicks: 195, conversions: 16, cost: 50 },
    { date: 'Sat', impressions: 900, clicks: 135, conversions: 10, cost: 35 },
    { date: 'Sun', impressions: 800, clicks: 120, conversions: 8, cost: 30 },
  ];

  const platformData = [
    { name: 'Facebook', value: 35, color: '#1877F2' },
    { name: 'Instagram', value: 25, color: '#E4405F' },
    { name: 'Google Ads', value: 20, color: '#4285F4' },
    { name: 'TikTok', value: 15, color: '#000000' },
    { name: 'LinkedIn', value: 5, color: '#0A66C2' },
  ];

  const conversionFunnelData = [
    { stage: 'Impressions', value: 10000, percentage: 100 },
    { stage: 'Clicks', value: 1200, percentage: 12 },
    { stage: 'Landing Page', value: 900, percentage: 9 },
    { stage: 'Add to Cart', value: 180, percentage: 1.8 },
    { stage: 'Purchase', value: 90, percentage: 0.9 },
  ];

  const statCards = [
    {
      name: 'Total Businesses',
      value: stats?.total_businesses || 0,
      icon: BuildingOfficeIcon,
      change: '+12%',
      changeType: 'positive' as const,
      trend: 'up',
    },
    {
      name: 'Active Campaigns',
      value: stats?.active_campaigns || 0,
      icon: MegaphoneIcon,
      change: '+8%',
      changeType: 'positive' as const,
      trend: 'up',
    },
    {
      name: 'Total Leads',
      value: stats?.total_leads || 0,
      icon: UserGroupIcon,
      change: '+23%',
      changeType: 'positive' as const,
      trend: 'up',
    },
    {
      name: 'Total Revenue',
      value: `$${(stats?.total_revenue || 0).toLocaleString()}`,
      icon: CurrencyDollarIcon,
      change: '+15%',
      changeType: 'positive' as const,
      trend: 'up',
    },
  ];

  const topPerformingCampaigns = campaigns
    .filter(campaign => campaign.status === 'active')
    .sort((a, b) => (b.conversions || 0) - (a.conversions || 0))
    .slice(0, 5);

  const recentActivities = stats?.recent_activities?.slice(0, 5) || [];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="bg-white border-b border-secondary-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-secondary-900">
                  Dashboard
                </h1>
                <p className="text-secondary-600">
                  Welcome back, {user?.name}! Here's what's happening with your businesses.
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-secondary-500">Time Range:</span>
                  <select
                    value={timeRange}
                    onChange={(e) => setTimeRange(e.target.value)}
                    className="text-sm border border-secondary-300 rounded px-2 py-1"
                  >
                    <option value="7d">Last 7 days</option>
                    <option value="30d">Last 30 days</option>
                    <option value="90d">Last 90 days</option>
                  </select>
                </div>
                <div className="text-right">
                  <p className="text-sm text-secondary-500">Last updated</p>
                  <p className="text-sm font-medium text-secondary-900">
                    {new Date().toLocaleTimeString()}
                  </p>
                </div>
              </div>
            </div>
          </header>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto p-6">
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {statCards.map((stat) => (
                    <div key={stat.name} className="stat-card">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="stat-label">{stat.name}</p>
                          <p className="stat-value">{stat.value}</p>
                          <p className={`stat-change ${stat.changeType}`}>
                            {stat.changeType === 'positive' ? (
                              <ArrowUpIcon className="inline h-3 w-3 mr-1" />
                            ) : (
                              <ArrowDownIcon className="inline h-3 w-3 mr-1" />
                            )}
                            {stat.change}
                          </p>
                        </div>
                        <div className="h-12 w-12 bg-primary-100 rounded-lg flex items-center justify-center">
                          <stat.icon className="h-6 w-6 text-primary-600" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Performance Charts */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Performance Over Time */}
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">Performance Over Time</h3>
                      <p className="card-subtitle">Campaign performance trends</p>
                    </div>
                    <div className="p-4">
                      <ResponsiveContainer width="100%" height={300}>
                        <AreaChart data={performanceData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Area
                            type="monotone"
                            dataKey="impressions"
                            stackId="1"
                            stroke="#8884d8"
                            fill="#8884d8"
                            fillOpacity={0.6}
                          />
                          <Area
                            type="monotone"
                            dataKey="clicks"
                            stackId="1"
                            stroke="#82ca9d"
                            fill="#82ca9d"
                            fillOpacity={0.6}
                          />
                          <Area
                            type="monotone"
                            dataKey="conversions"
                            stackId="1"
                            stroke="#ffc658"
                            fill="#ffc658"
                            fillOpacity={0.6}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Platform Distribution */}
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">Platform Distribution</h3>
                      <p className="card-subtitle">Budget allocation across platforms</p>
                    </div>
                    <div className="p-4">
                      <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={platformData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {platformData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                {/* Conversion Funnel */}
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Conversion Funnel</h3>
                    <p className="card-subtitle">Customer journey analysis</p>
                  </div>
                  <div className="p-4">
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={conversionFunnelData} layout="horizontal">
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis dataKey="stage" type="category" width={100} />
                        <Tooltip />
                        <Bar dataKey="value" fill="#8884d8" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Top Performing Campaigns & Recent Activity */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Top Performing Campaigns */}
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">Top Performing Campaigns</h3>
                      <p className="card-subtitle">Best performing campaigns this period</p>
                    </div>
                    <div className="space-y-4">
                      {topPerformingCampaigns.map((campaign) => (
                        <div key={campaign.id} className="flex items-center justify-between p-4 border border-secondary-200 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className="h-10 w-10 bg-primary-100 rounded-lg flex items-center justify-center">
                              <MegaphoneIcon className="h-5 w-5 text-primary-600" />
                            </div>
                            <div>
                              <p className="font-medium text-secondary-900">{campaign.name}</p>
                              <p className="text-sm text-secondary-600">{campaign.campaign_type}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-medium text-secondary-900">
                              {campaign.conversions || 0} conversions
                            </p>
                            <p className="text-sm text-secondary-600">
                              ${campaign.cost || 0} spent
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Recent Activity */}
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">Recent Activity</h3>
                      <p className="card-subtitle">Latest updates from your businesses</p>
                    </div>
                    <div className="space-y-4">
                      {recentActivities.map((activity) => (
                        <div key={activity.id} className="flex items-start space-x-3">
                          <div className="h-8 w-8 bg-primary-100 rounded-full flex items-center justify-center flex-shrink-0">
                            <span className="text-xs font-medium text-primary-700">
                              {activity.type.charAt(0).toUpperCase()}
                            </span>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-secondary-900">
                              {activity.description}
                            </p>
                            <p className="text-xs text-secondary-500">
                              {new Date(activity.timestamp).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Analytics & Automation Section */}
                {analytics && (
                  <>
                    {/* Overall Performance Metrics */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                      <div className="card">
                        <div className="card-header">
                          <h3 className="card-title text-sm">Overall CTR</h3>
                        </div>
                        <div className="p-4">
                          <p className="text-2xl font-bold text-secondary-900">
                            {analytics.overall_metrics?.overall_ctr || 0}%
                          </p>
                          <p className="text-sm text-secondary-600">Click-through rate</p>
                        </div>
                      </div>
                      
                      <div className="card">
                        <div className="card-header">
                          <h3 className="card-title text-sm">Conversion Rate</h3>
                        </div>
                        <div className="p-4">
                          <p className="text-2xl font-bold text-secondary-900">
                            {analytics.overall_metrics?.overall_conversion_rate || 0}%
                          </p>
                          <p className="text-sm text-secondary-600">Overall conversion</p>
                        </div>
                      </div>
                      
                      <div className="card">
                        <div className="card-header">
                          <h3 className="card-title text-sm">ROI</h3>
                        </div>
                        <div className="p-4">
                          <p className="text-2xl font-bold text-secondary-900">
                            {analytics.overall_metrics?.overall_roi || 0}x
                          </p>
                          <p className="text-sm text-secondary-600">Return on investment</p>
                        </div>
                      </div>
                      
                      <div className="card">
                        <div className="card-header">
                          <h3 className="card-title text-sm">CPC</h3>
                        </div>
                        <div className="p-4">
                          <p className="text-2xl font-bold text-secondary-900">
                            ${analytics.overall_metrics?.overall_cpc || 0}
                          </p>
                          <p className="text-sm text-secondary-600">Cost per click</p>
                        </div>
                      </div>
                      
                      <div className="card">
                        <div className="card-header">
                          <h3 className="card-title text-sm">CPM</h3>
                        </div>
                        <div className="p-4">
                          <p className="text-2xl font-bold text-secondary-900">
                            ${analytics.overall_metrics?.overall_cpm || 0}
                          </p>
                          <p className="text-sm text-secondary-600">Cost per 1000 impressions</p>
                        </div>
                      </div>
                    </div>

                    {/* Recent Optimizations & Automation Triggers */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {/* Recent Optimizations */}
                      <div className="card">
                        <div className="card-header">
                          <h3 className="card-title">Recent Optimizations</h3>
                          <p className="card-subtitle">AI-powered campaign improvements</p>
                        </div>
                        <div className="space-y-4">
                          {analytics.recent_optimizations?.slice(0, 5).map((optimization: any) => (
                            <div key={optimization.id} className="flex items-start space-x-3 p-3 border border-secondary-200 rounded-lg">
                              <div className="h-8 w-8 bg-success-100 rounded-full flex items-center justify-center flex-shrink-0">
                                <BoltIcon className="h-4 w-4 text-success-600" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center space-x-2 mb-1">
                                  <p className="text-sm font-medium text-secondary-900">
                                    {optimization.campaign_name}
                                  </p>
                                  <span className={`px-2 py-1 text-xs rounded-full ${
                                    optimization.impact === 'positive' 
                                      ? 'bg-success-100 text-success-700' 
                                      : 'bg-warning-100 text-warning-700'
                                  }`}>
                                    {optimization.impact}
                                  </span>
                                </div>
                                <p className="text-sm text-secondary-700 mb-1">
                                  {optimization.action_description}
                                </p>
                                <p className="text-xs text-secondary-500">
                                  Expected: {optimization.expected_improvement}
                                </p>
                                <p className="text-xs text-secondary-400">
                                  {new Date(optimization.timestamp).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Automation Triggers */}
                      <div className="card">
                        <div className="card-header">
                          <h3 className="card-title">Automation Triggers</h3>
                          <p className="card-subtitle">Recent rule-based actions</p>
                        </div>
                        <div className="space-y-4">
                          {analytics.automation_triggers?.slice(0, 5).map((trigger: any) => (
                            <div key={trigger.id} className="flex items-start space-x-3 p-3 border border-secondary-200 rounded-lg">
                              <div className="h-8 w-8 bg-warning-100 rounded-full flex items-center justify-center flex-shrink-0">
                                <ExclamationTriangleIcon className="h-4 w-4 text-warning-600" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center space-x-2 mb-1">
                                  <p className="text-sm font-medium text-secondary-900">
                                    {trigger.campaign_name}
                                  </p>
                                  <span className="px-2 py-1 text-xs rounded-full bg-warning-100 text-warning-700">
                                    {trigger.status}
                                  </span>
                                </div>
                                <p className="text-sm text-secondary-700 mb-1">
                                  {trigger.rule_name}: {trigger.trigger_value}
                                </p>
                                <p className="text-xs text-secondary-500">
                                  Action: {trigger.action_taken}
                                </p>
                                <p className="text-xs text-secondary-400">
                                  {new Date(trigger.timestamp).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Performance Trends Chart */}
                    <div className="card">
                      <div className="card-header">
                        <h3 className="card-title">Performance Trends</h3>
                        <p className="card-subtitle">Last 7 days performance</p>
                      </div>
                      <div className="p-4">
                        <ResponsiveContainer width="100%" height={300}>
                          <LineChart data={analytics.performance_trends?.daily_metrics || []}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="date" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="impressions" stroke="#8884d8" strokeWidth={2} />
                            <Line type="monotone" dataKey="clicks" stroke="#82ca9d" strokeWidth={2} />
                            <Line type="monotone" dataKey="conversions" stroke="#ffc658" strokeWidth={2} />
                            <Line type="monotone" dataKey="revenue" stroke="#ff7300" strokeWidth={2} />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* Automation Rules Status */}
                    <div className="card">
                      <div className="card-header">
                        <h3 className="card-title">Automation Rules Status</h3>
                        <p className="card-subtitle">Active rules across campaigns</p>
                      </div>
                      <div className="p-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                          <div className="text-center p-4 bg-secondary-50 rounded-lg">
                            <p className="text-2xl font-bold text-secondary-900">
                              {analytics.automation_rules_status?.total_rules || 0}
                            </p>
                            <p className="text-sm text-secondary-600">Total Rules</p>
                          </div>
                          <div className="text-center p-4 bg-success-50 rounded-lg">
                            <p className="text-2xl font-bold text-success-900">
                              {analytics.automation_rules_status?.active_rules || 0}
                            </p>
                            <p className="text-sm text-success-600">Active Rules</p>
                          </div>
                          <div className="text-center p-4 bg-primary-50 rounded-lg">
                            <p className="text-2xl font-bold text-primary-900">
                              {analytics.automation_rules_status?.rules_by_campaign?.length || 0}
                            </p>
                            <p className="text-sm text-primary-600">Campaigns with Rules</p>
                          </div>
                        </div>
                        
                        <div className="space-y-3">
                          {analytics.automation_rules_status?.rules_by_campaign?.map((campaign: any) => (
                            <div key={campaign.campaign_id} className="flex items-center justify-between p-3 border border-secondary-200 rounded-lg">
                              <div>
                                <p className="font-medium text-secondary-900">{campaign.campaign_name}</p>
                                <p className="text-sm text-secondary-600">
                                  {campaign.active_rules} of {campaign.total_rules} rules active
                                </p>
                              </div>
                              <div className="flex items-center space-x-2">
                                {campaign.rules?.map((rule: any) => (
                                  <span
                                    key={rule.id}
                                    className={`px-2 py-1 text-xs rounded-full ${
                                      rule.enabled 
                                        ? 'bg-success-100 text-success-700' 
                                        : 'bg-secondary-100 text-secondary-700'
                                    }`}
                                  >
                                    {rule.name}
                                  </span>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {/* Quick Actions */}
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Quick Actions</h3>
                    <p className="card-subtitle">Common tasks and shortcuts</p>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <button className="p-4 border border-secondary-200 rounded-lg hover:bg-secondary-50 transition-colors text-left">
                      <div className="h-8 w-8 bg-primary-100 rounded-lg flex items-center justify-center mb-2">
                        <BuildingOfficeIcon className="h-4 w-4 text-primary-600" />
                      </div>
                      <p className="text-sm font-medium text-secondary-900">Add Business</p>
                      <p className="text-xs text-secondary-500">Create new business</p>
                    </button>
                    
                    <button className="p-4 border border-secondary-200 rounded-lg hover:bg-secondary-50 transition-colors text-left">
                      <div className="h-8 w-8 bg-success-100 rounded-lg flex items-center justify-center mb-2">
                        <MegaphoneIcon className="h-4 w-4 text-success-600" />
                      </div>
                      <p className="text-sm font-medium text-secondary-900">New Campaign</p>
                      <p className="text-xs text-secondary-500">Start marketing campaign</p>
                    </button>
                    
                    <button className="p-4 border border-secondary-200 rounded-lg hover:bg-secondary-50 transition-colors text-left">
                      <div className="h-8 w-8 bg-warning-100 rounded-lg flex items-center justify-center mb-2">
                        <UserGroupIcon className="h-4 w-4 text-warning-600" />
                      </div>
                      <p className="text-sm font-medium text-secondary-900">Add Lead</p>
                      <p className="text-xs text-secondary-500">Capture new lead</p>
                    </button>
                    
                    <button className="p-4 border border-secondary-200 rounded-lg hover:bg-secondary-50 transition-colors text-left">
                      <div className="h-8 w-8 bg-secondary-100 rounded-lg flex items-center justify-center mb-2">
                        <CurrencyDollarIcon className="h-4 w-4 text-secondary-600" />
                      </div>
                      <p className="text-sm font-medium text-secondary-900">Add Expense</p>
                      <p className="text-xs text-secondary-500">Record business expense</p>
                    </button>
                  </div>
                </div>

                {/* Advertising Performance Section */}
                <div className="mb-8">
                  <h2 className="text-2xl font-semibold mb-4 flex items-center">
                    📊 Advertising Performance
                    <Badge variant="secondary" className="ml-2">Real-time</Badge>
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">Total Ad Spend</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold">${data?.advertising_metrics.total_spend?.toLocaleString() || '0'}</div>
                        <p className="text-xs text-gray-500">Across all platforms</p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">Total Revenue</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-green-600">${data?.advertising_metrics.total_revenue?.toLocaleString() || '0'}</div>
                        <p className="text-xs text-gray-500">From ad campaigns</p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">Overall ROAS</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-blue-600">{data?.advertising_metrics.overall_roas?.toFixed(2) || '0.00'}x</div>
                        <p className="text-xs text-gray-500">Return on ad spend</p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm font-medium text-gray-600">Last Updated</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-sm">{data?.advertising_metrics.last_updated ? new Date(data.advertising_metrics.last_updated).toLocaleTimeString() : 'Never'}</div>
                        <p className="text-xs text-gray-500">Auto-refreshes every 30s</p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Platform-specific metrics */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Google Ads */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center justify-between">
                          <span className="flex items-center">
                            🔍 Google Ads
                          </span>
                          <Badge variant={data?.advertising_metrics.google_ads.status === 'active' ? 'default' : 'secondary'}>
                            {data?.advertising_metrics.google_ads.status || 'inactive'}
                          </Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Impressions:</span>
                          <span>{data?.advertising_metrics.google_ads.impressions?.toLocaleString() || '0'}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Clicks:</span>
                          <span>{data?.advertising_metrics.google_ads.clicks?.toLocaleString() || '0'}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Conversions:</span>
                          <span>{data?.advertising_metrics.google_ads.conversions?.toLocaleString() || '0'}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>CTR:</span>
                          <span>{data?.advertising_metrics.google_ads.ctr?.toFixed(2) || '0.00'}%</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>CPC:</span>
                          <span>${data?.advertising_metrics.google_ads.cpc?.toFixed(2) || '0.00'}</span>
                        </div>
                        <div className="flex justify-between text-sm font-medium">
                          <span>ROAS:</span>
                          <span className="text-green-600">{data?.advertising_metrics.google_ads.roas?.toFixed(2) || '0.00'}x</span>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Facebook Ads */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center justify-between">
                          <span className="flex items-center">
                            📘 Facebook Ads
                          </span>
                          <Badge variant={data?.advertising_metrics.facebook_ads.status === 'active' ? 'default' : 'secondary'}>
                            {data?.advertising_metrics.facebook_ads.status || 'inactive'}
                          </Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Impressions:</span>
                          <span>{data?.advertising_metrics.facebook_ads.impressions?.toLocaleString() || '0'}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Clicks:</span>
                          <span>{data?.advertising_metrics.facebook_ads.clicks?.toLocaleString() || '0'}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Conversions:</span>
                          <span>{data?.advertising_metrics.facebook_ads.conversions?.toLocaleString() || '0'}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>CTR:</span>
                          <span>{data?.advertising_metrics.facebook_ads.ctr?.toFixed(2) || '0.00'}%</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>CPC:</span>
                          <span>${data?.advertising_metrics.facebook_ads.cpc?.toFixed(2) || '0.00'}</span>
                        </div>
                        <div className="flex justify-between text-sm font-medium">
                          <span>ROAS:</span>
                          <span className="text-green-600">{data?.advertising_metrics.facebook_ads.roas?.toFixed(2) || '0.00'}x</span>
                        </div>
                      </CardContent>
                    </Card>

                    {/* TikTok Ads */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center justify-between">
                          <span className="flex items-center">
                            🎵 TikTok Ads
                          </span>
                          <Badge variant={data?.advertising_metrics.tiktok_ads.status === 'active' ? 'default' : 'secondary'}>
                            {data?.advertising_metrics.tiktok_ads.status || 'inactive'}
                          </Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Impressions:</span>
                          <span>{data?.advertising_metrics.tiktok_ads.impressions?.toLocaleString() || '0'}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Clicks:</span>
                          <span>{data?.advertising_metrics.tiktok_ads.clicks?.toLocaleString() || '0'}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Conversions:</span>
                          <span>{data?.advertising_metrics.tiktok_ads.conversions?.toLocaleString() || '0'}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>CTR:</span>
                          <span>{data?.advertising_metrics.tiktok_ads.ctr?.toFixed(2) || '0.00'}%</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>CPC:</span>
                          <span>${data?.advertising_metrics.tiktok_ads.cpc?.toFixed(2) || '0.00'}</span>
                        </div>
                        <div className="flex justify-between text-sm font-medium">
                          <span>ROAS:</span>
                          <span className="text-green-600">{data?.advertising_metrics.tiktok_ads.roas?.toFixed(2) || '0.00'}x</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                {/* A/B Testing Activity */}
                <div className="mb-8">
                  <h2 className="text-2xl font-semibold mb-4 flex items-center">
                    🧪 A/B Testing Activity
                    <Badge variant="secondary" className="ml-2">Live</Badge>
                  </h2>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Recent A/B Test Triggers</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {data?.ab_test_triggers?.length ? (
                        <div className="space-y-3">
                          {data.ab_test_triggers.map((trigger, index) => (
                            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                              <div>
                                <div className="font-medium">{trigger.test_name}</div>
                                <div className="text-sm text-gray-600">
                                  Triggered via {trigger.trigger_type === 'ui' ? '🖥️ Dashboard' : trigger.trigger_type === 'telegram' ? '📱 Telegram' : '🤖 Automated'}
                                  • {trigger.variants_count} variants • {(trigger.confidence_level * 100).toFixed(0)}% confidence
                                </div>
                                <div className="text-xs text-gray-500">{new Date(trigger.trigger_time).toLocaleString()}</div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Badge variant={trigger.status === 'running' ? 'default' : trigger.status === 'completed' ? 'secondary' : 'outline'}>
                                  {trigger.status}
                                </Badge>
                                {trigger.current_winner && (
                                  <Badge variant="default">Winner: {trigger.current_winner}</Badge>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-gray-500">No A/B tests triggered recently. Start a test via the dashboard or Telegram bot!</p>
                      )}
                    </CardContent>
                  </Card>
                </div>

                {/* Webhook Events */}
                <div className="mb-8">
                  <h2 className="text-2xl font-semibold mb-4 flex items-center">
                    🔗 External Events
                    <Badge variant="secondary" className="ml-2">Webhooks</Badge>
                  </h2>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Recent Webhook Events</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {data?.webhook_events?.length ? (
                        <div className="space-y-2">
                          {data.webhook_events.slice(0, 10).map((event, index) => (
                            <div key={index} className="flex items-center justify-between p-2 border-b last:border-b-0">
                              <div>
                                <span className="font-medium">{event.source}</span>
                                <span className="text-gray-600 ml-2">{event.event_type}</span>
                              </div>
                              <div className="flex items-center space-x-2">
                                <span className="text-sm text-gray-500">{new Date(event.timestamp).toLocaleTimeString()}</span>
                                <Badge variant={event.processed ? 'default' : 'outline'}>
                                  {event.processed ? 'Processed' : 'Pending'}
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-gray-500">No recent webhook events. Configure webhooks to receive external notifications.</p>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </main>
        </div>
      </div>
    </ProtectedRoute>
  );
} 