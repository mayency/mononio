'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import { EnvelopeIcon, LockClosedIcon, EyeIcon, EyeSlashIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { getErrorMessage } from '@/lib/getErrorMessage';
import apiClient from '@/lib/api';

export default function DebugLoginPage() {
  const [email, setEmail] = useState('demo@launchmate.com');
  const [password, setPassword] = useState('demo123');
  const [showPassword, setShowPassword] = useState(false);
  const [debugLog, setDebugLog] = useState<string[]>([]);
  const router = useRouter();
  const { login, isLoading, error, clearError } = useAuthStore();

  const addLog = (message: string) => {
    setDebugLog(prev => [...prev, `${new Date().toISOString()}: ${message}`]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setDebugLog([]);
    addLog('📝 Form submitted');
    addLog(`📝 Email: ${email}`);
    addLog(`📝 Password: ${password ? '***' : 'empty'}`);
    
    clearError();

    if (!email || !password) {
      addLog('❌ Missing email or password');
      toast.error('Please fill in all fields');
      return;
    }

    addLog('🔐 Calling auth store login method...');
    
    try {
      // Test direct API call first
      addLog('🌐 Testing direct API call...');
      const directResponse = await apiClient.login({ email, password });
      addLog(`✅ Direct API call successful: ${JSON.stringify(directResponse, null, 2)}`);
    } catch (directError: any) {
      addLog(`❌ Direct API call failed: ${directError.message}`);
      addLog(`❌ Direct API error details: ${JSON.stringify(directError, null, 2)}`);
    }

    addLog('🔐 Now trying auth store login...');
    const success = await login(email, password);
    addLog(`🔐 Auth store login result: ${success}`);
    
    if (success) {
      addLog('✅ Login successful, redirecting to dashboard...');
      toast.success('Welcome to LaunchMate DIAMOND!');
      router.push('/dashboard');
    } else {
      addLog(`❌ Login failed`);
      addLog(`❌ Error object: ${JSON.stringify(error, null, 2)}`);
      addLog(`❌ Error message: ${getErrorMessage(error)}`);
      toast.error(getErrorMessage(error) || 'Login failed. Please check your credentials.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-secondary-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl w-full space-y-8">
        {/* Header */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-secondary-900">
            Debug Login
          </h2>
          <p className="mt-2 text-sm text-secondary-600">
            Debug version with detailed logging
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Login Form */}
          <div className="bg-white rounded-2xl shadow-xl border border-secondary-200 p-8">
            <form className="space-y-6" onSubmit={handleSubmit}>
              <Input
                label="Email address"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                leftIcon={<EnvelopeIcon />}
                required
              />

              <div className="relative">
                <Input
                  label="Password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  leftIcon={<LockClosedIcon />}
                  rightIcon={
                    <span className="text-secondary-400">
                      {showPassword ? <EyeSlashIcon /> : <EyeIcon />}
                    </span>
                  }
                  required
                />
              </div>

              {error && (
                <div className="bg-danger-50 border border-danger-200 rounded-lg p-3">
                  <p className="text-sm text-danger-600">{error}</p>
                </div>
              )}

              <Button
                type="submit"
                className="w-full"
                loading={isLoading}
                disabled={isLoading}
              >
                Sign in
              </Button>
            </form>

            {/* Demo Credentials */}
            <div className="mt-6 p-4 bg-secondary-50 rounded-lg">
              <h4 className="text-sm font-medium text-secondary-900 mb-2">
                Demo Account
              </h4>
              <p className="text-xs text-secondary-600">
                Email: demo@launchmate.com
                <br />
                Password: demo123
              </p>
            </div>
          </div>

          {/* Debug Log */}
          <div className="bg-white rounded-2xl shadow-xl border border-secondary-200 p-8">
            <h3 className="text-lg font-semibold mb-4">Debug Log</h3>
            <div className="bg-gray-100 rounded-lg p-4 h-96 overflow-y-auto">
              <pre className="text-xs text-gray-800 whitespace-pre-wrap">
                {debugLog.join('\n')}
              </pre>
            </div>
            <button
              onClick={() => setDebugLog([])}
              className="mt-4 px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
            >
              Clear Log
            </button>
          </div>
        </div>
      </div>
    </div>
  );
} 