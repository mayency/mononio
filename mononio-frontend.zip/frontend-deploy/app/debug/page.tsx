'use client';

import { useEffect, useState } from 'react';
import { useAuthStore } from '@/store/auth';

export default function DebugPage() {
  const { user, isAuthenticated, isLoading, _hasHydrated, initialize } = useAuthStore();
  const [apiTest, setApiTest] = useState<any>(null);
  const [localStorage, setLocalStorage] = useState<any>(null);

  useEffect(() => {
    // Test API connection
    fetch('http://localhost:8000/health')
      .then(res => res.json())
      .then(data => setApiTest(data))
      .catch(err => setApiTest({ error: err.message }));

    // Check localStorage
    if (typeof window !== 'undefined') {
      const token = window.localStorage.getItem('auth_token');
      setLocalStorage({ token: token ? 'present' : 'missing' });
    }
  }, []);

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">🔍 Debug Page</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-4">Authentication State</h2>
          <div className="space-y-2 text-sm">
            <div><strong>isLoading:</strong> {isLoading.toString()}</div>
            <div><strong>_hasHydrated:</strong> {_hasHydrated.toString()}</div>
            <div><strong>isAuthenticated:</strong> {isAuthenticated.toString()}</div>
            <div><strong>user:</strong> {user ? JSON.stringify(user, null, 2) : 'null'}</div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-4">API Connection</h2>
          <div className="space-y-2 text-sm">
            <div><strong>Backend Health:</strong> {apiTest ? JSON.stringify(apiTest, null, 2) : 'Loading...'}</div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-4">Local Storage</h2>
          <div className="space-y-2 text-sm">
            <div><strong>Auth Token:</strong> {localStorage ? JSON.stringify(localStorage, null, 2) : 'Loading...'}</div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-4">Actions</h2>
          <div className="space-y-2">
            <button 
              onClick={() => initialize()}
              className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
            >
              Re-initialize Auth
            </button>
            <button 
              onClick={() => {
                if (typeof window !== 'undefined') {
                  window.localStorage.removeItem('auth_token');
                  window.location.reload();
                }
              }}
              className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 ml-2"
            >
              Clear Token & Reload
            </button>
          </div>
        </div>
      </div>
    </div>
  );
} 