'use client';

import { useState, useEffect } from 'react';
import { useAuthStore } from '@/store/auth';
import { Campaign, CampaignAnalytics } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import PerformanceMonitor from '@/components/analytics/PerformanceMonitor';
import {
  ChartBarIcon,
  EyeIcon,
  CursorArrowRaysIcon,
  CurrencyDollarIcon,
  UserGroupIcon,
  GlobeAltIcon,
  CalendarIcon,
  FunnelIcon,
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  BeakerIcon,
  CogIcon,
} from '@heroicons/react/24/outline';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

export default function AnalyticsPage() {
  const { isAuthenticated } = useAuthStore();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [campaignAnalytics, setCampaignAnalytics] = useState<CampaignAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('7d');
  const [viewMode, setViewMode] = useState<'overview' | 'realtime' | 'detailed'>('overview');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const campaignsData = await apiClient.getCampaigns();
        setCampaigns(campaignsData);
        
        if (campaignsData.length > 0) {
          setSelectedCampaign(campaignsData[0]);
          const analytics = await apiClient.getCampaignAnalytics(campaignsData[0].id);
          setCampaignAnalytics(analytics);
        }
      } catch (error) {
        console.error('Failed to fetch analytics data:', error);
      } finally {
        setLoading(false);
      }
    };

    if (isAuthenticated) {
      fetchData();
    }
  }, [isAuthenticated]);

  const handleCampaignChange = async (campaignId: number) => {
    const campaign = campaigns.find(c => c.id === campaignId);
    if (campaign) {
      setSelectedCampaign(campaign);
      try {
        const analytics = await apiClient.getCampaignAnalytics(campaignId);
        setCampaignAnalytics(analytics);
      } catch (error) {
        console.error('Failed to fetch campaign analytics:', error);
      }
    }
  };

  // Mock data for charts
  const audienceData = [
    { age: '18-24', value: 25, color: '#3B82F6' },
    { age: '25-34', value: 35, color: '#10B981' },
    { age: '35-44', value: 20, color: '#F59E0B' },
    { age: '45-54', value: 15, color: '#EF4444' },
    { age: '55+', value: 5, color: '#8B5CF6' },
  ];

  const channelPerformanceData = [
    { channel: 'Facebook', impressions: 5000, clicks: 250, conversions: 25, cost: 500 },
    { channel: 'Instagram', impressions: 3000, clicks: 180, conversions: 18, cost: 300 },
    { channel: 'Google Ads', impressions: 4000, clicks: 200, conversions: 20, cost: 400 },
    { channel: 'TikTok', impressions: 2000, clicks: 120, conversions: 12, cost: 200 },
    { channel: 'LinkedIn', impressions: 1000, clicks: 80, conversions: 8, cost: 150 },
  ];

  const dailyPerformanceData = [
    { date: 'Mon', impressions: 1200, clicks: 180, conversions: 12, cost: 45 },
    { date: 'Tue', impressions: 1350, clicks: 210, conversions: 18, cost: 52 },
    { date: 'Wed', impressions: 1100, clicks: 165, conversions: 15, cost: 48 },
    { date: 'Thu', impressions: 1400, clicks: 225, conversions: 20, cost: 55 },
    { date: 'Fri', impressions: 1250, clicks: 195, conversions: 16, cost: 50 },
    { date: 'Sat', impressions: 900, clicks: 135, conversions: 10, cost: 35 },
    { date: 'Sun', impressions: 800, clicks: 120, conversions: 8, cost: 30 },
  ];

  if (loading) {
    return (
      <ProtectedRoute>
        <div className="flex h-screen bg-secondary-50">
          <Sidebar />
          <div className="flex-1 flex items-center justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
          </div>
        </div>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="bg-white border-b border-secondary-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-secondary-900">
                  Analytics & Performance
                </h1>
                <p className="text-secondary-600">
                  Monitor and analyze your campaign performance in real-time
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-secondary-500">Campaign:</span>
                  <select
                    value={selectedCampaign?.id || ''}
                    onChange={(e) => handleCampaignChange(parseInt(e.target.value))}
                    className="text-sm border border-secondary-300 rounded px-3 py-1"
                  >
                    {campaigns.map((campaign) => (
                      <option key={campaign.id} value={campaign.id}>
                        {campaign.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-secondary-500">Time Range:</span>
                  <select
                    value={timeRange}
                    onChange={(e) => setTimeRange(e.target.value)}
                    className="text-sm border border-secondary-300 rounded px-2 py-1"
                  >
                    <option value="7d">Last 7 days</option>
                    <option value="30d">Last 30 days</option>
                    <option value="90d">Last 90 days</option>
                  </select>
                </div>
              </div>
            </div>
          </header>

          {/* View Mode Tabs */}
          <div className="bg-white border-b border-secondary-200 px-6 py-2">
            <div className="flex space-x-1">
              <button
                onClick={() => setViewMode('overview')}
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                  viewMode === 'overview'
                    ? 'bg-primary-100 text-primary-700'
                    : 'text-secondary-600 hover:text-secondary-900'
                }`}
              >
                Overview
              </button>
              <button
                onClick={() => setViewMode('realtime')}
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                  viewMode === 'realtime'
                    ? 'bg-primary-100 text-primary-700'
                    : 'text-secondary-600 hover:text-secondary-900'
                }`}
              >
                Real-time Monitor
              </button>
              <button
                onClick={() => setViewMode('detailed')}
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                  viewMode === 'detailed'
                    ? 'bg-primary-100 text-primary-700'
                    : 'text-secondary-600 hover:text-secondary-900'
                }`}
              >
                Detailed Analysis
              </button>
            </div>
          </div>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto p-6">
            {viewMode === 'overview' && (
              <div className="space-y-6">
                {/* Campaign Overview */}
                {selectedCampaign && (
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">Campaign Overview</h3>
                      <p className="card-subtitle">{selectedCampaign.name}</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-6">
                      <div className="text-center">
                        <div className="h-12 w-12 bg-primary-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                          <EyeIcon className="h-6 w-6 text-primary-600" />
                        </div>
                        <p className="text-sm text-secondary-600">Impressions</p>
                        <p className="text-2xl font-bold text-secondary-900">
                          {selectedCampaign.impressions?.toLocaleString() || 0}
                        </p>
                      </div>
                      <div className="text-center">
                        <div className="h-12 w-12 bg-success-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                          <CursorArrowRaysIcon className="h-6 w-6 text-success-600" />
                        </div>
                        <p className="text-sm text-secondary-600">Clicks</p>
                        <p className="text-2xl font-bold text-secondary-900">
                          {selectedCampaign.clicks?.toLocaleString() || 0}
                        </p>
                      </div>
                      <div className="text-center">
                        <div className="h-12 w-12 bg-warning-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                          <UserGroupIcon className="h-6 w-6 text-warning-600" />
                        </div>
                        <p className="text-sm text-secondary-600">Conversions</p>
                        <p className="text-2xl font-bold text-secondary-900">
                          {selectedCampaign.conversions?.toLocaleString() || 0}
                        </p>
                      </div>
                      <div className="text-center">
                        <div className="h-12 w-12 bg-secondary-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                          <CurrencyDollarIcon className="h-6 w-6 text-secondary-600" />
                        </div>
                        <p className="text-sm text-secondary-600">Revenue</p>
                        <p className="text-2xl font-bold text-secondary-900">
                          ${selectedCampaign.revenue?.toLocaleString() || 0}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Performance Charts */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Daily Performance */}
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">Daily Performance</h3>
                      <p className="card-subtitle">Performance trends over time</p>
                    </div>
                    <div className="p-4">
                      <ResponsiveContainer width="100%" height={300}>
                        <AreaChart data={dailyPerformanceData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Area
                            type="monotone"
                            dataKey="impressions"
                            stackId="1"
                            stroke="#8884d8"
                            fill="#8884d8"
                            fillOpacity={0.6}
                          />
                          <Area
                            type="monotone"
                            dataKey="clicks"
                            stackId="1"
                            stroke="#82ca9d"
                            fill="#82ca9d"
                            fillOpacity={0.6}
                          />
                          <Area
                            type="monotone"
                            dataKey="conversions"
                            stackId="1"
                            stroke="#ffc658"
                            fill="#ffc658"
                            fillOpacity={0.6}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Channel Performance */}
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">Channel Performance</h3>
                      <p className="card-subtitle">Performance by platform</p>
                    </div>
                    <div className="p-4">
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={channelPerformanceData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="channel" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="impressions" fill="#8884d8" />
                          <Bar dataKey="clicks" fill="#82ca9d" />
                          <Bar dataKey="conversions" fill="#ffc658" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                {/* Audience Insights */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Age Distribution */}
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">Age Distribution</h3>
                      <p className="card-subtitle">Audience demographics</p>
                    </div>
                    <div className="p-4">
                      <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={audienceData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ age, percent }) => `${age} ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {audienceData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Conversion Funnel */}
                  <div className="card">
                    <div className="card-header">
                      <h3 className="card-title">Conversion Funnel</h3>
                      <p className="card-subtitle">Customer journey analysis</p>
                    </div>
                    <div className="p-4">
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={[
                          { stage: 'Impressions', value: 10000 },
                          { stage: 'Clicks', value: 1200 },
                          { stage: 'Landing Page', value: 900 },
                          { stage: 'Add to Cart', value: 180 },
                          { stage: 'Purchase', value: 90 },
                        ]} layout="horizontal">
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis type="number" />
                          <YAxis dataKey="stage" type="category" width={100} />
                          <Tooltip />
                          <Bar dataKey="value" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {viewMode === 'realtime' && (
              <PerformanceMonitor
                campaignId={selectedCampaign?.id}
                refreshInterval={15000}
                showAlerts={true}
              />
            )}

            {viewMode === 'detailed' && (
              <div className="space-y-6">
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">Detailed Analysis</h3>
                    <p className="card-subtitle">In-depth campaign insights</p>
                  </div>
                  <div className="p-6">
                    <p className="text-secondary-600">
                      Detailed analysis features will be implemented here, including:
                    </p>
                    <ul className="mt-4 space-y-2 text-secondary-600">
                      <li>• Advanced segmentation analysis</li>
                      <li>• A/B test results and statistical significance</li>
                      <li>• Attribution modeling</li>
                      <li>• Predictive analytics</li>
                      <li>• Custom report builder</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </main>
        </div>
      </div>
    </ProtectedRoute>
  );
} 