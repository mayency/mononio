'use client';

import { useEffect, useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth';
import { Business } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import ClientOnly from '@/components/auth/ClientOnly';
import {
  UserPlusIcon,
  PlusIcon,
  TrashIcon,
  ArrowLeftIcon,
  BuildingOfficeIcon,
  SparklesIcon,
  UserGroupIcon,
  EyeIcon,
  PencilIcon,
  CheckCircleIcon,
  ExclamationTriangleIcon,
  MagnifyingGlassIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { getErrorMessage } from '@/lib/getErrorMessage';

interface TargetAudience {
  id: string;
  name: string;
  description: string;
  business_id: string;
  demographics: {
    age_range?: string;
    gender?: string;
    location?: string;
    income_level?: string;
    education_level?: string;
  };
  interests: string[];
  behaviors: string[];
  platforms: string[];
  estimated_size: number;
  created_by: 'ai' | 'manual';
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface AIAudienceRequest {
  business_name: string;
  industry: string;
  target_audience: string;
  brand_voice: string;
  campaign_goal: string;
  budget_range?: string;
  platform_preference?: string;
}

export default function TargetAudiencesPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { isAuthenticated, isLoading } = useAuthStore();
  const [business, setBusiness] = useState<Business | null>(null);
  const [audiences, setAudiences] = useState<TargetAudience[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [showAICreateForm, setShowAICreateForm] = useState(false);
  const [selectedAudience, setSelectedAudience] = useState<TargetAudience | null>(null);
  const [formData, setFormData] = useState<Partial<TargetAudience>>({});
  const [aiFormData, setAiFormData] = useState<AIAudienceRequest>({
    business_name: '',
    industry: '',
    target_audience: '',
    brand_voice: '',
    campaign_goal: '',
  });

  const businessId = searchParams.get('businessId');

  useEffect(() => {
    if (isAuthenticated && !isLoading && businessId) {
      fetchData();
    }
  }, [isAuthenticated, isLoading, businessId]);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch business details
      const businessData = await apiClient.getBusiness(parseInt(businessId!));
      setBusiness(businessData);

      // Fetch target audiences
      await fetchTargetAudiences();

    } catch (error) {
      console.error('Failed to fetch target audiences data:', error);
      toast.error('Failed to load target audiences');
    } finally {
      setLoading(false);
    }
  };

  const fetchTargetAudiences = async () => {
    try {
      const response = await apiClient.getTargetAudiences(businessId!);
      setAudiences(response.audiences || []);
    } catch (error) {
      console.error('Failed to fetch target audiences:', error);
    }
  };

  const handleCreateAudience = async () => {
    if (!formData.name || !formData.description) {
      toast.error('Please fill in all required fields');
      return;
    }

    setSaving(true);
    try {
      const response = await apiClient.createTargetAudience({
        business_id: businessId!,
        ...formData,
        created_by: 'manual'
      });

      if (response.success) {
        toast.success('Target audience created successfully');
        setShowCreateForm(false);
        setFormData({});
        await fetchTargetAudiences();
      } else {
        toast.error(getErrorMessage(response.error) || 'Failed to create target audience');
      }
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to create target audience');
    } finally {
      setSaving(false);
    }
  };

  const handleCreateAIAudience = async () => {
    if (!aiFormData.campaign_goal) {
      toast.error('Please specify your campaign goal');
      return;
    }

    setSaving(true);
    try {
      const response = await apiClient.createAITargetAudience({
        business_id: businessId!,
        ...aiFormData
      });

      if (response.success) {
        toast.success('AI-generated target audience created successfully');
        setShowAICreateForm(false);
        setAiFormData({
          business_name: '',
          industry: '',
          target_audience: '',
          brand_voice: '',
          campaign_goal: '',
        });
        await fetchTargetAudiences();
      } else {
        toast.error(getErrorMessage(response.error) || 'Failed to create AI target audience');
      }
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to create AI target audience');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteAudience = async (audienceId: string) => {
    if (!confirm('Are you sure you want to delete this target audience? This action cannot be undone.')) {
      return;
    }

    try {
      const response = await apiClient.deleteTargetAudience(audienceId);
      if (response.success) {
        toast.success('Target audience deleted successfully');
        await fetchTargetAudiences();
      } else {
        toast.error(getErrorMessage(response.error) || 'Failed to delete target audience');
      }
    } catch (error: any) {
      toast.error(getErrorMessage(error) || 'Failed to delete target audience');
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  if (isLoading) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-secondary-900 mb-2">Authentication Required</h2>
            <p className="text-secondary-600">Please log in to access target audiences.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ClientOnly>
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="bg-white border-b border-secondary-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  variant="ghost"
                  onClick={() => router.back()}
                  leftIcon={<ArrowLeftIcon className="h-4 w-4" />}
                >
                  Back
                </Button>
                <div>
                  <h1 className="text-2xl font-bold text-secondary-900">
                    Target Audiences
                  </h1>
                  <p className="text-secondary-600">
                    Create and manage target audiences for your campaigns
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Button
                  variant="secondary"
                  onClick={() => setShowAICreateForm(true)}
                  leftIcon={<SparklesIcon className="h-4 w-4" />}
                >
                  AI Generate
                </Button>
                <Button
                  onClick={() => setShowCreateForm(true)}
                  leftIcon={<PlusIcon className="h-4 w-4" />}
                >
                  Create Manually
                </Button>
              </div>
            </div>
          </header>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto p-6">
            <div className="max-w-6xl mx-auto space-y-6">
              {/* Business Info */}
              {business && (
                <div className="bg-white rounded-lg border border-secondary-200 p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <BuildingOfficeIcon className="h-6 w-6 text-primary-600" />
                    <h2 className="text-lg font-semibold text-secondary-900">{business.name}</h2>
                  </div>
                  <p className="text-secondary-600">Manage target audiences for your advertising campaigns</p>
                </div>
              )}

              {/* Target Audiences List */}
              <div className="bg-white rounded-lg border border-secondary-200 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-lg font-semibold text-secondary-900">Target Audiences</h2>
                    <p className="text-secondary-600">Manage your audience segments</p>
                  </div>
                </div>

                {/* Audiences Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {audiences.length === 0 ? (
                    <div className="col-span-full text-center py-12">
                      <UserGroupIcon className="h-16 w-16 text-secondary-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-secondary-900 mb-2">No Target Audiences</h3>
                      <p className="text-secondary-600 mb-6">
                        Create your first target audience to start optimizing your campaigns
                      </p>
                      <div className="flex justify-center space-x-3">
                        <Button
                          onClick={() => setShowAICreateForm(true)}
                          leftIcon={<SparklesIcon className="h-4 w-4" />}
                        >
                          AI Generate
                        </Button>
                        <Button
                          variant="secondary"
                          onClick={() => setShowCreateForm(true)}
                          leftIcon={<PlusIcon className="h-4 w-4" />}
                        >
                          Create Manually
                        </Button>
                      </div>
                    </div>
                  ) : (
                    audiences.map((audience) => (
                      <div key={audience.id} className="border border-secondary-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <h3 className="font-medium text-secondary-900">{audience.name}</h3>
                              {audience.created_by === 'ai' && (
                                <SparklesIcon className="h-4 w-4 text-blue-600" />
                              )}
                            </div>
                            <p className="text-sm text-secondary-600 mb-3">{audience.description}</p>
                            
                            {/* Demographics */}
                            {audience.demographics && (
                              <div className="mb-3">
                                <h4 className="text-xs font-medium text-secondary-700 mb-1">Demographics</h4>
                                <div className="flex flex-wrap gap-1">
                                  {audience.demographics.age_range && (
                                    <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                                      {audience.demographics.age_range}
                                    </span>
                                  )}
                                  {audience.demographics.location && (
                                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">
                                      {audience.demographics.location}
                                    </span>
                                  )}
                                  {audience.demographics.income_level && (
                                    <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded">
                                      {audience.demographics.income_level}
                                    </span>
                                  )}
                                </div>
                              </div>
                            )}

                            {/* Interests */}
                            {audience.interests.length > 0 && (
                              <div className="mb-3">
                                <h4 className="text-xs font-medium text-secondary-700 mb-1">Interests</h4>
                                <div className="flex flex-wrap gap-1">
                                  {audience.interests.slice(0, 3).map((interest, index) => (
                                    <span key={index} className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded">
                                      {interest}
                                    </span>
                                  ))}
                                  {audience.interests.length > 3 && (
                                    <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded">
                                      +{audience.interests.length - 3} more
                                    </span>
                                  )}
                                </div>
                              </div>
                            )}

                            {/* Platforms */}
                            {audience.platforms.length > 0 && (
                              <div className="mb-3">
                                <h4 className="text-xs font-medium text-secondary-700 mb-1">Platforms</h4>
                                <div className="flex flex-wrap gap-1">
                                  {audience.platforms.map((platform, index) => (
                                    <span key={index} className="px-2 py-1 bg-indigo-100 text-indigo-800 text-xs rounded">
                                      {platform}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                          
                          <div className="flex items-center space-x-1">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              audience.is_active 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {audience.is_active ? 'Active' : 'Inactive'}
                            </span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setSelectedAudience(audience)}
                            >
                              <EyeIcon className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteAudience(audience.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <TrashIcon className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        
                        {/* Audience Stats */}
                        <div className="border-t border-secondary-200 pt-3">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-secondary-600">
                              Est. Size: <span className="font-medium text-secondary-900">{formatNumber(audience.estimated_size)}</span>
                            </span>
                            <span className="text-secondary-500 text-xs">
                              {new Date(audience.created_at).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Manual Create Form */}
              {showCreateForm && (
                <div className="bg-white rounded-lg border border-secondary-200 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-secondary-900">Create Target Audience</h3>
                    <Button
                      variant="ghost"
                      onClick={() => {
                        setShowCreateForm(false);
                        setFormData({});
                      }}
                    >
                      Cancel
                    </Button>
                  </div>

                  <div className="space-y-4">
                    {/* Basic Info */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-secondary-700 mb-2">
                          Audience Name *
                        </label>
                        <Input
                          type="text"
                          value={formData.name || ''}
                          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                          placeholder="e.g., Tech-Savvy Professionals"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-secondary-700 mb-2">
                          Description *
                        </label>
                        <Input
                          type="text"
                          value={formData.description || ''}
                          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                          placeholder="Brief description of the audience"
                        />
                      </div>
                    </div>

                    {/* Demographics */}
                    <div className="border-t border-secondary-200 pt-4">
                      <h4 className="font-medium text-secondary-900 mb-3">Demographics</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-secondary-700 mb-2">
                            Age Range
                          </label>
                          <select
                            value={formData.demographics?.age_range || ''}
                            onChange={(e) => setFormData(prev => ({
                              ...prev,
                              demographics: { ...prev.demographics, age_range: e.target.value }
                            }))}
                            className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                          >
                            <option value="">Select age range</option>
                            <option value="18-24">18-24</option>
                            <option value="25-34">25-34</option>
                            <option value="35-44">35-44</option>
                            <option value="45-54">45-54</option>
                            <option value="55-64">55-64</option>
                            <option value="65+">65+</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-secondary-700 mb-2">
                            Gender
                          </label>
                          <select
                            value={formData.demographics?.gender || ''}
                            onChange={(e) => setFormData(prev => ({
                              ...prev,
                              demographics: { ...prev.demographics, gender: e.target.value }
                            }))}
                            className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                          >
                            <option value="">Select gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="All">All</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-secondary-700 mb-2">
                            Location
                          </label>
                          <Input
                            type="text"
                            value={formData.demographics?.location || ''}
                            onChange={(e) => setFormData(prev => ({
                              ...prev,
                              demographics: { ...prev.demographics, location: e.target.value }
                            }))}
                            placeholder="e.g., San Francisco, CA"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-secondary-700 mb-2">
                            Income Level
                          </label>
                          <select
                            value={formData.demographics?.income_level || ''}
                            onChange={(e) => setFormData(prev => ({
                              ...prev,
                              demographics: { ...prev.demographics, income_level: e.target.value }
                            }))}
                            className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                          >
                            <option value="">Select income level</option>
                            <option value="Under $30k">Under $30k</option>
                            <option value="$30k-$50k">$30k-$50k</option>
                            <option value="$50k-$75k">$50k-$75k</option>
                            <option value="$75k-$100k">$75k-$100k</option>
                            <option value="$100k+">$100k+</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Interests */}
                    <div className="border-t border-secondary-200 pt-4">
                      <h4 className="font-medium text-secondary-900 mb-3">Interests & Behaviors</h4>
                      <div className="space-y-3">
                        <div>
                          <label className="block text-sm font-medium text-secondary-700 mb-2">
                            Interests (comma-separated)
                          </label>
                          <Input
                            type="text"
                            value={formData.interests?.join(', ') || ''}
                            onChange={(e) => setFormData(prev => ({
                              ...prev,
                              interests: e.target.value.split(',').map(s => s.trim()).filter(s => s)
                            }))}
                            placeholder="e.g., technology, business, marketing"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-secondary-700 mb-2">
                            Behaviors (comma-separated)
                          </label>
                          <Input
                            type="text"
                            value={formData.behaviors?.join(', ') || ''}
                            onChange={(e) => setFormData(prev => ({
                              ...prev,
                              behaviors: e.target.value.split(',').map(s => s.trim()).filter(s => s)
                            }))}
                            placeholder="e.g., online shoppers, mobile users"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Platforms */}
                    <div className="border-t border-secondary-200 pt-4">
                      <h4 className="font-medium text-secondary-900 mb-3">Target Platforms</h4>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {['Facebook', 'Instagram', 'Google', 'LinkedIn', 'Twitter', 'TikTok', 'YouTube', 'Pinterest'].map((platform) => (
                          <label key={platform} className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                              checked={formData.platforms?.includes(platform.toLowerCase()) || false}
                              onChange={(e) => {
                                const currentPlatforms = formData.platforms || [];
                                if (e.target.checked) {
                                  setFormData(prev => ({
                                    ...prev,
                                    platforms: [...currentPlatforms, platform.toLowerCase()]
                                  }));
                                } else {
                                  setFormData(prev => ({
                                    ...prev,
                                    platforms: currentPlatforms.filter(p => p !== platform.toLowerCase())
                                  }));
                                }
                              }}
                              className="rounded border-secondary-300 text-primary-600 focus:ring-primary-500"
                            />
                            <span className="text-sm text-secondary-700">{platform}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Estimated Size */}
                    <div className="border-t border-secondary-200 pt-4">
                      <div>
                        <label className="block text-sm font-medium text-secondary-700 mb-2">
                          Estimated Audience Size
                        </label>
                        <Input
                          type="number"
                          value={formData.estimated_size || ''}
                          onChange={(e) => setFormData(prev => ({
                            ...prev,
                            estimated_size: parseInt(e.target.value) || 0
                          }))}
                          placeholder="e.g., 50000"
                        />
                      </div>
                    </div>

                    {/* Submit Button */}
                    <div className="flex justify-end space-x-3 pt-4 border-t border-secondary-200">
                      <Button
                        variant="secondary"
                        onClick={() => {
                          setShowCreateForm(false);
                          setFormData({});
                        }}
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={handleCreateAudience}
                        disabled={saving || !formData.name || !formData.description}
                      >
                        {saving ? 'Creating...' : 'Create Audience'}
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* AI Create Form */}
              {showAICreateForm && (
                <div className="bg-white rounded-lg border border-secondary-200 p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      <SparklesIcon className="h-6 w-6 text-blue-600" />
                      <h3 className="text-lg font-semibold text-secondary-900">AI-Generated Target Audience</h3>
                    </div>
                    <Button
                      variant="ghost"
                      onClick={() => {
                        setShowAICreateForm(false);
                        setAiFormData({
                          business_name: '',
                          industry: '',
                          target_audience: '',
                          brand_voice: '',
                          campaign_goal: '',
                        });
                      }}
                    >
                      Cancel
                    </Button>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <div className="flex items-start space-x-3">
                        <SparklesIcon className="h-5 w-5 text-blue-600 mt-0.5" />
                        <div>
                          <h4 className="font-medium text-blue-900">AI-Powered Audience Generation</h4>
                          <p className="text-sm text-blue-700 mt-1">
                            Our AI will analyze your business and campaign goals to create the perfect target audience.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-secondary-700 mb-2">
                          Campaign Goal *
                        </label>
                        <select
                          value={aiFormData.campaign_goal}
                          onChange={(e) => setAiFormData(prev => ({ ...prev, campaign_goal: e.target.value }))}
                          className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        >
                          <option value="">Select campaign goal</option>
                          <option value="brand_awareness">Brand Awareness</option>
                          <option value="lead_generation">Lead Generation</option>
                          <option value="sales_conversion">Sales Conversion</option>
                          <option value="customer_retention">Customer Retention</option>
                          <option value="website_traffic">Website Traffic</option>
                          <option value="app_installs">App Installs</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-secondary-700 mb-2">
                          Budget Range
                        </label>
                        <select
                          value={aiFormData.budget_range || ''}
                          onChange={(e) => setAiFormData(prev => ({ ...prev, budget_range: e.target.value }))}
                          className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        >
                          <option value="">Select budget range</option>
                          <option value="under_1k">Under $1,000</option>
                          <option value="1k_5k">$1,000 - $5,000</option>
                          <option value="5k_10k">$5,000 - $10,000</option>
                          <option value="10k_25k">$10,000 - $25,000</option>
                          <option value="25k_plus">$25,000+</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-secondary-700 mb-2">
                        Platform Preference
                      </label>
                      <select
                        value={aiFormData.platform_preference || ''}
                        onChange={(e) => setAiFormData(prev => ({ ...prev, platform_preference: e.target.value }))}
                        className="w-full p-3 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      >
                        <option value="">Let AI choose best platforms</option>
                        <option value="facebook">Facebook & Instagram</option>
                        <option value="google">Google Ads</option>
                        <option value="linkedin">LinkedIn</option>
                        <option value="tiktok">TikTok</option>
                        <option value="youtube">YouTube</option>
                      </select>
                    </div>

                    {/* Submit Button */}
                    <div className="flex justify-end space-x-3 pt-4 border-t border-secondary-200">
                      <Button
                        variant="secondary"
                        onClick={() => {
                          setShowAICreateForm(false);
                          setAiFormData({
                            business_name: '',
                            industry: '',
                            target_audience: '',
                            brand_voice: '',
                            campaign_goal: '',
                          });
                        }}
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={handleCreateAIAudience}
                        disabled={saving || !aiFormData.campaign_goal}
                      >
                        {saving ? 'Generating...' : 'Generate with AI'}
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* Audience Detail Modal */}
              {selectedAudience && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                  <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-secondary-900">{selectedAudience.name}</h3>
                      <Button
                        variant="ghost"
                        onClick={() => setSelectedAudience(null)}
                      >
                        Close
                      </Button>
                    </div>
                    
                    <div className="space-y-4">
                      <p className="text-secondary-600">{selectedAudience.description}</p>
                      
                      {selectedAudience.demographics && (
                        <div>
                          <h4 className="font-medium text-secondary-900 mb-2">Demographics</h4>
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            {selectedAudience.demographics.age_range && (
                              <div><span className="text-secondary-600">Age:</span> {selectedAudience.demographics.age_range}</div>
                            )}
                            {selectedAudience.demographics.gender && (
                              <div><span className="text-secondary-600">Gender:</span> {selectedAudience.demographics.gender}</div>
                            )}
                            {selectedAudience.demographics.location && (
                              <div><span className="text-secondary-600">Location:</span> {selectedAudience.demographics.location}</div>
                            )}
                            {selectedAudience.demographics.income_level && (
                              <div><span className="text-secondary-600">Income:</span> {selectedAudience.demographics.income_level}</div>
                            )}
                          </div>
                        </div>
                      )}
                      
                      {selectedAudience.interests.length > 0 && (
                        <div>
                          <h4 className="font-medium text-secondary-900 mb-2">Interests</h4>
                          <div className="flex flex-wrap gap-2">
                            {selectedAudience.interests.map((interest, index) => (
                              <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 text-sm rounded">
                                {interest}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {selectedAudience.behaviors.length > 0 && (
                        <div>
                          <h4 className="font-medium text-secondary-900 mb-2">Behaviors</h4>
                          <div className="flex flex-wrap gap-2">
                            {selectedAudience.behaviors.map((behavior, index) => (
                              <span key={index} className="px-2 py-1 bg-green-100 text-green-800 text-sm rounded">
                                {behavior}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <div>
                        <h4 className="font-medium text-secondary-900 mb-2">Platforms</h4>
                        <div className="flex flex-wrap gap-2">
                          {selectedAudience.platforms.map((platform, index) => (
                            <span key={index} className="px-2 py-1 bg-purple-100 text-purple-800 text-sm rounded">
                              {platform}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <div className="border-t border-secondary-200 pt-4">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-secondary-600">
                            Estimated Size: <span className="font-medium text-secondary-900">{formatNumber(selectedAudience.estimated_size)}</span>
                          </span>
                          <span className="text-secondary-500">
                            Created: {new Date(selectedAudience.created_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </main>
        </div>
      </div>
    </ClientOnly>
  );
} 