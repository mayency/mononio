'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth';
import { CampaignCreate, Business } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import {
  MegaphoneIcon,
  UserGroupIcon,
  GlobeAltIcon,
  SparklesIcon,
  ArrowRightIcon,
  ArrowLeftIcon,
  CheckIcon,
  PlayIcon,
  CalendarIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

export default function CampaignWizardPage() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    business_id: 0,
    name: '',
    description: '',
    goal: '',
    target_audience: '',
    budget: 0,
    start_date: '',
    end_date: '',
    platforms: [] as string[],
  });

  const steps = [
    { id: 'basic', title: 'Basic Information', description: 'Campaign basics' },
    { id: 'audience', title: 'Target Audience', description: 'Define your audience' },
    { id: 'platforms', title: 'Platforms & Budget', description: 'Choose channels' },
    { id: 'schedule', title: 'Schedule', description: 'Set timeline' },
  ];

  useEffect(() => {
    if (isAuthenticated) {
      fetchBusinesses();
    }
  }, [isAuthenticated]);

  const fetchBusinesses = async () => {
    try {
      const data = await apiClient.getBusinesses();
      setBusinesses(data);
    } catch (error) {
      console.error('Failed to fetch businesses:', error);
      toast.error('Failed to load businesses');
    }
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const createCampaign = async () => {
    setLoading(true);
    try {
      const campaignData: CampaignCreate = {
        business_id: formData.business_id,
        name: formData.name,
        campaign_type: 'multi_channel',
        budget: formData.budget,
        start_date: formData.start_date,
        end_date: formData.end_date,
        description: formData.description,
        goal: formData.goal,
        target_audience: formData.target_audience,
        channels: formData.platforms,
        ab_testing_enabled: false,
      };

      const newCampaign = await apiClient.createCampaign(campaignData);
      toast.success('Campaign created successfully!');
      router.push('/campaigns');
    } catch (error: any) {
      toast.error(error.message || 'Failed to create campaign');
    } finally {
      setLoading(false);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-4">
            <div>
              <label className="label">Business</label>
              <select
                value={formData.business_id}
                onChange={(e) => setFormData({...formData, business_id: parseInt(e.target.value)})}
                className="input"
              >
                <option value={0}>Select a business</option>
                {businesses.map((business) => (
                  <option key={business.id} value={business.id}>
                    {business.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Campaign Name</label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Enter campaign name"
              />
            </div>
            <div>
              <label className="label">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                className="input"
                rows={3}
                placeholder="Describe your campaign"
              />
            </div>
            <div>
              <label className="label">Goal</label>
              <select
                value={formData.goal}
                onChange={(e) => setFormData({...formData, goal: e.target.value})}
                className="input"
              >
                <option value="">Select a goal</option>
                <option value="brand_awareness">Brand Awareness</option>
                <option value="lead_generation">Lead Generation</option>
                <option value="sales_conversion">Sales Conversion</option>
                <option value="website_traffic">Website Traffic</option>
              </select>
            </div>
          </div>
        );
      case 1:
        return (
          <div className="space-y-4">
            <div>
              <label className="label">Target Audience</label>
              <textarea
                value={formData.target_audience}
                onChange={(e) => setFormData({...formData, target_audience: e.target.value})}
                className="input"
                rows={4}
                placeholder="Describe your target audience (age, interests, location, etc.)"
              />
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-4">
            <div>
              <label className="label">Platforms</label>
              <div className="space-y-2">
                {['Facebook', 'Instagram', 'Google Ads', 'TikTok', 'LinkedIn'].map((platform) => (
                  <label key={platform} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={formData.platforms.includes(platform.toLowerCase())}
                      onChange={(e) => {
                        const newPlatforms = e.target.checked
                          ? [...formData.platforms, platform.toLowerCase()]
                          : formData.platforms.filter(p => p !== platform.toLowerCase());
                        setFormData({...formData, platforms: newPlatforms});
                      }}
                      className="checkbox"
                    />
                    <span className="ml-2">{platform}</span>
                  </label>
                ))}
              </div>
            </div>
            <div>
              <label className="label">Budget ($)</label>
              <Input
                type="number"
                value={formData.budget}
                onChange={(e) => setFormData({...formData, budget: parseFloat(e.target.value) || 0})}
                placeholder="0.00"
              />
            </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-4">
            <div>
              <label className="label">Start Date</label>
              <Input
                type="date"
                value={formData.start_date}
                onChange={(e) => setFormData({...formData, start_date: e.target.value})}
              />
            </div>
            <div>
              <label className="label">End Date</label>
              <Input
                type="date"
                value={formData.end_date}
                onChange={(e) => setFormData({...formData, end_date: e.target.value})}
              />
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="bg-white border-b border-secondary-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-secondary-900">
                  Campaign Creation Wizard
                </h1>
                <p className="text-secondary-600">
                  Step {currentStep + 1} of {steps.length}: {steps[currentStep].title}
                </p>
              </div>
              <Button
                onClick={() => router.push('/campaigns')}
                variant="secondary"
                size="sm"
              >
                Cancel
              </Button>
            </div>
          </header>

          {/* Progress Bar */}
          <div className="bg-white border-b border-secondary-200 px-6 py-4">
            <div className="flex items-center space-x-4">
              {steps.map((step, index) => (
                <div key={step.id} className="flex items-center">
                  <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 ${
                    index <= currentStep 
                      ? 'bg-primary-600 border-primary-600 text-white' 
                      : 'border-secondary-300 text-secondary-400'
                  }`}>
                    {index < currentStep ? (
                      <CheckIcon className="w-4 h-4" />
                    ) : (
                      <span className="text-sm font-medium">{index + 1}</span>
                    )}
                  </div>
                  <div className="ml-3">
                    <p className={`text-sm font-medium ${
                      index <= currentStep ? 'text-secondary-900' : 'text-secondary-500'
                    }`}>
                      {step.title}
                    </p>
                    <p className="text-xs text-secondary-500">{step.description}</p>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={`w-16 h-0.5 mx-4 ${
                      index < currentStep ? 'bg-primary-600' : 'bg-secondary-300'
                    }`} />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto p-6">
            <div className="max-w-2xl mx-auto">
              <div className="card">
                <div className="card-header">
                  <h3 className="card-title">{steps[currentStep].title}</h3>
                  <p className="card-subtitle">{steps[currentStep].description}</p>
                </div>
                <div className="p-6">
                  {renderStepContent()}
                </div>
              </div>
            </div>
          </main>

          {/* Footer */}
          <footer className="bg-white border-t border-secondary-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <Button
                onClick={prevStep}
                disabled={currentStep === 0}
                variant="secondary"
              >
                <ArrowLeftIcon className="w-4 h-4 mr-2" />
                Previous
              </Button>
              
              <div className="flex items-center space-x-4">
                {currentStep < steps.length - 1 ? (
                  <Button
                    onClick={nextStep}
                    disabled={!formData.business_id || !formData.name}
                  >
                    Next
                    <ArrowRightIcon className="w-4 h-4 ml-2" />
                  </Button>
                ) : (
                  <Button
                    onClick={createCampaign}
                    disabled={loading}
                    loading={loading}
                  >
                    <PlayIcon className="w-4 h-4 mr-2" />
                    Create Campaign
                  </Button>
                )}
              </div>
            </div>
          </footer>
        </div>
      </div>
    </ProtectedRoute>
  );
} 