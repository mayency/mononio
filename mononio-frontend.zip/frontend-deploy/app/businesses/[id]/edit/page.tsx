'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth';
import { Business, BusinessCreate } from '@/types';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import ClientOnly from '@/components/auth/ClientOnly';
import {
  ArrowLeftIcon,
  BuildingOfficeIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

export default function EditBusinessPage() {
  const params = useParams();
  const router = useRouter();
  const { isAuthenticated, isLoading } = useAuthStore();
  const [business, setBusiness] = useState<Business | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState<BusinessCreate>({
    name: '',
    industry: '',
    location: '',
    target_audience: '',
    brand_voice: '',
  });

  const businessId = parseInt(params.id as string);

  useEffect(() => {
    if (isAuthenticated && !isLoading && businessId) {
      fetchBusinessData();
    }
  }, [isAuthenticated, isLoading, businessId]);

  const fetchBusinessData = async () => {
    try {
      setLoading(true);
      const businessData = await apiClient.getBusiness(businessId);
      setBusiness(businessData);
      setFormData({
        name: businessData.name,
        industry: businessData.industry,
        location: businessData.location,
        target_audience: businessData.target_audience,
        brand_voice: businessData.brand_voice,
      });
    } catch (error) {
      console.error('Failed to fetch business data:', error);
      toast.error('Failed to load business details');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setSaving(true);
      await apiClient.updateBusiness(businessId, formData);
      toast.success('Business updated successfully!');
      router.push(`/businesses/${businessId}`);
    } catch (error: any) {
      toast.error(error.message || 'Failed to update business');
    } finally {
      setSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-secondary-900 mb-2">Authentication Required</h2>
            <p className="text-secondary-600">Please log in to edit business details.</p>
          </div>
        </div>
      </div>
    );
  }

  if (!business) {
    return (
      <div className="flex h-screen bg-secondary-50">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-secondary-900 mb-2">Business Not Found</h2>
            <p className="text-secondary-600">The business you're looking for doesn't exist.</p>
            <Button onClick={() => router.push('/businesses')} className="mt-4">
              Back to Businesses
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ClientOnly>
      <div className="flex h-screen bg-secondary-50">
        <Sidebar />
        
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="bg-white border-b border-secondary-200 px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  variant="ghost"
                  onClick={() => router.push(`/businesses/${businessId}`)}
                  leftIcon={<ArrowLeftIcon className="h-4 w-4" />}
                >
                  Back
                </Button>
                <div>
                  <h1 className="text-2xl font-bold text-secondary-900">
                    Edit Business
                  </h1>
                  <p className="text-secondary-600">
                    Update business information and settings
                  </p>
                </div>
              </div>
            </div>
          </header>

          {/* Main Content */}
          <main className="flex-1 overflow-y-auto p-6">
            <div className="max-w-2xl mx-auto">
              <div className="bg-white rounded-lg border border-secondary-200 p-6">
                <div className="flex items-center mb-6">
                  <BuildingOfficeIcon className="h-8 w-8 text-primary-600 mr-3" />
                  <h2 className="text-xl font-semibold text-secondary-900">
                    Business Information
                  </h2>
                </div>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <Input
                    label="Business Name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter business name"
                    required
                  />
                  
                  <Input
                    label="Industry"
                    value={formData.industry}
                    onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                    placeholder="e.g., Technology, Healthcare, Retail"
                    required
                  />
                  
                  <Input
                    label="Location"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="City, State or Country"
                    required
                  />
                  
                  <Input
                    label="Target Audience"
                    value={formData.target_audience}
                    onChange={(e) => setFormData({ ...formData, target_audience: e.target.value })}
                    placeholder="e.g., Small business owners, 25-45 years old"
                    required
                  />
                  
                  <Input
                    label="Brand Voice"
                    value={formData.brand_voice}
                    onChange={(e) => setFormData({ ...formData, brand_voice: e.target.value })}
                    placeholder="e.g., Professional, Friendly, Innovative"
                    required
                  />
                  
                  <div className="flex space-x-3 pt-4">
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => router.push(`/businesses/${businessId}`)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      className="flex-1"
                      disabled={saving}
                    >
                      {saving ? 'Updating...' : 'Update Business'}
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </main>
        </div>
      </div>
    </ClientOnly>
  );
} 