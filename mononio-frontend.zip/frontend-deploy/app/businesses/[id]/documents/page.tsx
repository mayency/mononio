'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import {
  DocumentIcon,
  FolderIcon,
  ArrowUpTrayIcon,
  MagnifyingGlassIcon,
  FunnelIcon,
  TrashIcon,
  PencilIcon,
  EyeIcon,
  ArrowDownTrayIcon,
  PlusIcon,
  XMarkIcon,
  DocumentTextIcon,
  PhotoIcon,
  FilmIcon,
  ArchiveBoxIcon,
  DocumentDuplicateIcon,
  CogIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

interface Document {
  id: string;
  filename: string;
  original_filename: string;
  file_size: number;
  mime_type: string;
  category: string;
  description: string;
  tags: string[];
  uploaded_at: string;
  status: string;
  download_count: number;
  file_url: string;
  thumbnail_url?: string;
  is_public: boolean;
}

interface DocumentCategory {
  name: string;
  count: number;
  total_size: number;
}

export default function BusinessDocumentsPage() {
  const router = useRouter();
  const params = useParams();
  const businessId = params.id as string;
  const { user, isAuthenticated } = useAuthStore();
  
  // State
  const [documents, setDocuments] = useState<Document[]>([]);
  const [categories, setCategories] = useState<DocumentCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [stats, setStats] = useState<any>(null);
  const [pagination, setPagination] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState(1);

  // Upload form state
  const [uploadForm, setUploadForm] = useState({
    file: null as File | null,
    category: 'general',
    description: '',
    tags: '',
  });

  // Edit form state
  const [editForm, setEditForm] = useState({
    category: '',
    description: '',
    tags: '',
    is_public: false,
  });

  // Predefined categories
  const predefinedCategories = [
    { name: 'general', label: 'General Documents' },
    { name: 'contracts', label: 'Contracts & Agreements' },
    { name: 'logos', label: 'Logos & Branding' },
    { name: 'marketing', label: 'Marketing Materials' },
    { name: 'financial', label: 'Financial Documents' },
    { name: 'legal', label: 'Legal Documents' },
    { name: 'images', label: 'Images & Photos' },
    { name: 'videos', label: 'Videos & Media' },
    { name: 'presentations', label: 'Presentations' },
    { name: 'reports', label: 'Reports & Analytics' },
  ];

  // Load documents
  const loadDocuments = async () => {
    try {
      setLoading(true);
      const response = await apiClient.getBusinessDocuments(
        businessId,
        selectedCategory || undefined,
        searchTerm || undefined,
        currentPage
      );

      if (response.success) {
        setDocuments(response.documents || []);
        setCategories(response.categories || []);
        setStats(response.stats);
        setPagination(response.pagination);
      } else {
        toast.error(response.error || 'Failed to load documents');
      }
    } catch (error: any) {
      toast.error('Failed to load documents');
      console.error('Error loading documents:', error);
    } finally {
      setLoading(false);
    }
  };

  // Load categories
  const loadCategories = async () => {
    try {
      const response = await apiClient.getBusinessDocumentCategories(businessId);
      if (response.success) {
        setCategories(response.categories || []);
      }
    } catch (error) {
      console.error('Error loading categories:', error);
    }
  };

  // Upload document
  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!uploadForm.file) {
      toast.error('Please select a file to upload');
      return;
    }

    setUploading(true);
    try {
      const response = await apiClient.uploadBusinessDocument(
        businessId,
        uploadForm.file,
        uploadForm.category,
        uploadForm.description,
        uploadForm.tags
      );

      if (response.success) {
        toast.success('Document uploaded successfully!');
        setShowUploadModal(false);
        setUploadForm({
          file: null,
          category: 'general',
          description: '',
          tags: '',
        });
        loadDocuments();
        loadCategories();
      } else {
        toast.error(response.error || 'Upload failed');
      }
    } catch (error: any) {
      toast.error('Upload failed');
      console.error('Upload error:', error);
    } finally {
      setUploading(false);
    }
  };

  // Update document
  const handleUpdateDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedDocument) return;

    try {
      const response = await apiClient.updateBusinessDocument(
        businessId,
        selectedDocument.id,
        {
          category: editForm.category,
          description: editForm.description,
          tags: editForm.tags,
          is_public: editForm.is_public,
        }
      );

      if (response.success) {
        toast.success('Document updated successfully!');
        setShowEditModal(false);
        setSelectedDocument(null);
        loadDocuments();
      } else {
        toast.error(response.error || 'Update failed');
      }
    } catch (error: any) {
      toast.error('Update failed');
      console.error('Update error:', error);
    }
  };

  // Delete document
  const handleDeleteDocument = async (documentId: string) => {
    if (!confirm('Are you sure you want to delete this document?')) return;

    try {
      const response = await apiClient.deleteBusinessDocument(businessId, documentId);
      
      if (response.success) {
        toast.success('Document deleted successfully!');
        loadDocuments();
        loadCategories();
      } else {
        toast.error(response.error || 'Delete failed');
      }
    } catch (error: any) {
      toast.error('Delete failed');
      console.error('Delete error:', error);
    }
  };

  // Download document
  const handleDownloadDocument = async (doc: Document) => {
    try {
      const response = await apiClient.downloadBusinessDocument(businessId, doc.id);
      
      if (response.success && response.download_url) {
        // Create a temporary link to download the file
        const link = document.createElement('a');
        link.href = response.download_url;
        link.download = doc.original_filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        toast.success('Download started!');
        loadDocuments(); // Refresh to update download count
      } else {
        toast.error('Download failed');
      }
    } catch (error: any) {
      toast.error('Download failed');
      console.error('Download error:', error);
    }
  };

  // Open edit modal
  const openEditModal = (document: Document) => {
    setSelectedDocument(document);
    setEditForm({
      category: document.category,
      description: document.description,
      tags: document.tags.join(', '),
      is_public: document.is_public,
    });
    setShowEditModal(true);
  };

  // Format file size
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Get file icon
  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith('image/')) return PhotoIcon;
    if (mimeType.startsWith('video/')) return FilmIcon;
    if (mimeType.includes('pdf')) return DocumentTextIcon;
    if (mimeType.includes('word') || mimeType.includes('document')) return DocumentDuplicateIcon;
    return DocumentIcon;
  };

  // Effects
  useEffect(() => {
    if (isAuthenticated && businessId) {
      loadDocuments();
      loadCategories();
    }
  }, [isAuthenticated, businessId, selectedCategory, searchTerm, currentPage]);

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-gray-50">
        <Sidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <div className="bg-white shadow-sm border-b border-gray-200">
            <div className="px-6 py-4">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Business Documents</h1>
                  <p className="text-gray-600">Manage and organize your business documents</p>
                </div>
                <Button
                  onClick={() => setShowUploadModal(true)}
                  className="flex items-center space-x-2"
                >
                  <ArrowUpTrayIcon className="h-5 w-5" />
                  <span>Upload Document</span>
                </Button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 overflow-auto">
            <div className="p-6">
              <button
                className="mb-4 px-4 py-2 bg-gray-200 rounded hover:bg-gray-300"
                onClick={() => router.back()}
              >
                ← Back
              </button>
              {/* Stats */}
              {stats && (
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                  <div className="bg-white rounded-lg p-4 shadow-sm">
                    <div className="flex items-center">
                      <DocumentIcon className="h-8 w-8 text-blue-600" />
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-500">Total Documents</p>
                        <p className="text-2xl font-bold text-gray-900">{stats.total_documents}</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-4 shadow-sm">
                    <div className="flex items-center">
                      <FolderIcon className="h-8 w-8 text-green-600" />
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-500">Categories</p>
                        <p className="text-2xl font-bold text-gray-900">{stats.categories_count}</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-4 shadow-sm">
                    <div className="flex items-center">
                      <ArchiveBoxIcon className="h-8 w-8 text-purple-600" />
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-500">Total Size</p>
                        <p className="text-2xl font-bold text-gray-900">{formatFileSize(stats.total_size)}</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg p-4 shadow-sm">
                    <div className="flex items-center">
                      <ArrowDownTrayIcon className="h-8 w-8 text-orange-600" />
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-500">Downloads</p>
                        <p className="text-2xl font-bold text-gray-900">
                          {documents.reduce((sum, doc) => sum + doc.download_count, 0)}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Filters */}
              <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Search documents..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      leftIcon={<MagnifyingGlassIcon className="h-5 w-5" />}
                    />
                  </div>
                  <div className="w-full md:w-48">
                    <select
                      value={selectedCategory}
                      onChange={(e) => setSelectedCategory(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="">All Categories</option>
                      {predefinedCategories.map((cat) => (
                        <option key={cat.name} value={cat.name}>
                          {cat.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Documents Grid */}
              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : documents.length === 0 ? (
                <div className="text-center py-12">
                  <DocumentIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No documents found</h3>
                  <p className="text-gray-600 mb-4">
                    {searchTerm || selectedCategory 
                      ? 'Try adjusting your search or filters'
                      : 'Upload your first document to get started'
                    }
                  </p>
                  {!searchTerm && !selectedCategory && (
                    <Button onClick={() => setShowUploadModal(true)}>
                      Upload Document
                    </Button>
                  )}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {documents.map((document) => {
                    const FileIcon = getFileIcon(document.mime_type);
                    return (
                      <div key={document.id} className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
                        <div className="p-4">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex items-center space-x-2">
                              {document.mime_type.startsWith('image/') ? (
                                <div className="w-12 h-12 rounded-lg overflow-hidden bg-gray-100 flex items-center justify-center relative">
                                  <img
                                    src={`http://localhost:8000${document.file_url}`}
                                    alt={document.original_filename}
                                    className="w-full h-full object-cover"
                                    onError={(e) => {
                                      const target = e.target as HTMLImageElement;
                                      target.style.display = 'none';
                                    }}
                                  />
                                  <FileIcon className="absolute inset-0 m-auto h-6 w-6 text-gray-400 opacity-0" />
                                </div>
                              ) : (
                                <FileIcon className="h-8 w-8 text-blue-600" />
                              )}
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-gray-900 truncate">
                                  {document.original_filename}
                                </p>
                                <p className="text-xs text-gray-500">
                                  {formatFileSize(document.file_size)}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-1">
                              <button
                                onClick={() => handleDownloadDocument(document)}
                                className="p-1 text-gray-400 hover:text-blue-600"
                                title="Download"
                              >
                                <ArrowDownTrayIcon className="h-4 w-4" />
                              </button>
                              <button
                                onClick={() => openEditModal(document)}
                                className="p-1 text-gray-400 hover:text-green-600"
                                title="Edit"
                              >
                                <PencilIcon className="h-4 w-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteDocument(document.id)}
                                className="p-1 text-gray-400 hover:text-red-600"
                                title="Delete"
                              >
                                <TrashIcon className="h-4 w-4" />
                              </button>
                            </div>
                          </div>
                          
                          {document.description && (
                            <p className="text-xs text-gray-600 mb-2 line-clamp-2">
                              {document.description}
                            </p>
                          )}
                          
                          <div className="flex items-center justify-between text-xs text-gray-500">
                            <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded">
                              {document.category}
                            </span>
                            <span>{new Date(document.uploaded_at).toLocaleDateString()}</span>
                          </div>
                          
                          {document.tags.length > 0 && (
                            <div className="mt-2 flex flex-wrap gap-1">
                              {document.tags.slice(0, 3).map((tag, index) => (
                                <span
                                  key={index}
                                  className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs"
                                >
                                  {tag}
                                </span>
                              ))}
                              {document.tags.length > 3 && (
                                <span className="text-xs text-gray-500">
                                  +{document.tags.length - 3} more
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Pagination */}
              {pagination && pagination.pages > 1 && (
                <div className="mt-6 flex items-center justify-center">
                  <nav className="flex items-center space-x-2">
                    <button
                      onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                      disabled={currentPage === 1}
                      className="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50"
                    >
                      Previous
                    </button>
                    {Array.from({ length: Math.min(5, pagination.pages) }, (_, i) => {
                      const page = i + 1;
                      return (
                        <button
                          key={page}
                          onClick={() => setCurrentPage(page)}
                          className={`px-3 py-2 text-sm font-medium rounded-md ${
                            currentPage === page
                              ? 'bg-blue-600 text-white'
                              : 'text-gray-500 bg-white border border-gray-300 hover:bg-gray-50'
                          }`}
                        >
                          {page}
                        </button>
                      );
                    })}
                    <button
                      onClick={() => setCurrentPage(Math.min(pagination.pages, currentPage + 1))}
                      disabled={currentPage === pagination.pages}
                      className="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50"
                    >
                      Next
                    </button>
                  </nav>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Upload Modal */}
        {showUploadModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-900">Upload Document</h3>
                <button
                  onClick={() => setShowUploadModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <XMarkIcon className="h-6 w-6" />
                </button>
              </div>
              
              <form onSubmit={handleUpload}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      File
                    </label>
                    <input
                      type="file"
                      onChange={(e) => setUploadForm({ ...uploadForm, file: e.target.files?.[0] || null })}
                      className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Category
                    </label>
                    <select
                      value={uploadForm.category}
                      onChange={(e) => setUploadForm({ ...uploadForm, category: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      {predefinedCategories.map((cat) => (
                        <option key={cat.name} value={cat.name}>
                          {cat.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Description
                    </label>
                    <textarea
                      value={uploadForm.description}
                      onChange={(e) => setUploadForm({ ...uploadForm, description: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      rows={3}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Tags (comma-separated)
                    </label>
                    <input
                      type="text"
                      value={uploadForm.tags}
                      onChange={(e) => setUploadForm({ ...uploadForm, tags: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="tag1, tag2, tag3"
                    />
                  </div>
                </div>
                
                <div className="flex space-x-3 mt-6">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => setShowUploadModal(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button type="submit" loading={uploading} className="flex-1">
                    Upload
                  </Button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Edit Modal */}
        {showEditModal && selectedDocument && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-900">Edit Document</h3>
                <button
                  onClick={() => setShowEditModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <XMarkIcon className="h-6 w-6" />
                </button>
              </div>
              
              <form onSubmit={handleUpdateDocument}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Category
                    </label>
                    <select
                      value={editForm.category}
                      onChange={(e) => setEditForm({ ...editForm, category: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      {predefinedCategories.map((cat) => (
                        <option key={cat.name} value={cat.name}>
                          {cat.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Description
                    </label>
                    <textarea
                      value={editForm.description}
                      onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      rows={3}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Tags (comma-separated)
                    </label>
                    <input
                      type="text"
                      value={editForm.tags}
                      onChange={(e) => setEditForm({ ...editForm, tags: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="tag1, tag2, tag3"
                    />
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="is_public"
                      checked={editForm.is_public}
                      onChange={(e) => setEditForm({ ...editForm, is_public: e.target.checked })}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <label htmlFor="is_public" className="ml-2 block text-sm text-gray-900">
                      Make document public
                    </label>
                  </div>
                </div>
                
                <div className="flex space-x-3 mt-6">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => setShowEditModal(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button type="submit" className="flex-1">
                    Update
                  </Button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
} 