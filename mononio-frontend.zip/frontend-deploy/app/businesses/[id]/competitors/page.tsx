'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth';
import apiClient from '@/lib/api';
import Sidebar from '@/components/layout/Sidebar';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import { Button } from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import {
  MagnifyingGlassIcon,
  PlusIcon,
  PencilIcon,
  TrashIcon,
  EyeIcon,
  ChartBarIcon,
  SparklesIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  XCircleIcon,
  GlobeAltIcon,
  BuildingOfficeIcon,
  CurrencyDollarIcon,
  UserGroupIcon,
  TagIcon,
  ClockIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';

interface Competitor {
  id: number;
  name: string;
  website?: string;
  industry?: string;
  location?: string;
  description?: string;
  market_position?: string;
  competitive_strengths?: string[];
  competitive_weaknesses?: string[];
  unique_selling_proposition?: string;
  social_media_presence?: any;
  website_traffic?: number;
  seo_ranking?: any;
  online_reviews?: any;
  pricing_strategy?: string;
  pricing_range?: any;
  product_offerings?: string[];
  target_audience?: string;
  marketing_channels?: string[];
  advertising_spend?: number;
  content_strategy?: string;
  brand_voice?: string;
  market_share?: number;
  growth_rate?: number;
  customer_satisfaction?: number;
  ai_analysis?: any;
  threat_level?: string;
  opportunity_areas?: string[];
  recommended_actions?: string[];
  is_active?: boolean;
  tracking_enabled?: boolean;
  last_updated?: string;
  update_frequency?: string;
  discovery_method?: string;
  confidence_score?: number;
  notes?: string;
  tags?: string[];
  created_at?: string;
  updated_at?: string;
}

interface CompetitorInsight {
  id: number;
  competitor_id: number;
  insight_type: string;
  title: string;
  description: string;
  insight_data?: any;
  source?: string;
  source_url?: string;
  impact_level?: string;
  impact_description?: string;
  recommended_response?: string;
  verified?: boolean;
  verified_at?: string;
  verified_by?: string;
  ai_generated?: boolean;
  ai_confidence?: number;
  created_at?: string;
}

export default function BusinessCompetitorsPage() {
  const router = useRouter();
  const params = useParams();
  const businessId = params.id as string;
  const { user, isAuthenticated } = useAuthStore();
  
  // State
  const [competitors, setCompetitors] = useState<Competitor[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedThreatLevel, setSelectedThreatLevel] = useState<string>('');
  const [selectedMarketPosition, setSelectedMarketPosition] = useState<string>('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showInsightsModal, setShowInsightsModal] = useState(false);
  const [selectedCompetitor, setSelectedCompetitor] = useState<Competitor | null>(null);
  const [insights, setInsights] = useState<CompetitorInsight[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);
  const [pagination, setPagination] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [aiDiscovering, setAiDiscovering] = useState(false);

  // Form state
  const [competitorForm, setCompetitorForm] = useState({
    name: '',
    website: '',
    industry: '',
    location: '',
    description: '',
    market_position: '',
    competitive_strengths: [] as string[],
    competitive_weaknesses: [] as string[],
    unique_selling_proposition: '',
    pricing_strategy: '',
    target_audience: '',
    notes: '',
    tags: [] as string[],
  });

  // AI discovery form
  const [aiDiscoveryForm, setAiDiscoveryForm] = useState({
    industry: '',
    location: '',
  });
  const [showAiDiscoveryModal, setShowAiDiscoveryModal] = useState(false);

  // Load competitors
  const loadCompetitors = async () => {
    try {
      setLoading(true);
      const response = await apiClient.getBusinessCompetitors(
        businessId,
        searchTerm || undefined,
        selectedThreatLevel || undefined,
        selectedMarketPosition || undefined,
        currentPage
      );

      if (response.success) {
        setCompetitors(response.competitors || []);
        setPagination(response.pagination);
      } else {
        toast.error(response.error || 'Failed to load competitors');
      }
    } catch (error: any) {
      toast.error('Failed to load competitors');
      console.error('Error loading competitors:', error);
    } finally {
      setLoading(false);
    }
  };

  // Load analytics
  const loadAnalytics = async () => {
    try {
      const response = await apiClient.getCompetitorAnalytics(businessId);
      if (response.success) {
        setAnalytics(response.analytics);
      }
    } catch (error) {
      console.error('Error loading analytics:', error);
    }
  };

  // Load insights for a competitor
  const loadInsights = async (competitorId: number) => {
    try {
      const response = await apiClient.getCompetitorInsights(businessId, competitorId.toString());
      if (response.success) {
        setInsights(response.insights || []);
      }
    } catch (error) {
      console.error('Error loading insights:', error);
    }
  };

  // Add competitor
  const handleAddCompetitor = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!competitorForm.name) {
      toast.error('Please enter a competitor name');
      return;
    }

    try {
      const response = await apiClient.createBusinessCompetitor(businessId, competitorForm);

      if (response.success) {
        toast.success('Competitor added successfully!');
        setShowAddModal(false);
        setCompetitorForm({
          name: '',
          website: '',
          industry: '',
          location: '',
          description: '',
          market_position: '',
          competitive_strengths: [],
          competitive_weaknesses: [],
          unique_selling_proposition: '',
          pricing_strategy: '',
          target_audience: '',
          notes: '',
          tags: [],
        });
        loadCompetitors();
        loadAnalytics();
      } else {
        toast.error(response.error || 'Failed to add competitor');
      }
    } catch (error: any) {
      toast.error('Failed to add competitor');
      console.error('Add competitor error:', error);
    }
  };

  // AI discover competitors
  const handleAiDiscover = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!aiDiscoveryForm.industry || !aiDiscoveryForm.location) {
      toast.error('Please enter industry and location');
      return;
    }

    setAiDiscovering(true);
    try {
      const response = await apiClient.aiDiscoverCompetitors(
        businessId,
        aiDiscoveryForm.industry,
        aiDiscoveryForm.location
      );

      if (response.success) {
        toast.success(response.message || 'AI discovery completed!');
        setAiDiscoveryForm({ industry: '', location: '' });
        setShowAiDiscoveryModal(false);
        loadCompetitors();
        loadAnalytics();
      } else {
        toast.error(response.error || 'AI discovery failed');
      }
    } catch (error: any) {
      toast.error('AI discovery failed');
      console.error('AI discovery error:', error);
    } finally {
      setAiDiscovering(false);
    }
  };

  // Delete competitor
  const handleDeleteCompetitor = async (competitorId: number) => {
    if (!confirm('Are you sure you want to delete this competitor?')) return;

    try {
      const response = await apiClient.deleteBusinessCompetitor(businessId, competitorId.toString());

      if (response.success) {
        toast.success('Competitor deleted successfully!');
        loadCompetitors();
        loadAnalytics();
      } else {
        toast.error(response.error || 'Failed to delete competitor');
      }
    } catch (error: any) {
      toast.error('Failed to delete competitor');
      console.error('Delete competitor error:', error);
    }
  };

  // Open insights modal
  const openInsightsModal = async (competitor: Competitor) => {
    setSelectedCompetitor(competitor);
    setShowInsightsModal(true);
    await loadInsights(competitor.id);
  };

  // Get threat level color
  const getThreatLevelColor = (level: string) => {
    switch (level?.toLowerCase()) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  // Get market position color
  const getMarketPositionColor = (position: string) => {
    switch (position?.toLowerCase()) {
      case 'leader': return 'text-blue-600 bg-blue-100';
      case 'challenger': return 'text-orange-600 bg-orange-100';
      case 'follower': return 'text-purple-600 bg-purple-100';
      case 'niche': return 'text-indigo-600 bg-indigo-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  // Format number
  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  useEffect(() => {
    if (isAuthenticated) {
      loadCompetitors();
      loadAnalytics();
    }
  }, [isAuthenticated, businessId, searchTerm, selectedThreatLevel, selectedMarketPosition, currentPage]);

  return (
    <ProtectedRoute>
      <div className="flex h-screen bg-gray-50">
        <Sidebar />
        <div className="flex-1 overflow-auto">
          <div className="p-6">
            <button
              className="mb-4 px-4 py-2 bg-gray-200 rounded hover:bg-gray-300"
              onClick={() => router.back()}
            >
              ← Back
            </button>
            {/* Header */}
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-gray-900">Competitor Tracking</h1>
              <p className="text-gray-600 mt-2">Monitor and analyze your competitors</p>
            </div>

            {/* Analytics Summary */}
            {analytics && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-white p-4 rounded-lg shadow">
                  <div className="flex items-center">
                    <BuildingOfficeIcon className="h-8 w-8 text-blue-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-500">Total Competitors</p>
                      <p className="text-2xl font-bold text-gray-900">{analytics.total_competitors}</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow">
                  <div className="flex items-center">
                    <ExclamationTriangleIcon className="h-8 w-8 text-red-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-500">High Threat</p>
                      <p className="text-2xl font-bold text-gray-900">{analytics.high_threat_competitors || 0}</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow">
                  <div className="flex items-center">
                    <CurrencyDollarIcon className="h-8 w-8 text-green-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-500">Avg Market Share</p>
                      <p className="text-2xl font-bold text-gray-900">{analytics.average_market_share || 0}%</p>
                    </div>
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow">
                  <div className="flex items-center">
                    <ChartBarIcon className="h-8 w-8 text-purple-600" />
                    <div className="ml-3">
                      <p className="text-sm font-medium text-gray-500">Active Tracking</p>
                      <p className="text-2xl font-bold text-gray-900">{competitors.filter(c => c.tracking_enabled).length}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Controls */}
            <div className="bg-white p-4 rounded-lg shadow mb-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <MagnifyingGlassIcon className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <Input
                      type="text"
                      placeholder="Search competitors..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <select
                    value={selectedThreatLevel}
                    onChange={(e) => setSelectedThreatLevel(e.target.value)}
                    className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">All Threat Levels</option>
                    <option value="high">High Threat</option>
                    <option value="medium">Medium Threat</option>
                    <option value="low">Low Threat</option>
                  </select>
                  <select
                    value={selectedMarketPosition}
                    onChange={(e) => setSelectedMarketPosition(e.target.value)}
                    className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">All Positions</option>
                    <option value="leader">Leader</option>
                    <option value="challenger">Challenger</option>
                    <option value="follower">Follower</option>
                    <option value="niche">Niche</option>
                  </select>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => setShowAddModal(true)}
                    className="flex items-center gap-2"
                  >
                    <PlusIcon className="h-5 w-5" />
                    Add Competitor
                  </Button>
                  <Button
                    onClick={() => setShowAiDiscoveryModal(true)}
                    variant="secondary"
                    className="flex items-center gap-2"
                  >
                    <SparklesIcon className="h-5 w-5" />
                    AI Discover
                  </Button>
                </div>
              </div>
            </div>

            {/* Competitors List */}
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
                <p className="mt-4 text-gray-600">Loading competitors...</p>
              </div>
            ) : competitors.length === 0 ? (
              <div className="text-center py-8">
                <BuildingOfficeIcon className="h-12 w-12 text-gray-400 mx-auto" />
                <h3 className="mt-4 text-lg font-medium text-gray-900">No competitors found</h3>
                <p className="mt-2 text-gray-600">Add your first competitor or use AI discovery to find them automatically.</p>
                <div className="mt-4 flex gap-2 justify-center">
                  <Button onClick={() => setShowAddModal(true)}>
                    Add Competitor
                  </Button>
                  <Button variant="secondary" onClick={() => setShowAiDiscoveryModal(true)}>
                    AI Discover
                  </Button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {competitors.map((competitor) => (
                  <div key={competitor.id} className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow">
                    <div className="p-6">
                      {/* Header */}
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-gray-900">{competitor.name}</h3>
                          {competitor.website && (
                            <a
                              href={competitor.website}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-sm text-blue-600 hover:text-blue-800 flex items-center gap-1"
                            >
                              <GlobeAltIcon className="h-4 w-4" />
                              {competitor.website.replace(/^https?:\/\//, '')}
                            </a>
                          )}
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openInsightsModal(competitor)}
                            title="View Insights"
                          >
                            <EyeIcon className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setSelectedCompetitor(competitor);
                              setShowEditModal(true);
                            }}
                            title="Edit"
                          >
                            <PencilIcon className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteCompetitor(competitor.id)}
                            title="Delete"
                          >
                            <TrashIcon className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      {/* Tags */}
                      <div className="flex flex-wrap gap-2 mb-4">
                        {competitor.threat_level && (
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${getThreatLevelColor(competitor.threat_level)}`}>
                            {competitor.threat_level} Threat
                          </span>
                        )}
                        {competitor.market_position && (
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${getMarketPositionColor(competitor.market_position)}`}>
                            {competitor.market_position}
                          </span>
                        )}
                        {competitor.discovery_method === 'ai_discovered' && (
                          <span className="px-2 py-1 text-xs font-medium rounded-full bg-purple-100 text-purple-600">
                            AI Discovered
                          </span>
                        )}
                      </div>

                      {/* Description */}
                      {competitor.description && (
                        <p className="text-sm text-gray-600 mb-4">{competitor.description}</p>
                      )}

                      {/* Key Metrics */}
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        {competitor.market_share && (
                          <div>
                            <p className="text-xs text-gray-500">Market Share</p>
                            <p className="text-sm font-semibold">{competitor.market_share}%</p>
                          </div>
                        )}
                        {competitor.growth_rate && (
                          <div>
                            <p className="text-xs text-gray-500">Growth Rate</p>
                            <p className="text-sm font-semibold">{competitor.growth_rate}%</p>
                          </div>
                        )}
                        {competitor.website_traffic && (
                          <div>
                            <p className="text-xs text-gray-500">Monthly Traffic</p>
                            <p className="text-sm font-semibold">{formatNumber(competitor.website_traffic)}</p>
                          </div>
                        )}
                        {competitor.customer_satisfaction && (
                          <div>
                            <p className="text-xs text-gray-500">Satisfaction</p>
                            <p className="text-sm font-semibold">{competitor.customer_satisfaction}/5</p>
                          </div>
                        )}
                      </div>

                      {/* Strengths & Weaknesses */}
                      {competitor.competitive_strengths && competitor.competitive_strengths.length > 0 && (
                        <div className="mb-3">
                          <p className="text-xs font-medium text-gray-700 mb-1">Strengths</p>
                          <div className="flex flex-wrap gap-1">
                            {competitor.competitive_strengths.slice(0, 3).map((strength, index) => (
                              <span key={index} className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded">
                                {strength}
                              </span>
                            ))}
                            {competitor.competitive_strengths.length > 3 && (
                              <span className="px-2 py-1 text-xs bg-gray-100 text-gray-600 rounded">
                                +{competitor.competitive_strengths.length - 3} more
                              </span>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Last Updated */}
                      {competitor.last_updated && (
                        <div className="flex items-center text-xs text-gray-500">
                          <ClockIcon className="h-3 w-3 mr-1" />
                          Updated {new Date(competitor.last_updated).toLocaleDateString()}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Pagination */}
            {pagination && pagination.pages > 1 && (
              <div className="mt-6 flex justify-center">
                <div className="flex gap-2">
                  {Array.from({ length: pagination.pages }, (_, i) => i + 1).map((page) => (
                    <Button
                      key={page}
                      variant={page === currentPage ? "primary" : "ghost"}
                      size="sm"
                      onClick={() => setCurrentPage(page)}
                    >
                      {page}
                    </Button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Add Competitor Modal */}
        {showAddModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <h2 className="text-xl font-semibold mb-4">Add New Competitor</h2>
              <form onSubmit={handleAddCompetitor}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                    <Input
                      value={competitorForm.name}
                      onChange={(e) => setCompetitorForm({ ...competitorForm, name: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Website</label>
                    <Input
                      value={competitorForm.website}
                      onChange={(e) => setCompetitorForm({ ...competitorForm, website: e.target.value })}
                      placeholder="https://example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Industry</label>
                    <Input
                      value={competitorForm.industry}
                      onChange={(e) => setCompetitorForm({ ...competitorForm, industry: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                    <Input
                      value={competitorForm.location}
                      onChange={(e) => setCompetitorForm({ ...competitorForm, location: e.target.value })}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                    <textarea
                      value={competitorForm.description}
                      onChange={(e) => setCompetitorForm({ ...competitorForm, description: e.target.value })}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      rows={3}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Market Position</label>
                    <select
                      value={competitorForm.market_position}
                      onChange={(e) => setCompetitorForm({ ...competitorForm, market_position: e.target.value })}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Select position</option>
                      <option value="leader">Leader</option>
                      <option value="challenger">Challenger</option>
                      <option value="follower">Follower</option>
                      <option value="niche">Niche</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Pricing Strategy</label>
                    <select
                      value={competitorForm.pricing_strategy}
                      onChange={(e) => setCompetitorForm({ ...competitorForm, pricing_strategy: e.target.value })}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Select strategy</option>
                      <option value="premium">Premium</option>
                      <option value="competitive">Competitive</option>
                      <option value="budget">Budget</option>
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Target Audience</label>
                    <Input
                      value={competitorForm.target_audience}
                      onChange={(e) => setCompetitorForm({ ...competitorForm, target_audience: e.target.value })}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                    <textarea
                      value={competitorForm.notes}
                      onChange={(e) => setCompetitorForm({ ...competitorForm, notes: e.target.value })}
                      className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      rows={2}
                    />
                  </div>
                </div>
                <div className="flex gap-2 mt-6">
                  <Button type="submit">Add Competitor</Button>
                  <Button variant="secondary" onClick={() => setShowAddModal(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* AI Discovery Modal */}
        {showAiDiscoveryModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <h2 className="text-xl font-semibold mb-4">AI Competitor Discovery</h2>
              <form onSubmit={handleAiDiscover}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Industry *</label>
                    <Input
                      value={aiDiscoveryForm.industry}
                      onChange={(e) => setAiDiscoveryForm({ ...aiDiscoveryForm, industry: e.target.value })}
                      placeholder="e.g., technology, healthcare, retail"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Location *</label>
                    <Input
                      value={aiDiscoveryForm.location}
                      onChange={(e) => setAiDiscoveryForm({ ...aiDiscoveryForm, location: e.target.value })}
                      placeholder="e.g., San Francisco, CA"
                      required
                    />
                  </div>
                </div>
                <div className="flex gap-2 mt-6">
                  <Button type="submit" disabled={aiDiscovering}>
                    {aiDiscovering ? 'Discovering...' : 'Discover Competitors'}
                  </Button>
                  <Button variant="secondary" onClick={() => {
                    setShowAiDiscoveryModal(false);
                    setAiDiscoveryForm({ industry: '', location: '' });
                  }}>
                    Cancel
                  </Button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Insights Modal */}
        {showInsightsModal && selectedCompetitor && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">Insights for {selectedCompetitor.name}</h2>
                <Button variant="ghost" onClick={() => setShowInsightsModal(false)}>
                  <XCircleIcon className="h-5 w-5" />
                </Button>
              </div>
              
              {insights.length === 0 ? (
                <div className="text-center py-8">
                  <ChartBarIcon className="h-12 w-12 text-gray-400 mx-auto" />
                  <h3 className="mt-4 text-lg font-medium text-gray-900">No insights yet</h3>
                  <p className="mt-2 text-gray-600">Insights will appear here as we monitor this competitor.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {insights.map((insight) => (
                    <div key={insight.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-medium text-gray-900">{insight.title}</h3>
                        <div className="flex items-center gap-2">
                          {insight.verified ? (
                            <CheckCircleIcon className="h-4 w-4 text-green-600" title="Verified" />
                          ) : (
                            <ExclamationTriangleIcon className="h-4 w-4 text-yellow-600" title="Unverified" />
                          )}
                          {insight.ai_generated && (
                            <SparklesIcon className="h-4 w-4 text-purple-600" title="AI Generated" />
                          )}
                        </div>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{insight.description}</p>
                      {insight.impact_level && (
                        <span className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${getThreatLevelColor(insight.impact_level)}`}>
                          {insight.impact_level} Impact
                        </span>
                      )}
                      {insight.recommended_response && (
                        <div className="mt-2 p-2 bg-blue-50 rounded">
                          <p className="text-xs font-medium text-blue-800">Recommended Response:</p>
                          <p className="text-xs text-blue-700">{insight.recommended_response}</p>
                        </div>
                      )}
                      <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                        <span>{insight.source}</span>
                        <span>{insight.created_at ? new Date(insight.created_at).toLocaleDateString() : 'N/A'}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
} 