# Authentication Debugging Guide

## Current Status
- ✅ Backend server is running on http://localhost:8001
- ✅ Frontend server is running on http://localhost:3003
- ✅ API endpoints are working (tested with curl)
- ✅ CORS is properly configured for all frontend ports

## Debugging Steps

### 1. Open Browser Developer Tools
1. Open http://localhost:3003 in your browser
2. Press F12 to open Developer Tools
3. Go to the **Console** tab
4. Clear the console (click the 🚫 icon)

### 2. Test the Authentication Flow
1. You should see the main page loading with "Loading LaunchMate DIAMOND..."
2. Check the console for auth store initialization logs:
   ```
   🔐 Auth store: Initializing...
   🔐 Auth store: Token found: false
   🔐 Auth store: No token found, user not authenticated
   ```

3. You should be redirected to the login page
4. Enter the demo credentials:
   - **Email:** demo@launchmate.com
   - **Password:** demo123

5. Click "Sign in" and watch the console for logs:
   ```
   📝 Login Page: Form submitted with email: demo@launchmate.com
   📝 Login Page: Calling auth store login method...
   🔐 Auth store: Attempting login for: demo@launchmate.com
   🔑 API Client: Login attempt with credentials: {email: "demo@launchmate.com", password: "demo123"}
   🌐 API Request: {url: "http://localhost:8001/auth/login", method: "POST", ...}
   🌐 API Response: {status: 200, ...}
   🌐 API Success: {access_token: "...", user: {...}}
   🔑 API Client: Login response received: {...}
   🔑 API Client: Token stored in localStorage
   🔐 Auth store: Login successful: {...}
   📝 Login Page: Login result: true
   📝 Login Page: Login successful, redirecting to dashboard...
   ```

### 3. If Login Fails
If you see any errors in the console, they will help identify the issue:

- **Network errors**: Check if backend is running
- **CORS errors**: Check if CORS is properly configured
- **API errors**: Check if the API endpoint is working
- **Token errors**: Check if token is being stored properly

### 4. Test API Directly
You can also test the API directly using the test file:
1. Open `frontend/test-api.html` in your browser
2. Click "Test Login" to verify the API is working
3. Click "Test Get Current User" to verify token authentication

### 5. Common Issues and Solutions

#### Issue: "Cannot connect to backend"
**Solution**: Make sure the backend is running:
```bash
python3 -m uvicorn app.simple_api:app --host 0.0.0.0 --port 8001 --reload
```

#### Issue: "CORS error"
**Solution**: The backend now has CORS configured for all frontend ports (3000-3003)

#### Issue: "Token not stored"
**Solution**: Check if localStorage is available in the browser

#### Issue: "Login returns false"
**Solution**: Check the console logs to see where the failure occurs

### 6. Expected Behavior
1. **First visit**: Redirect to login page
2. **Login success**: Redirect to dashboard
3. **Login failure**: Stay on login page with error message
4. **Dashboard access**: Show dashboard with user info
5. **Logout**: Clear token and redirect to login

### 7. Console Logs to Look For
- 🔐 Auth store logs (authentication state)
- 🌐 API logs (network requests)
- 🔑 API Client logs (login process)
- 📝 Login Page logs (user interaction)

## Demo Credentials
- **Email:** demo@launchmate.com
- **Password:** demo123

## Server URLs
- **Frontend:** http://localhost:3003
- **Backend:** http://localhost:8001

## Next Steps
If the authentication is still not working after following these steps, please share the console logs so I can help identify the specific issue. 