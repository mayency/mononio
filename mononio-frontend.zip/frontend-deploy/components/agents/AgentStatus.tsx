'use client';

import { useState, useEffect } from 'react';
import apiClient from '@/lib/api';
import {
  CheckCircleIcon,
  XCircleIcon,
  ClockIcon,
  ExclamationTriangleIcon,
  SparklesIcon,
  CogIcon,
} from '@heroicons/react/24/outline';

interface AgentStatusProps {
  businessId?: string;
  showDetails?: boolean;
}

interface AgentInfo {
  name: string;
  available: boolean;
  description: string;
  error?: string;
}

export default function AgentStatus({ businessId, showDetails = false }: AgentStatusProps) {
  const [agents, setAgents] = useState<AgentInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchAgentStatus();
  }, [businessId]);

  const fetchAgentStatus = async () => {
    try {
      setLoading(true);
      const response = await apiClient.getAllAgentsStatus();
      
      if (response.success && response.agents) {
        setAgents(response.agents);
      } else {
        setError(response.error || 'Failed to fetch agent status');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to fetch agent status');
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (available: boolean) => {
    if (available) {
      return <CheckCircleIcon className="h-5 w-5 text-green-500" />;
    } else {
      return <XCircleIcon className="h-5 w-5 text-red-500" />;
    }
  };

  const getStatusColor = (available: boolean) => {
    return available ? 'text-green-600' : 'text-red-600';
  };

  const getStatusText = (available: boolean) => {
    return available ? 'Online' : 'Offline';
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center space-x-2">
          <CogIcon className="h-5 w-5 animate-spin text-primary-600" />
          <span className="text-sm text-secondary-600">Loading agent status...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center space-x-2">
          <ExclamationTriangleIcon className="h-5 w-5 text-red-500" />
          <span className="text-sm text-red-600">{error}</span>
        </div>
      </div>
    );
  }

  const onlineAgents = agents.filter(agent => agent.available);
  const offlineAgents = agents.filter(agent => !agent.available);

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="px-6 py-4 border-b border-secondary-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <SparklesIcon className="h-6 w-6 text-primary-600" />
            <h3 className="text-lg font-semibold text-secondary-900">AI Agents Status</h3>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <CheckCircleIcon className="h-4 w-4 text-green-500" />
              <span className="text-sm text-secondary-600">
                {onlineAgents.length} Online
              </span>
            </div>
            <div className="flex items-center space-x-1">
              <XCircleIcon className="h-4 w-4 text-red-500" />
              <span className="text-sm text-secondary-600">
                {offlineAgents.length} Offline
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {agents.map((agent) => (
            <div
              key={agent.name}
              className={`p-4 rounded-lg border ${
                agent.available
                  ? 'border-green-200 bg-green-50'
                  : 'border-red-200 bg-red-50'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    {getStatusIcon(agent.available)}
                    <h4 className="font-medium text-secondary-900 capitalize">
                      {agent.name.replace('_', ' ')}
                    </h4>
                  </div>
                  
                  <p className="text-sm text-secondary-600 mb-2">
                    {agent.description}
                  </p>
                  
                  <div className="flex items-center space-x-2">
                    <span className={`text-xs font-medium ${getStatusColor(agent.available)}`}>
                      {getStatusText(agent.available)}
                    </span>
                  </div>

                  {agent.error && showDetails && (
                    <div className="mt-2 p-2 bg-red-100 rounded text-xs text-red-700">
                      Error: {agent.error}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {showDetails && (
          <div className="mt-6 pt-6 border-t border-secondary-200">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-secondary-900 mb-3">Online Agents</h4>
                <div className="space-y-2">
                  {onlineAgents.map((agent) => (
                    <div key={agent.name} className="flex items-center space-x-2">
                      <CheckCircleIcon className="h-4 w-4 text-green-500" />
                      <span className="text-sm text-secondary-700 capitalize">
                        {agent.name.replace('_', ' ')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-medium text-secondary-900 mb-3">Offline Agents</h4>
                <div className="space-y-2">
                  {offlineAgents.map((agent) => (
                    <div key={agent.name} className="flex items-center space-x-2">
                      <XCircleIcon className="h-4 w-4 text-red-500" />
                      <span className="text-sm text-secondary-700 capitalize">
                        {agent.name.replace('_', ' ')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
} 