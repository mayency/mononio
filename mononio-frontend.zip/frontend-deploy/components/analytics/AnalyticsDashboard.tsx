'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { 
  BarChart, 
  LineChart, 
  PieChart, 
  Activity, 
  Users, 
  TrendingUp, 
  Clock, 
  Filter,
  Download,
  Settings,
  RefreshCw,
  AlertTriangle,
  Eye,
  Layers,
  Target
} from 'lucide-react';

interface AnalyticsData {
  property_id: string;
  report_type: string;
  dimension_headers: string[];
  metric_headers: string[];
  rows: Array<{
    dimensions: string[];
    metrics: string[];
  }>;
  row_count: number;
  totals?: string[][];
  metadata?: {
    currency_code?: string;
    time_zone?: string;
    refresh_interval?: number;
    last_updated?: string;
  };
}

interface ReportRequest {
  property_id: string;
  date_ranges: Array<{
    start_date: string;
    end_date: string;
  }>;
  dimensions: string[];
  metrics: string[];
  limit?: number;
  offset?: number;
}

interface MetadataItem {
  api_name: string;
  ui_name: string;
  description: string;
  type?: string;
  custom_definition?: boolean;
}

interface PropertyMetadata {
  dimensions: MetadataItem[];
  metrics: MetadataItem[];
  dimension_count: number;
  metric_count: number;
}

export default function AnalyticsDashboard() {
  // State management
  const [propertyId, setPropertyId] = useState<string>('123456789');
  const [activeTab, setActiveTab] = useState<'standard' | 'realtime' | 'pivot' | 'funnel' | 'builder'>('standard');
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [realtimeData, setRealtimeData] = useState<AnalyticsData | null>(null);
  const [metadata, setMetadata] = useState<PropertyMetadata | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  // Report builder state
  const [selectedDimensions, setSelectedDimensions] = useState<string[]>(['date']);
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>(['sessions', 'users']);
  const [dateRange, setDateRange] = useState({
    start_date: '2025-01-01',
    end_date: '2025-01-31'
  });

  // Real-time update interval
  const [realtimeInterval, setRealtimeInterval] = useState<NodeJS.Timeout | null>(null);

  // ============================================================================
  // API FUNCTIONS
  // ============================================================================

  const fetchAnalyticsData = useCallback(async (reportType: string, customRequest?: any) => {
    setIsLoading(true);
    setError(null);

    try {
      const authToken = localStorage.getItem('auth_token');
      let url = '';
      let requestBody: any = {};

      switch (reportType) {
        case 'standard':
          url = '/api/analytics/reports/standard';
          requestBody = customRequest || {
            property_id: propertyId,
            date_ranges: [dateRange],
            dimensions: selectedDimensions,
            metrics: selectedMetrics,
            limit: 1000
          };
          break;

        case 'realtime':
          url = '/api/analytics/reports/realtime';
          requestBody = {
            property_id: propertyId,
            dimensions: ['country', 'deviceCategory'],
            metrics: ['activeUsers', 'screenPageViews'],
            limit: 100
          };
          break;

        case 'pivot':
          url = '/api/analytics/reports/pivot';
          requestBody = {
            property_id: propertyId,
            date_ranges: [dateRange],
            dimensions: selectedDimensions,
            metrics: selectedMetrics,
            pivots: [
              {
                field_names: [selectedDimensions[0] || 'date'],
                limit: 100,
                offset: 0
              }
            ]
          };
          break;

        case 'funnel':
          url = '/api/analytics/reports/funnel';
          requestBody = {
            property_id: propertyId,
            date_ranges: [dateRange],
            funnel_steps: [
              {
                name: 'Page View',
                is_directly_followed_by: false
              },
              {
                name: 'Button Click',
                is_directly_followed_by: true,
                duration: '30m'
              },
              {
                name: 'Purchase',
                is_directly_followed_by: false
              }
            ],
            breakdown_dimension: 'deviceCategory'
          };
          break;

        case 'batch':
          url = '/api/analytics/reports/batch';
          requestBody = {
            property_id: propertyId,
            reports: [
              {
                property_id: propertyId,
                date_ranges: [dateRange],
                dimensions: ['date'],
                metrics: ['sessions'],
                limit: 30
              },
              {
                property_id: propertyId,
                date_ranges: [dateRange],
                dimensions: ['deviceCategory'],
                metrics: ['users'],
                limit: 10
              }
            ]
          };
          break;
      }

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify(requestBody)
      });

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`);
      }

      const result = await response.json();
      
      if (result.success) {
        if (reportType === 'realtime') {
          setRealtimeData(result.realtime_data || result.report_data);
        } else {
          setAnalyticsData(result.report_data || result.batch_reports || result.pivot_data || result.funnel_data);
        }
        setLastUpdated(new Date());
      } else {
        throw new Error(result.error || 'Unknown error occurred');
      }

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch analytics data');
      console.error('Analytics API error:', err);
    } finally {
      setIsLoading(false);
    }
  }, [propertyId, selectedDimensions, selectedMetrics, dateRange]);

  const fetchMetadata = useCallback(async () => {
    try {
      const authToken = localStorage.getItem('auth_token');
      
      const response = await fetch(`/api/analytics/metadata/${propertyId}`, {
        headers: {
          'Authorization': `Bearer ${authToken}`
        }
      });

      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          setMetadata(result.metadata);
        }
      }
    } catch (err) {
      console.error('Metadata fetch error:', err);
    }
  }, [propertyId]);

  // ============================================================================
  // EFFECTS
  // ============================================================================

  useEffect(() => {
    // Load metadata on component mount
    fetchMetadata();
  }, [fetchMetadata]);

  useEffect(() => {
    // Auto-refresh real-time data when on real-time tab
    if (activeTab === 'realtime') {
      // Initial load
      fetchAnalyticsData('realtime');
      
      // Set up interval for auto-refresh (every 60 seconds)
      const interval = setInterval(() => {
        fetchAnalyticsData('realtime');
      }, 60000);
      
      setRealtimeInterval(interval);
      
      return () => {
        if (interval) clearInterval(interval);
      };
    } else {
      // Clear interval when leaving real-time tab
      if (realtimeInterval) {
        clearInterval(realtimeInterval);
        setRealtimeInterval(null);
      }
    }
  }, [activeTab, fetchAnalyticsData]);

  // ============================================================================
  // RENDER FUNCTIONS
  // ============================================================================

  const renderTabNavigation = () => (
    <div className="flex space-x-4 border-b border-gray-200 mb-6">
      {[
        { key: 'standard', label: 'Standard Reports', icon: BarChart },
        { key: 'realtime', label: 'Real-time', icon: Activity },
        { key: 'pivot', label: 'Pivot Tables', icon: Layers },
        { key: 'funnel', label: 'Funnels', icon: Target },
        { key: 'builder', label: 'Report Builder', icon: Settings }
      ].map(({ key, label, icon: Icon }) => (
        <button
          key={key}
          onClick={() => setActiveTab(key as any)}
          className={`flex items-center space-x-2 px-4 py-2 border-b-2 font-medium text-sm ${
            activeTab === key
              ? 'border-blue-500 text-blue-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          <Icon className="w-4 h-4" />
          <span>{label}</span>
          {key === 'funnel' && (
            <span className="px-1.5 py-0.5 text-xs bg-orange-100 text-orange-800 rounded">
              Alpha
            </span>
          )}
        </button>
      ))}
    </div>
  );

  const renderPropertySelector = () => (
    <div className="mb-6 p-4 bg-gray-50 rounded-lg">
      <label className="block text-sm font-medium text-gray-700 mb-2">
        GA4 Property ID
      </label>
      <div className="flex items-center space-x-4">
        <input
          type="text"
          value={propertyId}
          onChange={(e) => setPropertyId(e.target.value)}
          placeholder="Enter GA4 Property ID"
          className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          onClick={() => fetchAnalyticsData(activeTab)}
          disabled={isLoading}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 flex items-center space-x-2"
        >
          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>
    </div>
  );

  const renderReportBuilder = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Dimensions Selector */}
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Select Dimensions</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {metadata?.dimensions.map((dimension) => (
              <label key={dimension.api_name} className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={selectedDimensions.includes(dimension.api_name)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSelectedDimensions([...selectedDimensions, dimension.api_name]);
                    } else {
                      setSelectedDimensions(selectedDimensions.filter(d => d !== dimension.api_name));
                    }
                  }}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                />
                <div>
                  <div className="text-sm font-medium text-gray-900">{dimension.ui_name}</div>
                  <div className="text-xs text-gray-500">{dimension.description}</div>
                </div>
              </label>
            ))}
          </div>
          <div className="mt-4 text-sm text-gray-600">
            Selected: {selectedDimensions.length} dimensions
          </div>
        </div>

        {/* Metrics Selector */}
        <div className="bg-white p-6 rounded-lg border border-gray-200">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Select Metrics</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {metadata?.metrics.map((metric) => (
              <label key={metric.api_name} className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={selectedMetrics.includes(metric.api_name)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSelectedMetrics([...selectedMetrics, metric.api_name]);
                    } else {
                      setSelectedMetrics(selectedMetrics.filter(m => m !== metric.api_name));
                    }
                  }}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                />
                <div>
                  <div className="text-sm font-medium text-gray-900">{metric.ui_name}</div>
                  <div className="text-xs text-gray-500">{metric.description}</div>
                  {metric.type && (
                    <div className="text-xs text-blue-600">{metric.type}</div>
                  )}
                </div>
              </label>
            ))}
          </div>
          <div className="mt-4 text-sm text-gray-600">
            Selected: {selectedMetrics.length} metrics
          </div>
        </div>
      </div>

      {/* Date Range Selector */}
      <div className="bg-white p-6 rounded-lg border border-gray-200">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Date Range</h3>
        <div className="flex items-center space-x-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
            <input
              type="date"
              value={dateRange.start_date}
              onChange={(e) => setDateRange({...dateRange, start_date: e.target.value})}
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
            <input
              type="date"
              value={dateRange.end_date}
              onChange={(e) => setDateRange({...dateRange, end_date: e.target.value})}
              className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Generate Report Button */}
      <div className="flex justify-end">
        <button
          onClick={() => fetchAnalyticsData('standard')}
          disabled={isLoading || selectedDimensions.length === 0 || selectedMetrics.length === 0}
          className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center space-x-2"
        >
          <BarChart className="w-5 h-5" />
          <span>{isLoading ? 'Generating...' : 'Generate Report'}</span>
        </button>
      </div>
    </div>
  );

  const renderDataTable = (data: AnalyticsData, title: string) => (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium text-gray-900">{title}</h3>
          {data.metadata?.last_updated && (
            <p className="text-sm text-gray-500">
              Last updated: {new Date(data.metadata.last_updated).toLocaleString()}
            </p>
          )}
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-500">
            {data.row_count} rows
          </span>
          {activeTab === 'realtime' && (
            <div className="flex items-center space-x-1 text-green-600">
              <Activity className="w-4 h-4" />
              <span className="text-sm">Live</span>
            </div>
          )}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              {data.dimension_headers.map((header, index) => (
                <th
                  key={index}
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  {header}
                </th>
              ))}
              {data.metric_headers.map((header, index) => (
                <th
                  key={index}
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {data.rows.slice(0, 50).map((row, rowIndex) => (
              <tr key={rowIndex} className="hover:bg-gray-50">
                {row.dimensions.map((dimension, dimIndex) => (
                  <td key={dimIndex} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {dimension}
                  </td>
                ))}
                {row.metrics.map((metric, metricIndex) => (
                  <td key={metricIndex} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {typeof metric === 'number' ? metric.toLocaleString() : metric}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {data.row_count > 50 && (
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
          <p className="text-sm text-gray-600">
            Showing first 50 rows of {data.row_count} total rows
          </p>
        </div>
      )}
    </div>
  );

  const renderQuickActions = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <button
        onClick={() => fetchAnalyticsData('standard')}
        disabled={isLoading}
        className="p-4 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-50"
      >
        <div className="flex items-center space-x-3">
          <BarChart className="w-8 h-8 text-blue-600" />
          <div className="text-left">
            <div className="font-medium text-gray-900">Standard Report</div>
            <div className="text-sm text-gray-500">Generate custom report</div>
          </div>
        </div>
      </button>

      <button
        onClick={() => fetchAnalyticsData('batch')}
        disabled={isLoading}
        className="p-4 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-50"
      >
        <div className="flex items-center space-x-3">
          <Layers className="w-8 h-8 text-green-600" />
          <div className="text-left">
            <div className="font-medium text-gray-900">Batch Reports</div>
            <div className="text-sm text-gray-500">Multiple reports at once</div>
          </div>
        </div>
      </button>

      <button
        onClick={() => fetchAnalyticsData('pivot')}
        disabled={isLoading}
        className="p-4 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-50"
      >
        <div className="flex items-center space-x-3">
          <PieChart className="w-8 h-8 text-purple-600" />
          <div className="text-left">
            <div className="font-medium text-gray-900">Pivot Table</div>
            <div className="text-sm text-gray-500">Cross-data analysis</div>
          </div>
        </div>
      </button>

      <button
        onClick={() => fetchAnalyticsData('funnel')}
        disabled={isLoading}
        className="p-4 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-50"
      >
        <div className="flex items-center space-x-3">
          <Target className="w-8 h-8 text-orange-600" />
          <div className="text-left">
            <div className="flex items-center space-x-1">
              <span className="font-medium text-gray-900">Funnel Report</span>
              <span className="px-1.5 py-0.5 text-xs bg-orange-100 text-orange-800 rounded">
                Alpha
              </span>
            </div>
            <div className="text-sm text-gray-500">User journey analysis</div>
          </div>
        </div>
      </button>
    </div>
  );

  // ============================================================================
  // MAIN RENDER
  // ============================================================================

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Google Analytics Data API Dashboard
        </h1>
        <p className="text-gray-600">
          Comprehensive analytics reporting with real-time data, pivot tables, and funnel analysis
        </p>
      </div>

      {/* Property Selector */}
      {renderPropertySelector()}

      {/* Error Display */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center space-x-3">
          <AlertTriangle className="w-5 h-5 text-red-600" />
          <div>
            <p className="text-red-800 font-medium">Error loading analytics data</p>
            <p className="text-red-600 text-sm">{error}</p>
          </div>
        </div>
      )}

      {/* Tab Navigation */}
      {renderTabNavigation()}

      {/* Quick Actions (only show on standard tab) */}
      {activeTab === 'standard' && renderQuickActions()}

      {/* Tab Content */}
      <div className="space-y-6">
        {activeTab === 'builder' && renderReportBuilder()}

        {activeTab === 'realtime' && (
          <div>
            <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center space-x-3">
              <Activity className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-green-800 font-medium">Real-time Data</p>
                <p className="text-green-600 text-sm">Updates automatically every 60 seconds</p>
              </div>
            </div>
            {realtimeData && renderDataTable(realtimeData, 'Real-time Analytics')}
          </div>
        )}

        {(activeTab === 'standard' || activeTab === 'pivot' || activeTab === 'funnel') && analyticsData && (
          <div>
            {renderDataTable(
              analyticsData,
              activeTab === 'pivot' ? 'Pivot Table Analysis' :
              activeTab === 'funnel' ? 'Funnel Analysis (Alpha)' :
              'Standard Analytics Report'
            )}
          </div>
        )}

        {/* Metadata Display */}
        {metadata && activeTab === 'builder' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
            <div className="bg-white p-6 rounded-lg border border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Available Dimensions ({metadata.dimension_count})
              </h3>
              <div className="text-sm text-gray-600 space-y-1">
                {metadata.dimensions.slice(0, 5).map(dim => (
                  <div key={dim.api_name}>
                    <span className="font-medium">{dim.ui_name}</span> - {dim.description}
                  </div>
                ))}
                {metadata.dimension_count > 5 && (
                  <div className="text-gray-500">... and {metadata.dimension_count - 5} more</div>
                )}
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg border border-gray-200">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Available Metrics ({metadata.metric_count})
              </h3>
              <div className="text-sm text-gray-600 space-y-1">
                {metadata.metrics.slice(0, 5).map(metric => (
                  <div key={metric.api_name}>
                    <span className="font-medium">{metric.ui_name}</span> - {metric.description}
                  </div>
                ))}
                {metadata.metric_count > 5 && (
                  <div className="text-gray-500">... and {metadata.metric_count - 5} more</div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Loading State */}
        {isLoading && (
          <div className="flex items-center justify-center py-12">
            <div className="flex items-center space-x-3">
              <RefreshCw className="w-6 h-6 animate-spin text-blue-600" />
              <span className="text-gray-600">Loading analytics data...</span>
            </div>
          </div>
        )}

        {/* Last Updated */}
        {lastUpdated && !isLoading && (
          <div className="text-center text-sm text-gray-500">
            Last updated: {lastUpdated.toLocaleString()}
          </div>
        )}
      </div>
    </div>
  );
} 