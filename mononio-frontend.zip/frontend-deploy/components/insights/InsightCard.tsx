'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/Button';
import {
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  MinusIcon,
  ChevronRightIcon,
  LightBulbIcon,
  CheckCircleIcon,
  ExclamationTriangleIcon,
} from '@heroicons/react/24/outline';

interface InsightCardProps {
  question: string;
  answer: string;
  trend: 'up' | 'down' | 'neutral';
  confidence: 'high' | 'medium' | 'low';
  action: string;
  actionUrl: string;
  detailData?: {
    metrics?: Record<string, any>;
    explanation?: string;
    recommendations?: string[];
  };
  priority?: 'critical' | 'important' | 'normal';
}

function TrendIcon({ trend }: { trend: 'up' | 'down' | 'neutral' }) {
  const iconClass = "h-6 w-6";
  
  switch (trend) {
    case 'up':
      return <ArrowTrendingUpIcon className={`${iconClass} text-green-600`} />;
    case 'down':
      return <ArrowTrendingDownIcon className={`${iconClass} text-red-600`} />;
    case 'neutral':
      return <MinusIcon className={`${iconClass} text-yellow-600`} />;
  }
}

function ConfidenceIndicator({ confidence }: { confidence: 'high' | 'medium' | 'low' }) {
  const baseClass = "inline-flex items-center px-2 py-1 rounded-full text-xs font-medium";
  
  switch (confidence) {
    case 'high':
      return (
        <span className={`${baseClass} bg-green-100 text-green-800`}>
          <CheckCircleIcon className="h-3 w-3 mr-1" />
          High confidence
        </span>
      );
    case 'medium':
      return (
        <span className={`${baseClass} bg-yellow-100 text-yellow-800`}>
          <LightBulbIcon className="h-3 w-3 mr-1" />
          Medium confidence
        </span>
      );
    case 'low':
      return (
        <span className={`${baseClass} bg-gray-100 text-gray-800`}>
          <ExclamationTriangleIcon className="h-3 w-3 mr-1" />
          Low confidence
        </span>
      );
  }
}

export function InsightCard({
  question,
  answer,
  trend,
  confidence,
  action,
  actionUrl,
  detailData,
  priority = 'normal'
}: InsightCardProps) {
  const [showDetails, setShowDetails] = useState(false);
  
  const cardClass = `
    bg-white p-6 rounded-lg shadow-sm border transition-all duration-200 hover:shadow-md
    ${priority === 'critical' ? 'border-red-200 bg-red-50' : ''}
    ${priority === 'important' ? 'border-blue-200 bg-blue-50' : ''}
    ${priority === 'normal' ? 'border-gray-100' : ''}
  `;

  return (
    <div className={cardClass}>
      {/* Priority indicator */}
      {priority === 'critical' && (
        <div className="flex items-center space-x-2 mb-3">
          <ExclamationTriangleIcon className="h-4 w-4 text-red-600" />
          <span className="text-sm font-medium text-red-800">Needs attention</span>
        </div>
      )}
      
      {/* Question as header */}
      <h3 className="text-lg font-medium text-gray-900 mb-3 leading-tight">
        {question}
      </h3>
      
      {/* Natural language answer with trend */}
      <div className="flex items-start space-x-3 mb-4">
        <TrendIcon trend={trend} />
        <div className="flex-1">
          <p className="text-xl font-semibold text-gray-800 leading-tight mb-2">
            {answer}
          </p>
          <ConfidenceIndicator confidence={confidence} />
        </div>
      </div>
      
      {/* Progressive disclosure for details */}
      {detailData && (
        <div className="mb-4">
          <button
            onClick={() => setShowDetails(!showDetails)}
            className="flex items-center text-sm text-gray-600 hover:text-gray-800 transition-colors"
          >
            <span>{showDetails ? 'Hide' : 'Show'} details</span>
            <ChevronRightIcon 
              className={`h-4 w-4 ml-1 transition-transform ${showDetails ? 'rotate-90' : ''}`} 
            />
          </button>
          
          {showDetails && (
            <div className="mt-3 p-3 bg-gray-50 rounded-lg">
              {detailData.explanation && (
                <p className="text-sm text-gray-700 mb-3">{detailData.explanation}</p>
              )}
              
              {detailData.metrics && (
                <div className="mb-3">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Key metrics:</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {Object.entries(detailData.metrics).map(([key, value]) => (
                      <div key={key} className="text-sm">
                        <span className="text-gray-600">{key}:</span>
                        <span className="ml-1 font-medium text-gray-900">{value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {detailData.recommendations && detailData.recommendations.length > 0 && (
                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Recommendations:</h4>
                  <ul className="text-sm text-gray-700 space-y-1">
                    {detailData.recommendations.map((rec, index) => (
                      <li key={index} className="flex items-start">
                        <span className="text-blue-600 mr-2">•</span>
                        {rec}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      )}
      
      {/* Single, clear action */}
      <Link href={actionUrl}>
        <Button 
          variant="default"
          size="sm"
          className="w-full group"
        >
          <span>{action}</span>
          <ChevronRightIcon className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
        </Button>
      </Link>
    </div>
  );
}

// Example usage component for testing
export function InsightCardExample() {
  const sampleInsights = [
    {
      question: "Are my ads working?",
      answer: "Yes! You spent $127 yesterday and got 5 new customers",
      trend: "up" as const,
      confidence: "high" as const,
      action: "Scale this campaign",
      actionUrl: "/campaigns/123/scale",
      priority: "important" as const,
      detailData: {
        explanation: "Your Facebook campaign has a 4.2x return on ad spend, which is excellent.",
        metrics: {
          "Ad spend": "$127",
          "New customers": "5",
          "Cost per customer": "$25.40",
          "ROAS": "4.2x"
        },
        recommendations: [
          "Increase daily budget by 20%",
          "Duplicate top-performing ad creative",
          "Expand to similar audiences"
        ]
      }
    },
    {
      question: "How's my customer growth?",
      answer: "Steady. You gained 12 customers this week (same as last week)",
      trend: "neutral" as const,
      confidence: "high" as const,
      action: "Explore growth strategies",
      actionUrl: "/growth/strategies",
      detailData: {
        explanation: "Your customer acquisition rate has plateaued. This is normal but there's room for improvement.",
        metrics: {
          "This week": "12 customers",
          "Last week": "12 customers", 
          "Growth rate": "0%",
          "Avg. customer value": "$89"
        },
        recommendations: [
          "Try new marketing channels",
          "Improve referral program",
          "A/B test pricing strategy"
        ]
      }
    },
    {
      question: "What needs my attention today?",
      answer: "7 customers left reviews - 2 need responses",
      trend: "neutral" as const,
      confidence: "high" as const,
      action: "Respond to reviews",
      actionUrl: "/reviews/pending",
      priority: "critical" as const,
      detailData: {
        explanation: "Responding to reviews quickly improves your reputation and shows customer care.",
        metrics: {
          "New reviews": "7",
          "Pending responses": "2",
          "Average rating": "4.8 ⭐",
          "Response rate": "85%"
        },
        recommendations: [
          "Respond within 24 hours",
          "Thank customers for positive reviews",
          "Address concerns in negative reviews professionally"
        ]
      }
    }
  ];

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Your Business Dashboard
        </h1>
        <p className="text-gray-600 mb-8">
          Here's what's happening with your business right now.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sampleInsights.map((insight, index) => (
            <InsightCard key={index} {...insight} />
          ))}
        </div>
      </div>
    </div>
  );
} 