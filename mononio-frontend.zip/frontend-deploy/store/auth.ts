import { create } from 'zustand';
import { User } from '@/types';
import apiClient from '@/lib/api';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  _hasHydrated: boolean;
  
  // Actions
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  getCurrentUser: () => Promise<void>;
  clearError: () => void;
  initialize: () => void;
  setHasHydrated: (state: boolean) => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  isAuthenticated: false,
  isLoading: true, // Start with loading true to prevent render issues
  error: null,
  _hasHydrated: false,

  initialize: () => {
    console.log('🔐 Auth store: Initializing...');
    
    // Only initialize on the client side
    if (typeof window === 'undefined') {
      console.log('🔐 Auth store: Server-side rendering, skipping initialization');
      set({ isLoading: false, _hasHydrated: true });
      return;
    }

    set({ isLoading: true, error: null });
    
    // Use setTimeout to make this non-blocking
    setTimeout(async () => {
      try {
        // Check if we have a token in localStorage
        const token = localStorage.getItem('auth_token');
        console.log('🔐 Auth store: Token found:', !!token);
        
        if (token) {
          // Try to get current user with existing token
          console.log('🔐 Auth store: Attempting to get current user...');
          const user = await apiClient.getCurrentUser();
          console.log('🔐 Auth store: Current user retrieved:', user);
          set({
            user,
            isAuthenticated: true,
            isLoading: false,
            error: null,
            _hasHydrated: true,
          });
        } else {
          // No token found, user is not authenticated
          console.log('🔐 Auth store: No token found, user not authenticated');
          set({
            user: null,
            isAuthenticated: false,
            isLoading: false,
            error: null,
            _hasHydrated: true,
          });
        }
      } catch (error: any) {
        // Token is invalid or expired, clear it
        console.log('🔐 Auth store: Error during initialization:', error);
        if (typeof window !== 'undefined') {
          localStorage.removeItem('auth_token');
        }
        set({
          user: null,
          isAuthenticated: false,
          isLoading: false,
          error: null,
          _hasHydrated: true,
        });
      }
    }, 100); // Small delay to ensure hydration is complete
  },

  login: async (email: string, password: string) => {
    console.log('🔐 Auth store: Attempting login for:', email);
    set({ isLoading: true, error: null });
    try {
      const response = await apiClient.login({ email, password });
      console.log('🔐 Auth store: Login successful:', response);
      set({
        user: response.user,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      });
      return true;
    } catch (error: any) {
      console.log('🔐 Auth store: Login failed with error:', error);
      console.log('🔐 Auth store: Error message:', error.message);
      console.log('🔐 Auth store: Error stack:', error.stack);
      set({
        isLoading: false,
        error: error.message || 'Login failed',
      });
      return false;
    }
  },

  logout: async () => {
    console.log('🔐 Auth store: Logging out...');
    set({ isLoading: true });
    try {
      await apiClient.logout();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      set({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: null,
      });
    }
  },

  getCurrentUser: async () => {
    console.log('🔐 Auth store: Getting current user...');
    set({ isLoading: true });
    try {
      const user = await apiClient.getCurrentUser();
      console.log('🔐 Auth store: Current user retrieved:', user);
      set({
        user,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      });
    } catch (error: any) {
      console.log('🔐 Auth store: Failed to get current user:', error);
      set({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: error.message || 'Failed to get user',
      });
    }
  },

  clearError: () => {
    set({ error: null });
  },

  setHasHydrated: (state: boolean) => {
    console.log('🔐 Auth store: Setting hydration state to:', state);
    set({ _hasHydrated: state });
  },
})); 